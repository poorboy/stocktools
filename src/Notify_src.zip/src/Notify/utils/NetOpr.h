#pragma once

string GetNetData(wstring &strURL);

bool GetNetFile(wstring &strUrl, wstring &strFile);