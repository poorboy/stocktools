/********************************************************************
�ļ���:		LyLog.h 
������:		poorboy
����ʱ��:	[6/20/2013 10:34:42]
�޸�ʱ��:
�ļ�˵��:	 
*********************************************************************/
#ifndef __LYLOG_HEADER__
#define __LYLOG_HEADER__ 
#pragma once 
#define LOG_DEBUG        (0)
#define LOG_WARNING      (1)
#define LOG_INFO         (2)
#define LOG_ERROR        (3)  
 

void Log(int who, int level, LPCTSTR message, int line, const char* file,const char * funName);
// void SYSLog(int level, LPCTSTR message, int line, const char* file,const char * funName);

void LogING(int lever, const char * szfile, int nLine, LPWSTR wszPrintString, ...);

#define LYLOG(lever, msg, ...)     LyLogING( lever, __FILE__, __LINE__, msg, ## __VA_ARGS__)

#define LYDBG(msg,...)             LYLOG(LOG_DEBUG, msg, ## __VA_ARGS__)
#define LYWARN(msg, ...)           LYLOG(LOG_WARNING, msg, ## __VA_ARGS__)
#define LYINFO(msg, ...)           LYLOG(LOG_INFO, msg, ## __VA_ARGS__)
#define LYERR(msg, ...)            LYLOG(LOG_ERROR, msg, ## __VA_ARGS__)



class CLyLog
{
public:
    CLyLog(void); 
    ~CLyLog(void);
    static void Loging();
    static void Loging(int level ,wstring &mesg, int line, wstring &fileName);
    static void InitData(void);
    static void ClearData(void);
    static void FinshLog(int nTime);
    static bool bIsInit;
protected: 
    static  int m_nwho;
    static  int m_nlevel;
    static wstring m_strmesg;
    static int m_nline;
    static wstring m_strfileName;
    static wstring m_strlogfileName; 
    static wstring m_strlogDIR;  
    static string m_strLog;
    static wstring m_strLogSYS;
    static bool m_bIsClearLog;
    static int m_nCuuDay; 
    static HANDLE hLogFile;
    int  m_nDebugLevel;
}; 
#endif //__LYLOG_HEADER__
