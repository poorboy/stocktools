#include "../StdAfx.h"
#include "myLog.h" 

#include "../debugnew.h" 

CString GetLogTimeString(CTime time)
{ 
    CString strTmp;
    strTmp.Format(_T("%d-%02d-%02d %02d:%02d:%02d"),time.GetYear(),time.GetMonth(),time.GetDay(), time.GetHour(), time.GetMinute(), time.GetSecond());
    return strTmp;
} 


void LogING(int lever,const char * szfile,int nLine,LPWSTR wszPrintString, ... )
{
    if (wszPrintString == NULL) 
        return; 
 
        return;

    if (!CLyLog::bIsInit) 
        CLyLog::InitData();

    if (!CLyLog::bIsInit) 
        return; 

    va_list arg_list;
    int len;
    WCHAR * wszFinalString; 
    va_start(arg_list, wszPrintString); 
    len = _vscwprintf( wszPrintString, arg_list ) + 1; 
    wszFinalString =(WCHAR *) malloc( len * sizeof(WCHAR) );
    vswprintf_s(wszFinalString, len, wszPrintString, arg_list); 
    va_end(arg_list);  
    CString strMesg = CString(wszFinalString); 
    free(wszFinalString); 
    wszFinalString = NULL; 

    CString strFile = CString(szfile); 
    strFile = strFile.Mid(strFile.ReverseFind(L'\\')); 
    CLyLog::Loging(lever,strMesg,nLine,strFile);  
}

int CLyLog::m_nwho = 0;
int CLyLog::m_nlevel = 0;
CString CLyLog::m_strmesg = _T(""); 
int CLyLog::m_nline = 0;
CString CLyLog::m_strfileName = _T(""); 
CString CLyLog::m_strlogfileName = _T(""); 
CString CLyLog::m_strlogDIR = _T("");
CCriticalSection CLyLog::m_csLock; 
CTime CLyLog::m_LastWriteTime;
string CLyLog::m_strLog;
CString CLyLog::m_strLogSYS = _T(""); 
bool CLyLog::m_bIsClearLog = false;
int CLyLog::m_nCuuDay = 0;
bool CLyLog::bIsInit = false;
HANDLE CLyLog::hLogFile = INVALID_HANDLE_VALUE;

CString szLevel[4] = {_T("Debug"), _T("Warning"), _T("Info"),_T("Error")};


//  
CLyLog::CLyLog(void)
{
    // m_logFile;
    m_nwho = 0;
    m_nlevel = 0;
    m_strmesg  = _T("");
    m_nline = 0;
    m_strfileName  = _T("");
    m_LastWriteTime = CTime::GetCurrentTime();
}

CLyLog::~CLyLog(void)
{
    if (INVALID_HANDLE_VALUE != hLogFile)
    { 
        ::CloseHandle(hLogFile);
    } 
}

void CLyLog::InitData(void)
{
    CString strError;
    m_nwho = 0;
    m_nlevel = 0;
    m_strmesg  = _T("");
    m_nline = 0;
    m_strfileName  = _T("");
    m_LastWriteTime = CTime::GetCurrentTime();
    m_nCuuDay = m_LastWriteTime.GetDay();  
    m_strlogfileName = L""; 
    m_strlogDIR = GetAppDir() + _T("data\\MonFile\\Log\\");
    m_strlogfileName.Format(_T("%s%d-%02d-%02d.log"),m_strlogDIR,m_LastWriteTime.GetYear(),m_LastWriteTime.GetMonth(),m_LastWriteTime.GetDay());

    if (!DirExist(m_strlogDIR))  
        SHCreateDirectory(NULL,m_strlogDIR);  


    if (hLogFile == INVALID_HANDLE_VALUE)
    {
        bool bNewFile = false;
        if (!IsFileExists((LPCTSTR)m_strlogfileName))
        {			  
            CFile fil = CFile(m_strlogfileName,CFile::modeCreate);
            fil.Close();
            bNewFile = true; 
        }


        hLogFile = ::CreateFile(m_strlogfileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hLogFile == INVALID_HANDLE_VALUE)
        {
            LYDBG(_T("����־�ļ�ʧ�� ,��������ǣ�%d"),::GetLastError());
            return ;
        }

        if (!bNewFile)
        {
            DWORD dwPtr = SetFilePointer(hLogFile,0,0,FILE_END);  
            if (dwPtr == INVALID_SET_FILE_POINTER)  
            {  
                LYDBG(_T("������־�ļ�ָ��ʧ�� ,��������ǣ�%d"),::GetLastError());
                return; 
            }  
        }
    }
    bIsInit = true;
}

void CLyLog::ClearData(void)
{
    if (INVALID_HANDLE_VALUE != hLogFile)
        ::CloseHandle(hLogFile);
}  


void CLyLog::FinshLog(int nTime)
{
    CTime tCuuTime = CTime::GetCurrentTime(); 
    m_LastWriteTime = CTime::GetCurrentTime();   
    CTimeSpan tSpan = m_LastWriteTime - tCuuTime;
    int nWriteTime = (tSpan.GetTotalSeconds()/60);
    if (nWriteTime < nTime) 
        return; 
 
    if (hLogFile)
    { 
        DWORD cbLenth,cbWritten; 
        cbLenth = m_strLog.length();

        DWORD dwPtr = SetFilePointer(hLogFile,0,0,FILE_END);  
        if (dwPtr == INVALID_SET_FILE_POINTER)   
            LYDBG(_T("������־�ļ�ָ��ʧ�� ,��������ǣ�%d"),::GetLastError());

        if (::WriteFile(hLogFile,m_strLog.c_str(), cbLenth, &cbWritten, NULL))
        {
            m_strLog.clear();
            m_LastWriteTime = CTime::GetCurrentTime();  
        }else
        {

            LYDBG(_T("д��־ ,��������ǣ�%d"),::GetLastError());
        }
    }  
}

void CLyLog::Loging()
{      
    wstring strMesg,strError;

    CTime tCuuTime = CTime::GetCurrentTime(); 
    if (m_nCuuDay != tCuuTime.GetDay())
    { 
        bool bNewFile = false;
        m_nCuuDay = tCuuTime.GetDay();

        if (INVALID_HANDLE_VALUE != hLogFile)
        { 
            ::CloseHandle(hLogFile);
        }

        m_strlogfileName.Format(_T("%s%d-%02d-%02d.log"),m_strlogDIR,tCuuTime.GetYear(),tCuuTime.GetMonth(),tCuuTime.GetDay()); 

        if (!IsFileExists((LPCTSTR)m_strlogfileName))
        {			  
            CFile fil = CFile(m_strlogfileName,CFile::modeCreate);
            fil.Close();
            bNewFile = true;
        }  

        hLogFile = ::CreateFile(m_strlogfileName, GENERIC_WRITE|GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hLogFile == INVALID_HANDLE_VALUE)
        {
            LYDBG(_T("����־�ļ�ʧ�� ,��������ǣ�%d"),::GetLastError()); 
            return ;
        }
        if (!bNewFile)
        {
            DWORD dwPtr = SetFilePointer(hLogFile,0,0,FILE_END);  
            if (dwPtr == INVALID_SET_FILE_POINTER)  
            {  
                LYDBG(_T("������־�ļ�ָ��ʧ�� ,��������ǣ�%d"),::GetLastError());
                return; 
            }  
        }
    } 

    if (hLogFile == INVALID_HANDLE_VALUE)
    {
        bool bNewFile = false;
        if (!IsFileExists((LPCTSTR)m_strlogfileName))
        {			  
            CFile fil = CFile(m_strlogfileName,CFile::modeCreate);
            fil.Close();
            bNewFile = true; 
        }

        hLogFile = ::CreateFile(m_strlogfileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hLogFile == INVALID_HANDLE_VALUE)
        {
            LYDBG(_T("����־�ļ�ʧ�� ,��������ǣ�%d"),::GetLastError()); 
            return ;
        }

        if (!bNewFile)
        {
            DWORD dwPtr = SetFilePointer(hLogFile,0,0,FILE_END);  
            if (dwPtr == INVALID_SET_FILE_POINTER)  
            {  
                LYDBG(_T("������־�ļ�ָ��ʧ�� ,��������ǣ�%d"),::GetLastError()); 
                return; 
            }  
        }
    }

    strMesg.Format(_T("[%s]:[%s][%sL%d]:%s\r\n"),
        ::GetLogTimeString(),
        szLevel[m_nlevel%4],
        m_strfileName,
        m_nline,
        m_strmesg
        );

    _tprintf(_T("[%s]:[%s][%sL%d]:%s\r\n"),
        ::GetLogTimeString(),
        szLevel[m_nlevel%4],
        m_strfileName,
        m_nline,
        m_strmesg);

    string strtmgMsg = string(W2A(strMesg));

    m_strLog.append(strtmgMsg);

    DWORD cbLenth,cbWritten; 
    cbLenth = m_strLog.length();
    if (cbLenth < TaskPathManager::Instance()->GetLogCacheSize())    
        return;

    DWORD dwSize;   
    DWORD mpsize = GetFileSize(hLogFile,&dwSize);
    DWORD dwLogSize = TaskPathManager::Instance()->GetMaxLogFileSize();
    dwLogSize *= 1024;
    dwLogSize *= 1024;
    if ((mpsize > dwLogSize)
        ||
        (dwSize > 0)
        )
    {
        CloseHandle(hLogFile);
        CFile::Remove(m_strlogfileName); 
        CFile fil = CFile(m_strlogfileName,CFile::modeCreate);
        fil.Close();

        hLogFile = ::CreateFile(m_strlogfileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hLogFile == INVALID_HANDLE_VALUE)
        {
            LYDBG(_T("����־�ļ�ʧ�� ,��������ǣ�%d"),::GetLastError()); 
            return ;
        } 
    }

    DWORD dwPtr = SetFilePointer(hLogFile,0,0,FILE_END);  
    if (dwPtr == INVALID_SET_FILE_POINTER)  
    {   
        LYDBG(_T("������־�ļ�ָ��ʧ�� ,��������ǣ�%d"),::GetLastError()); 
        return; 
    } 

    if (::WriteFile(hLogFile,m_strLog.c_str(), cbLenth, &cbWritten, NULL))
    {
        m_strLog.clear();
        m_LastWriteTime = CTime::GetCurrentTime();  
    }else
    {

        LYDBG(_T("д��־ ,��������ǣ�%d"),::GetLastError());
    }

    m_strLog.clear();
    m_LastWriteTime = CTime::GetCurrentTime();  
}
void CLyLog::Loging(int level ,CString &mesg, int line, CString &fileName)
{ 
    try
    { 
        m_csLock.Lock();
        CString strTmpMsg = mesg;
        CString strTmpFile = fileName;
        m_nwho = 0; 
        m_nlevel = level; 
        m_strmesg  = strTmpMsg;
        m_nline = line;
        m_strfileName = strTmpFile;
        Loging(); 
        m_csLock.Unlock();
    }
    catch (CMemoryException* e)
    {

    }
    catch (CFileException* e)
    {
    }
    catch (CException* e)
    {
    }
    catch (...)
    {
    }
} 
