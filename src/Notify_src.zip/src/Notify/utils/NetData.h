#pragma once
#include <xstring>

using namespace std;

typedef enum _NetType
{
	URL_TYPE_163   = 1,
	URL_TYPE_Hexun = 2,
}NetType;

class NetStockData
{
public:
	NetStockData();
	~NetStockData();

	string GetStockData(wstring &skNo, NetType _type = URL_TYPE_163);

protected:
	string GetStockDataBy163(wstring &skNo);
	string GetStockDataByHexun(wstring &skNo);

private:
	wstring GetUrl(wstring &strNo, NetType _type = URL_TYPE_163);
};