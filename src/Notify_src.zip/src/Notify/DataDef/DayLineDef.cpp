#include <StdAfx.h>
#include "CommData.h"

bool _SecondItem::FromData(vector<wstring> &vctFd, CTimeEx &_time)
{
	if (vctFd.size() < 6) return false;

	wstring strTmp;
	strTmp = _time.ToString();
	strTmp += L" ";
	strTmp += vctFd[0];

	//�ɽ�ʱ��	
	time = CTimeEx(strTmp.c_str());

	//�ɽ���	
	dP = _ttof(vctFd[1].c_str());

	//�۸�䶯	
	duxp = _ttof(vctFd[2].c_str());

	//�ɽ���(��)
	uCount = _tstoi(vctFd[3].c_str());

	//�ɽ���(Ԫ)	
	nAllM = _tstoi64(vctFd[4].c_str());

	//���� 1 �� 2 ��  3 ��
	if (vctFd[5].find(L"��") != string::npos)
		uAtrr = 1;
	else if (vctFd[5].find(L"��") != string::npos)
		uAtrr = 2;
	else if (vctFd[5].find(L"��") != string::npos)
		uAtrr = 3;
	else
		uAtrr = 0;

	return IsValTime();
}


bool _SecondItem::FromData(wstring &strData, CTimeEx &_time)
{
	vector<wstring> vctFd;
	int i = 0;
	wstring _data = strData;
	wstring wTmp;
	while ((i = _data.find_first_of(L'\t')) && (i != string::npos))
	{
		wTmp = _data.substr(0, i);
		vctFd.push_back(wTmp);
		_data = _data.substr(i + 1);
	}
	vctFd.push_back(_data);
	return FromData(vctFd, _time);
}
bool _SecondItem::IsValTime()
{
	if (time.GetMinute() < 30 && time.GetHour() == 9)
		return false;
	return true;
}


void _MinuteItem::InitData(SecondItem &item)
{
	time = item.time;
	dP = item.dP;
	nAllC += item.uCount;

	//���� 1 �� 2 ��  3 ��
	if (item.uAtrr == 1)
		nAllM += item.nAllM;
	else if (item.uAtrr == 2)
		nAllM -= item.nAllM;

	if (_vctP.size() < 1)
	{
		dMinP = item.dP;
		dMaxp = item.dP;
	}
	else
	{
		if (dMinP > item.dP) dMinP = item.dP;
		if (dMaxp < item.dP) dMaxp = item.dP;
	}
}
void _MinuteItem::GetAvgP()
{
	dAvg = 0.000;
	for (int i = 0; i < _vctP.size(); i++)
	{
		dAvg += _vctP[i].dP;
	}

	dAvg /= _vctP.size();
}
bool _MinuteItem::AddSItem(SecondItem &item)
{
	if (_vctP.size() > 0 && time.GetMinute() != item.time.GetMinute())
	{
		GetAvgP();
		return false;
	}

	InitData(item);
	_vctP.push_back(item);
	return true;
}

void _MinuteItem::ReSet()
{
	_vctP.clear();
	dMinP = 0.00000;
	dMaxp = 0.00000;
	dP = 0.00000;
	dAvg = 0.00000;
	nAllM = 0;
	nAllC = 0;
}

void _DayItem::ClacData(MinuteItem &mItem)
{
	nAllM += mItem.nAllM;
	if (_vctP.size() > 0) {
		if (dMinP > mItem.dMinP) dMinP = mItem.dMinP;
		if (dMaxp < mItem.dMaxp) dMaxp = mItem.dMaxp;

		if (nMaxM < mItem.nAllM) nMaxM = mItem.nAllM;
		if (nMinM > mItem.nAllM) nMinM = mItem.nAllM;
	}
	else {
		dMinP = mItem.dMinP;
		dMaxp = mItem.dMaxp;

		nMaxM = mItem.nAllM;
		nMinM = mItem.nAllM;
	}
}

void _DayItem::ReSetData(CTimeEx &_time)
{
	time = _time;
	_vctP.clear();

	dMinP = 0.0000;
	dMaxp = 0.0000;
	dP = 0.0000;
	nAllM = 0;
	nMaxM = 0;
	nMinM = 0;

}

void _DayItem::ReSort()
{
	vector<MinuteItem> vctTmp = _vctP;
	_vctP.clear();
	for (int i = (vctTmp.size() - 1); i >= 0; i--)
	{
		_vctP.push_back(vctTmp[i]);
	}
}

void _DayItem::AddTimeItem(wstring &strData)
{
	if (!_sItem.FromData(strData, time)) return;

	if (!_mItem.AddSItem(_sItem))
	{
		ClacData(_mItem);
		_vctP.push_back(_mItem);
		_mItem.ReSet();
		_mItem.AddSItem(_sItem);
	}
}

void _DayItem::AddTimeItem(vector<wstring> &vctFd)
{
	if (!_sItem.FromData(vctFd, time)) return;

	if (!_mItem.AddSItem(_sItem))
	{
		ClacData(_mItem);
		_vctP.push_back(_mItem);
		_mItem.ReSet();
		_mItem.AddSItem(_sItem);
	}
}

MinuteItem _DayItem::operator[](int nIdx)
{
	return _vctP[nIdx];
}