#ifndef __COMMDATA__H__
#define __COMMDATA__H__
#pragma once 
#include "StockDef.h"
#include "DayLineDef.h"
#include "CfgSet.h" 

extern vector<SData> g_sData;
extern map<wstring, vector<SData>> g_Groub;
extern CCfgSet _set;
extern DayItem g_DayData;

#endif //__COMMDATA__H__