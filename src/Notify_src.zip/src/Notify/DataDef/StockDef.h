#ifndef __STOCKDEF__H__
#define __STOCKDEF__H__
#pragma once 
#include <vector>
#include <string>

typedef struct _StockPrice
{
	int nCount;
	double duPrice;
	wstring addTime;
}StockPrice;


typedef struct _ShortcutsKey
{
	wstring strName;
	wstring KeyDes;
	DWORD dwHotKey;
	WCHAR chKey;
	UINT uHotID;
	UINT uID;

	void SetKeyInfo(wstring &strKey);
	wstring GetKeyDes();
	void UpKeyDes();
	void AddHotKey(wstring &strKey);

}ShortKey;

typedef struct _SData
{
	wstring SNO;
	double  MinP;
	double  MaxP;

	double duOp;
	double duCloseP;
	double duCp;
	double duXp;
	double duZdf;
	double duFy;
	int profit;

	DWORD dwColor;
	static DWORD dwCrMax;
	static DWORD dwCrMaxEx;
	static DWORD dwCrMin;
	static DWORD dwCrMinEx;
	static double _duBrokerage;

	static DWORD dwCrMinExBK;
	static DWORD dwCrMaxExBK;

	DWORD dwAllNumber;
	
	_SData();

	void GetColor();
	DWORD GetTxtColor();
	DWORD GetItemBkColor();

	double GetTransfer(double duPrice);
	double GetBrokerage(double duPrice);

	double ClacHCharge();
	void ClacCharge();
	void analyze();

	vector<std::wstring> vctFd;
	vector<StockPrice> vctSPrice;
	vector <RECT> vctRc;
}SData;

#endif //__CCFGSET__H__