#pragma once
#ifndef __DAY_LINE_DEF_H__
#define __DAY_LINE_DEF_H__

#include <vector>
#include <string>
#include "StockDef.h"
#include "../Utils/CTimeEx.h"


typedef struct _SecondItem
{
	//�ɽ�ʱ��	
	CTimeEx time;
	//�ɽ���	
	double  dP;
	//�۸�䶯	
	double duxp;
	//�ɽ���(��)
	UINT    uCount;
	//�ɽ���(Ԫ)	
	__int64 nAllM;
	//����
	UINT    uAtrr;   // 1 �� 2 ��  3 ��

	bool FromData(vector<wstring> &vctFd, CTimeEx &_time);
	bool FromData(wstring &strData, CTimeEx &_time);
	bool IsValTime();

}SecondItem;

typedef struct _MinuteItem
{
	CTimeEx time;
	double  dMinP;
	double dMaxp;
	double dP;
	double dAvg;
	__int64 nAllM = 0;
	__int64 nAllC = 0;
	vector<SecondItem> _vctP;

	void InitData(SecondItem &item);
	void GetAvgP();
	bool AddSItem(SecondItem &item);
	void ReSet();
}MinuteItem;

typedef struct _DayItem
{
	vector<MinuteItem> _vctP;
	double  dMinP;
	double dMaxp;
	double dP;
	__int64 nAllM;

	__int64 nMaxM;
	__int64 nMinM;

	CTimeEx time;


	MinuteItem _mItem;
	SecondItem _sItem;


	void ClacData(MinuteItem &mItem);
	void ReSetData(CTimeEx &_time);
	void ReSort();
	void AddTimeItem(vector<wstring> &vctFd);
	void AddTimeItem(wstring &strData);

	MinuteItem operator[](int nIdx);

}DayItem;

#endif //__DAY_LINE_DEF_H__