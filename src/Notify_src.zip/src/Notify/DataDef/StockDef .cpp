#include <math.h>
#include "../StdAfx.h"
#include "StdAfx.h"
#include "StockDef.h"


DWORD _SData::dwCrMax = 0xFF000000 + (0, 0, 255);
DWORD _SData::dwCrMaxEx = 0xFF000000 + RGB(38, 39, 173);
DWORD _SData::dwCrMin = 0xFF000000 + RGB(0, 255, 0);
DWORD _SData::dwCrMinEx = 0xFF000000 + RGB(58, 138, 66);

DWORD _SData::dwCrMinExBK = 0xFF000000 + RGB(200, 200, 170);
DWORD _SData::dwCrMaxExBK = 0xFF000000 + RGB(100, 130, 180);

double _SData::_duBrokerage = 0.00025;

void _ShortcutsKey::SetKeyInfo(wstring &strKey)
{
	wstring tmp;
	dwHotKey = 0;
	WCHAR ch = ' ';
	chKey = ' ';

	KeyDes = L"";

	for (int i = 0; i < strKey.length(); i++)
	{
		ch = strKey[i];
		if (ch == L'+') AddHotKey(tmp);
		else tmp += ch;
	}
	if (tmp.length() > 0) AddHotKey(tmp);
	UpKeyDes();
}

wstring _ShortcutsKey::GetKeyDes()
{
	return KeyDes;
}

void _ShortcutsKey::UpKeyDes()
{
	if (dwHotKey & MOD_SHIFT) KeyDes = L"Shift";
	if (dwHotKey & MOD_CONTROL) KeyDes.append(L"+Ctrl");
	if (dwHotKey & MOD_ALT) KeyDes.append(L"+Alt");
	KeyDes.append(L"+");
	KeyDes += chKey;

	/*
	#define VK_SPACE          0x20
	#define VK_PRIOR          0x21
	#define VK_NEXT           0x22
	#define VK_END            0x23
	#define VK_HOME           0x24
	#define VK_LEFT           0x25
	#define VK_UP             0x26
	#define VK_RIGHT          0x27
	#define VK_DOWN           0x28
	#define VK_SELECT         0x29
	#define VK_PRINT          0x2A
	#define VK_EXECUTE        0x2B
	#define VK_SNAPSHOT       0x2C
	#define VK_INSERT         0x2D
	#define VK_DELETE         0x2E
	#define VK_HELP           0x2F
	*/

	if (chKey == L'<') chKey = VK_LEFT;
	else if (chKey == L'>') chKey = VK_RIGHT;
	//else if (chKey == L'∧') chKey = VK_UP;
	//else if (chKey == L'∨') chKey = VK_DOWN;

}

void _ShortcutsKey::AddHotKey(wstring &strKey)
{
	CDuiString strTmp = strKey.c_str();
	strKey = L"";
	//Shift+Ctrl+Alt
	if (strTmp.CompareNoCase(L"Shift") == 0) dwHotKey |= MOD_SHIFT;
	else if (strTmp.CompareNoCase(L"Ctrl") == 0) dwHotKey |= MOD_CONTROL;
	else if (strTmp.CompareNoCase(L"Alt") == 0) dwHotKey |= MOD_ALT;
	else if (strTmp.CompareNoCase(L"SS") == 0) dwHotKey |= MOD_SHIFT;
	else if (strTmp.CompareNoCase(L"CC") == 0) dwHotKey |= MOD_CONTROL;
	else if (strTmp.CompareNoCase(L"AA") == 0) dwHotKey |= MOD_ALT;
	else chKey = (char)strTmp[0];
}

_SData::_SData()
{
	dwColor = RGB(0, 0, 255);
	vctFd.clear();
	vctSPrice.clear();
	dwAllNumber = 0;
}

#define IF_BREAK(X, Y)  { X = Y; break; }
#define COR_BREAK(Y) IF_BREAK(dwColor, Y)

void _SData::GetColor()
{
	dwColor = dwCrMax;

	do
	{
		if ((MinP > 0.000001) && (duCp < MinP)) COR_BREAK(dwCrMinEx);

		if ((MaxP > 0.000001) && (duCp > MaxP)) COR_BREAK(dwCrMaxEx);

		if ((MaxP < 0.000001) && (MinP < 0.000001) && (duCp < duOp)) COR_BREAK(dwCrMin);

		if (duCp < duCloseP) COR_BREAK(dwCrMin);

		if (duCp > duCloseP) COR_BREAK(dwCrMax);

	} while (0);
}


DWORD _SData::GetTxtColor()
{
	DWORD dwTxtCr = dwColor;

	if (dwAllNumber > 0)
	{
		if (duZdf < 0.00001)
		{
			dwTxtCr = dwCrMin;
		}
	}


	return dwTxtCr;

}

double _SData::GetTransfer(double duPrice)
{
	double duTransfer = 0.000;
	if (SNO.find(L"sh") != string::npos)
	{
		duTransfer = duPrice * 0.00002;
		if (duTransfer < 0.010) duTransfer = 0.010;
	}
	return duTransfer;
}


#define BKCOR_BREAK(Y) IF_BREAK(dwBkColor, Y)

DWORD _SData::GetItemBkColor()
{
	DWORD dwBkColor = 0;

	do
	{
		//BGR  RGB   
		if ((MaxP < 0.000001) && (MinP < 0.000001)) BKCOR_BREAK(0); 

		if ((MinP > 0.000001) && (duCp <= MinP)) BKCOR_BREAK(dwCrMinExBK);

		if ((MaxP > 0.000001) && (duCp >= MaxP)) BKCOR_BREAK(dwCrMaxExBK);
	} while (0); 
	//0xFF5933290xFFC86400
	return dwBkColor;
}

double _SData::GetBrokerage(double duPrice)
{
	double duBrokerage = 0.000;
	duBrokerage = duPrice*_duBrokerage;
	if (duBrokerage < 5.00000) duBrokerage = 5.000;
	return duBrokerage;
}

double _SData::ClacHCharge()
{
	double duRet = 0.000;
	double duTmpPrice = 0.000;
	double duAllPrieCb = 0.000;
	double duAllPrieCU = 0.000;
	dwAllNumber = 0;

	double duPrieTotal = 0.000;

	for (int i = 0; i < vctSPrice.size(); i++)
	{
		duTmpPrice = vctSPrice[i].nCount * vctSPrice[i].duPrice;
		duAllPrieCb += duTmpPrice;
		dwAllNumber += vctSPrice[i].nCount;

		duRet += GetBrokerage(duTmpPrice);
		duRet += GetTransfer(duTmpPrice);
	}

	duAllPrieCU += duRet;
	duAllPrieCU = dwAllNumber *duCp;
	profit = (int)(duAllPrieCU - duAllPrieCb);
	profit -= duRet;
	profit -= 1;

	duRet = GetBrokerage(duAllPrieCU);
	duRet += GetTransfer(duAllPrieCU);


	double duPs = duAllPrieCU* 0.001;
	duRet += duPs;

	duPrieTotal = duAllPrieCb / dwAllNumber;
	duZdf = duCp - duPrieTotal;
	duZdf -= 0.01;
	return duRet;
}

void _SData::ClacCharge()
{
	if (vctSPrice.size() < 1) return;
	duFy = ClacHCharge();
	//佣金最低5元 万2.5  0.00025
	//税  0.001
	//过户费 0.00004
}

void _SData::analyze()
{
	if (vctFd.size() > 3)
	{
		duCloseP = _ttof(vctFd.at(2).c_str());
		duOp = _ttof(vctFd.at(1).c_str());
		duCp = _ttof(vctFd.at(3).c_str());
		if (duCp == 0.0000) return;
		duXp = duCp - duCloseP;
		ClacCharge();
		GetColor();
	}
}