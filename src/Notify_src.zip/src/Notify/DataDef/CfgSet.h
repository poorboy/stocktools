#ifndef __CCFGSET__H__
#define __CCFGSET__H__
#pragma once 

#include "StockDef.h"
#include "../mic/XML/Markup.h"
#include "../StdAfx.h"

class CCfgSet
{
public:
	CCfgSet();
	void InitFromCfg(void);
	void Save2Cfg(void);
	void FormateSNo(wstring &strNo);

	void UpShowInfoDlg()
	{
		bIsShowInfoDlg = (bIsShowInfoDlg ? false : true);
	}

	bool IsShowInfoDlg() { return bIsShowInfoDlg; }
	void SetShowInfoDlg(bool bIsShow) { bIsShowInfoDlg = bIsShow; }

	void UpShowInfo()
	{
		bIsShowTotal = (bIsShowTotal ? false : true);
	}

	bool IsNeedShow()
	{
		if (nAllSocketNumber < 1) return false;
		return bIsShowTotal;
	}

	bool ValidStockNO(CDuiString &strSNo);
	bool RegHotKey(CDuiString &retNotify, HWND _hWnd);
	bool UnRegHotKey(HWND _hWnd);
	UINT GetHotKeyID(DWORD hotID);

	void SaveColor(CXMLMarkup &_xml);
	void SaveShortKey(CXMLMarkup &_xml);
	void SaveStockItem(CXMLMarkup &_xml);

private:
	DWORD GetColorFromString(wstring &strColor);
	wstring GetColorStringFromDw(DWORD cr);

	void GetColor(CXMLMarkup &_xml);

	void GetSockItem(CXMLMarkup &_xml, SData &item);
	void GetShortKeyInfo(CXMLMarkup &_xml);
	void GetSockPriceItem(CXMLMarkup &_xml, StockPrice &item);
	void InitHotKey();
	void SetNewHotKeyInfo(ShortKey &newHot);



public:
	bool bIsShowInfoDlg;

	int nAllSocketNumber = 0;
	bool bIsShowTotal;

	map <UINT, ShortKey> MapHotKey;
};

#endif //__CCFGSET__H__