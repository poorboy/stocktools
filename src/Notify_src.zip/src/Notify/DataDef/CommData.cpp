#include "StdAfx.h"
#include "CommData.h"


vector<SData> g_sData;
map<wstring, vector<SData>> g_Groub; 
CCfgSet _set;
DayItem g_DayData;
