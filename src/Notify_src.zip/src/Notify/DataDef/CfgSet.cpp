#include "StdAfx.h"
#include "CfgSet.h"
#include "CommData.h"

CCfgSet::CCfgSet()
{
	InitFromCfg();
}

void CCfgSet::InitFromCfg(void)
{
	nAllSocketNumber = 0;
	bIsShowTotal = false;

	g_sData.clear();
	InitHotKey();

	wstring strFile = GetAppDir() + L"cfg.xml";
	CXMLMarkup _xml;

	if (!_xml.Load(strFile)) return;

	if (!_xml.FindElem(L"set")) return;

	_xml.IntoElem();

	wstring strTmp;
	GetColor(_xml);

	if (_xml.FindElem(L"Other"))
	{
		strTmp = _xml.GetAttrib(L"IsShowInfo");
		bIsShowInfoDlg = _tstoi(strTmp.c_str());
	}

	if (_xml.FindElem(L"ShortKey"))
	{
		GetShortKeyInfo(_xml);
	}

	if (_xml.FindElem(L"stock"))
	{
		_xml.IntoElem();

		while (_xml.FindElem(L"item"))
		{
			SData item;
			GetSockItem(_xml, item);
			g_sData.push_back(item);
		}
	}

	_xml.OutOfElem(); 

	if (_xml.FindElem(L"stocks"))
	{
		_xml.IntoElem();

		while (_xml.FindElem(L"items"))
		{
			strTmp = _xml.GetAttrib(L"name");
			vector<SData> vctItems;

			_xml.IntoElem();

			while (_xml.FindElem(L"item"))
			{
				SData item;
				GetSockItem(_xml, item);
				vctItems.push_back(item);
			}

			_xml.OutOfElem();

			g_Groub[strTmp] = vctItems;
		}
	}
}

void CCfgSet::FormateSNo(wstring &strNo)
{

	/*
	1������
����A��Ʊ��������60��ͷ
����B�ɴ�������900��ͷ
�����¹��깺�Ĵ�������730��ͷ
������ɴ�����700��ͷ

����2������
����A��Ʊ��������00��ͷ
����B�ɴ�������200��ͷ
�����¹��깺�Ĵ�������00��ͷ
������ɴ�����080��ͷ
������С���Ʊ��002��ͷ
������ҵ���Ʊ��300��ͷ��
����3������
����S��ͷ��ʾδ���йɸģ�
����ST��ͷ��ʾ��������ɶ�����Ϊ����ԭ��
����*ST��ͷ��ʾ�����з���
����XD��ʾ�ֺ��
	*/
	//60  900 730 700 

	if (strNo.find(L"sz") != string::npos) return;
	if (strNo.find(L"sh") != string::npos) return;


	wstring strTmp = strNo;
	strNo = L"sz";
	if (strTmp[0] == L'6' && strTmp[1] == L'0') strNo = L"sh";
	else if (strTmp[0] == L'9' && strTmp[1] == L'0' && strTmp[2] == L'0') strNo = L"sh";
	else if (strTmp[0] == L'7' && strTmp[1] == L'3' && strTmp[2] == L'0') strNo = L"sh";
	else if (strTmp[0] == L'7' && strTmp[1] == L'0' && strTmp[2] == L'0') strNo = L"sh";

	strNo += strTmp;

}
void CCfgSet::GetSockItem(CXMLMarkup &_xml, SData &item)
{
	wstring strTmp;

	item.SNO = _xml.GetAttrib(L"NO");
	FormateSNo(item.SNO);

	strTmp = _xml.GetAttrib(L"Min");
	item.MinP = _ttof(strTmp.c_str());

	strTmp = _xml.GetAttrib(L"Max");
	item.MaxP = _ttof(strTmp.c_str());

	while (_xml.FindChildElem(L"Price"))
	{
		StockPrice priceitem;
		GetSockPriceItem(_xml, priceitem);
		item.vctSPrice.push_back(priceitem);
	}
}

void CCfgSet::SetNewHotKeyInfo(ShortKey &newHot)
{
	map <UINT, ShortKey>::iterator itrFind = MapHotKey.find(newHot.uID);
	if (itrFind != MapHotKey.end())
	{
		itrFind->second = newHot;
		itrFind->second.uHotID = WM_USER + 5000 + newHot.uID;
	}
}

void CCfgSet::GetShortKeyInfo(CXMLMarkup &_xml)
{
	_xml.IntoElem();
	ShortKey Item;
	wstring strTmp;

	while (_xml.FindElem(L"key"))
	{
		strTmp = _xml.GetAttrib(L"id");
		Item.uID = _tstoi(strTmp.c_str());
		Item.strName = _xml.GetAttrib(L"desc");
		strTmp = _xml.GetAttrib(L"key");
		Item.SetKeyInfo(strTmp);
		SetNewHotKeyInfo(Item);
	}
	_xml.OutOfElem();
}

void CCfgSet::GetSockPriceItem(CXMLMarkup &_xml, StockPrice &item)
{
	wstring strTmp;
	strTmp = _xml.GetChildAttrib(L"count");
	item.nCount = _ttof(strTmp.c_str());
	nAllSocketNumber += item.nCount;

	strTmp = _xml.GetChildAttrib(L"p");
	item.duPrice = _ttof(strTmp.c_str());
	item.addTime = _xml.GetChildAttrib(L"time");
}

void CCfgSet::InitHotKey()
{

	DWORD dwHotKeyID = WM_USER + 5000;
	MapHotKey.clear();

	ShortKey Item;
	int nID = 1;
	Item.chKey = L'1';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"��ʾ���ؽ���";
	Item.KeyDes = L"Ctrl+Shift+1";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;


	Item.chKey = L'2';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"����ȡ����괩͸";
	Item.KeyDes = L"Ctrl+Shift+2";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;


	Item.chKey = L'R';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"���¼�������";
	Item.KeyDes = L"Ctrl+Shift+R";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;

	Item.chKey = L'S';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"��ʾ����������(��������)";
	Item.KeyDes = L"Ctrl+Shift+S";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;

	Item.chKey = VK_LEFT;
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"���ʹ���͸����";
	Item.KeyDes = L"Ctrl+Shift+<";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;

	Item.chKey = VK_RIGHT;// L'>';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"��ߴ���͸����";
	Item.KeyDes = L"Ctrl+Shift+>";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;

	Item.chKey = L'X';
	Item.dwHotKey = MOD_CONTROL | MOD_ALT | MOD_SHIFT;
	Item.strName = L"�˳�����";
	Item.KeyDes = L"Ctrl+Shift+Alt+X";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;
	Item.chKey = L'Q';
	Item.dwHotKey = MOD_CONTROL | MOD_SHIFT;
	Item.strName = L"��ʾ������ͣ��ʾ����";
	Item.KeyDes = L"Ctrl+Shift+Q";
	Item.uHotID = dwHotKeyID++;
	Item.uID = nID++;

	MapHotKey[Item.uID] = Item;
}


void CCfgSet::GetColor(CXMLMarkup &_xml)
{
	//crMax="255,0,0" crMin="0,255,0" crMaxEx="173,39,38" crMinEx="66,138,58"
	wstring strTmp;
	if (_xml.FindElem(L"color"))
	{
		strTmp = _xml.GetAttrib(L"crMax");
		if (strTmp.length() > 6) _SData::dwCrMax = GetColorFromString(strTmp);

		strTmp = _xml.GetAttrib(L"crMin");
		if (strTmp.length() > 6) _SData::dwCrMin = GetColorFromString(strTmp);

		strTmp = _xml.GetAttrib(L"crMaxEx");
		if (strTmp.length() > 6) _SData::dwCrMaxEx = GetColorFromString(strTmp);

		strTmp = _xml.GetAttrib(L"crMinEx");
		if (strTmp.length() > 6) _SData::dwCrMinEx = GetColorFromString(strTmp);


		strTmp = _xml.GetAttrib(L"crMinExBK");
		if (strTmp.length() > 6) _SData::dwCrMinExBK = GetColorFromString(strTmp);

		strTmp = _xml.GetAttrib(L"crMaxExBK");
		if (strTmp.length() > 6) _SData::dwCrMaxExBK = GetColorFromString(strTmp);

		strTmp = _xml.GetAttrib(L"Brokerage");
		_SData::_duBrokerage = _ttof(strTmp.c_str());
	}
}


DWORD CCfgSet::GetColorFromString(wstring &strColor)
{
	int nRvalue = 0;
	int nGvalue = 0;
	int nBvalue = 0;

	vector<wstring> strRgb;
	wstring strTmp;

	for (int i = 0; i < strColor.length(); i++)
	{
		if (strColor[i] != L',')
			strTmp += strColor[i];
		else
		{
			strRgb.push_back(strTmp);
			strTmp = L"";
		}
	}

	if (strTmp.length() > 0) strRgb.push_back(strTmp);
	if (strRgb.size() == 3)
	{
		nRvalue = _tstoi(strRgb[0].c_str());
		nGvalue = _tstoi(strRgb[1].c_str());
		nBvalue = _tstoi(strRgb[2].c_str());
	}

	DWORD cr = RGB(nRvalue, nGvalue, nBvalue);
	if (cr < 0xFF000000) cr += 0xFF000000;
	return cr;
}

wstring CCfgSet::GetColorStringFromDw(DWORD dwColor)
{
	DWORD cr = dwColor;
	if (dwColor > 0xFF000000) cr = dwColor - 0xFF000000;

	wstring wsColor;
	static TCHAR szBuf[50] = { 0 };
	ZeroMemory(szBuf, sizeof(szBuf));
	_stprintf_s(szBuf, 50 - 1, _T("%d,%d,%d")
		, GetRValue(cr), GetGValue(cr), GetBValue(cr));
	wsColor = szBuf;
	return wsColor;
}

void CCfgSet::SaveColor(CXMLMarkup &_xml)
{
	_xml.IntoElem();
	_xml.AddElem(L"color");
	wstring strTmp;
	CDuiString strT;
	strTmp = GetColorStringFromDw(_SData::dwCrMax);
	_xml.AddAttrib(L"crMax", strTmp);
	strTmp = GetColorStringFromDw(_SData::dwCrMin);
	_xml.AddAttrib(L"crMin", strTmp);
	strTmp = GetColorStringFromDw(_SData::dwCrMaxEx);
	_xml.AddAttrib(L"crMaxEx", strTmp);
	strTmp = GetColorStringFromDw(_SData::dwCrMinEx);
	_xml.AddAttrib(L"crMinEx", strTmp);

	strTmp = GetColorStringFromDw(_SData::dwCrMaxExBK);
	_xml.AddAttrib(L"crMaxExBK", strTmp);
	strTmp = GetColorStringFromDw(_SData::dwCrMinExBK);
	_xml.AddAttrib(L"CrMinExBK", strTmp);

	strT.Format(L"%0.6f", _SData::_duBrokerage);
	_xml.AddAttrib(L"Brokerage", strT.GetData());

	_xml.AddElem(L"Other");
	_xml.AddAttrib(L"IsShowInfo", bIsShowInfoDlg);
}

void CCfgSet::SaveShortKey(CXMLMarkup &_xml)
{
	_xml.AddElem(L"ShortKey");
	_xml.IntoElem();

	map <UINT, ShortKey>::iterator itr = MapHotKey.begin();
	for (; itr != MapHotKey.end(); ++itr)
	{
		_xml.AddElem(L"key");
		_xml.AddAttrib(L"id", itr->second.uID);
		_xml.AddAttrib(L"key", itr->second.GetKeyDes());
		_xml.AddAttrib(L"desc", itr->second.strName);
	}
	_xml.OutOfElem();
}

void CCfgSet::SaveStockItem(CXMLMarkup &_xml)
{
	_xml.AddElem(L"stock");
	_xml.IntoElem();


	CDuiString strT;

	for (int i = 0; i < g_sData.size(); i++)
	{
		_SData &sItem = g_sData[i];
		_xml.AddElem(L"item");
		_xml.AddAttrib(L"NO", sItem.SNO);

		if (sItem.MaxP > 0.0000001)
		{
			strT.Format(L"%0.2f", sItem.MaxP);
			_xml.AddAttrib(L"Max", strT.GetData());
		}

		if (sItem.MinP > 0.0000001)
		{
			strT.Format(L"%0.2f", sItem.MinP);
			_xml.AddAttrib(L"Min", strT.GetData());
		}

		for (int i = 0; i < sItem.vctSPrice.size(); i++)
		{
			StockPrice &spItem = sItem.vctSPrice[i];
			_xml.IntoElem();
			_xml.AddElem(L"Price");
			strT.Format(L"%0.2f", spItem.duPrice);
			_xml.AddAttrib(L"p", strT.GetData());
			_xml.AddAttrib(L"count", spItem.nCount);
			_xml.AddAttrib(L"time", spItem.addTime);
			_xml.OutOfElem();
		}
	}

	_xml.OutOfElem();
}

void CCfgSet::Save2Cfg(void)
{
	wstring strFile = GetAppDir() + L"cfg.xml";
	CXMLMarkup _xml;
	_xml.SetDoc(L"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
	_xml.AddElem(L"set");
	SaveColor(_xml);
	SaveShortKey(_xml);
	SaveStockItem(_xml);
	_xml.Save(strFile);
}

bool CCfgSet::ValidStockNO(CDuiString &strSNo)
{
	//"��֤��ָ
	if (strSNo == L"sz399001") return true;

	//"��ָ֤��
	if (strSNo == L"sh000001") return true;

	//"����300"
	if (strSNo == L"sh000300") return true;

	//"��С��ָ
	if (strSNo == L"sz399005") return true;

	//"��ҵ��ָ
	if (strSNo == L"sz399006") return true;

	//"B��ָ��"
	if (strSNo == L"sh000003") return true;


	int nLen = strSNo.GetLength();
	int nStart = 0;
	if (!((nLen == 6) || (nLen == 8))) return false; 
	//sh  sz
	if (strSNo[0] == L's' && strSNo.GetLength() == 8) nStart = 2;

	bool bIsVCode = false;

	if (strSNo[nStart + 0] == L'6' && strSNo[nStart + 1] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'9' && strSNo[nStart + 1] == L'0' && strSNo[nStart + 2] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'7' && strSNo[nStart + 1] == L'3' && strSNo[nStart + 2] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'7' && strSNo[nStart + 1] == L'0' && strSNo[nStart + 2] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'3' && strSNo[nStart + 1] == L'0' && strSNo[nStart + 2] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'0' && strSNo[nStart + 1] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'2' && strSNo[nStart + 1] == L'0' && strSNo[nStart + 2] == L'0') bIsVCode = true;
	else if (strSNo[nStart + 0] == L'0' && strSNo[nStart + 1] == L'8' && strSNo[nStart + 2] == L'0') bIsVCode = true;

	return bIsVCode;

}

bool CCfgSet::RegHotKey(CDuiString &retNotify, HWND _hWnd)
{
	retNotify = L"";
	CDuiString strTmp = L"";

	bool bNotify = true;
	bool bRegSuccess = false;

	map <UINT, ShortKey>::iterator itr = MapHotKey.begin();

	for (; itr != MapHotKey.end(); ++itr)
	{
		ShortKey &item = itr->second;
		bRegSuccess = RegisterHotKey(_hWnd, item.uHotID, item.dwHotKey, item.chKey);
		if (!bRegSuccess)
		{
			strTmp.Format(L"ע��[%s][%s]�ȼ�ʧ��!"
				, item.GetKeyDes().c_str()
				, item.strName.c_str());

			if (retNotify.GetLength() > 0)
				retNotify.Append(L"\r\n");

			retNotify.Append(strTmp.GetData());
			bNotify = false;
		}
	}
	return bNotify;
}

bool CCfgSet::UnRegHotKey(HWND _hWnd)
{
	map <UINT, ShortKey>::iterator itr = MapHotKey.begin();
	bool bRet = true;
	bool bRet1 = false;
	for (; itr != MapHotKey.end(); ++itr)
	{
		ShortKey &item = itr->second;
		bRet1 = UnregisterHotKey(_hWnd, item.uHotID);
		if (!bRet1) bRet = false;
	}
	return bRet;
}


UINT CCfgSet::GetHotKeyID(DWORD hotID)
{
	UINT uRet = 0;
	map <UINT, ShortKey>::iterator itr = MapHotKey.begin();

	for (; itr != MapHotKey.end(); ++itr)
	{
		if (itr->second.uHotID == hotID)
		{
			uRet = itr->second.uID;
			break;
		}
	}

	return uRet;
}