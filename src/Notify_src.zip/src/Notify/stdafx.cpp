// stdafx.cpp : source file that includes just the standard includes
// LWASUI.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file 
//#pragma comment(lib, "comctl32.lib") 
#pragma comment(lib, "shlwapi.lib") 
//#pragma comment(lib, "ws2_32.lib")
//#pragma comment(lib, "Psapi.lib") 
#pragma comment( lib, "Wininet.lib" )

#ifdef _DEBUG
#   ifdef _UNICODE
#       pragma comment(lib, "../../bin/release/DuiLib.lib")
#   else
#       pragma comment(lib, "../../bin/release/DuiLib.lib")
#   endif
#else
#   ifdef _UNICODE
#       pragma comment(lib, "../../bin/release/DuiLib.lib")
#   else
#       pragma comment(lib, "../../bin/release/DuiLib.lib")
#   endif
#endif