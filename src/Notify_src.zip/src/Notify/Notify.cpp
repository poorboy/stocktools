#include "stdafx.h"
#include "Notify.h"
#include "./dlg/MainDlg.h"
#include "./mic/MemDump/MiniDumper.h" 
#include "../commApi/debugnew.h"

CMiniDumper g_miniDumper(true);

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
HANDLE AppMutex = NULL;
MainDlg* g_pFrame = NULL;

void DoMakeVerInfo()
{
	if (!g_pFrame) return;
	g_pFrame->MakeVerInfo();
}

bool DoChkVer()
{
	bool bRet = false;
	if (!g_pFrame) return bRet;
	CDuiString strNote;
	if (g_pFrame->ChkNewVer(strNote))
	{
		strNote.Format(L"���µİ汾,�Ƿ����?\r\n������Ҫ������:%s", strNote.GetData());
		if (IDYES == MessageBox(NULL, strNote.GetData(), L"����", MB_YESNO))
			bRet = true;
	}
	return bRet;
}

bool ChkIsRun()
{
	return false;
	wstring MutexStr = L"Global\\StockNotifyTools";
	AppMutex = ::CreateMutex(NULL, TRUE, MutexStr.c_str());
	if (NULL != AppMutex)
	{
		if (GetLastError() == ERROR_ALREADY_EXISTS)
		{
			::ReleaseMutex(AppMutex);
			::CloseHandle(AppMutex);
			AppMutex = NULL;
			HWND hwnd = FindWindow(L"StockNofifyToolsUI", NULL);
			if (hwnd) ::ShowWindow(hwnd, SW_SHOW);
			return true;
		}
	}
	return false;
}

void ShowDlg()
{
	if (!g_pFrame) return;
	DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;

	g_pFrame->CreateDuiWindow(NULL,
		_T("StockNofifyToolsUI"),
		WS_POPUP, //WS_VISIBLE WS_POPUP    WS_OVERLAPPEDWINDOW  | WS_POPUPWINDOW, UI_WNDSTYLE_FRAME WS_EX_NOACTIVATE |
		dwExstyle);

	g_pFrame->CenterWindow();
	::ShowWindow(*g_pFrame, SW_SHOW);
	CPaintManagerUI::MessageLoop();
}

void ClsHandle()
{
	if (g_pFrame) delete g_pFrame;
	::CoUninitialize();
	::ReleaseMutex(AppMutex);
	::CloseHandle(AppMutex);
	AppMutex = NULL;
}

int APIENTRY _tWinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPTSTR    lpCmdLine,
	int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	CPaintManagerUI::SetInstance(hInstance);
	CPaintManagerUI::SetResourcePath(CPaintManagerUI::GetInstancePath() + _T("skin"));

	bool bShow = false;

	do
	{
		if (ChkIsRun()) break;

		if FAILED(::CoInitialize(NULL)) break;

		g_pFrame = new MainDlg();

		if (NULL == g_pFrame)  break;

		CDuiString strCmd = lpCmdLine;

		strCmd.MakeUpper();
		if (strCmd.Find(L"MAKEVERINFO") >= 0)
		{
			DoMakeVerInfo();
			break;
		}
		if (DoChkVer())
		{
			ClsHandle();
			g_pFrame->DownAndRun();
			break;
		}
		ShowDlg();
	} while (0);

	ClsHandle();
	return 0;
}