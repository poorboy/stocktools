#pragma once
#include "../DataDef/StockDef.h"
namespace DuiLib {

	class StockNote :public CControlUI
	{
	public:
		StockNote();
		~StockNote();

		void SetSData(SData &sData);
		double GetCost();
		double GetCuuCost(double duP);
		double GetExhibit();
		void DrawPrice(HDC hDC, RECT &rc);
		void ClacText(int i, double duU, double duD);
		virtual void PaintText(HDC hDC);
	protected:
		SData _sData;
		bool bInit = false;
	};
} // namespace DuiLib