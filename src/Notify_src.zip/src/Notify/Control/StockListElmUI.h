#pragma once
#include "../DataDef/CommData.h"
namespace DuiLib {

	class CStockListElmUI : public CListContainerElementUI
	{
	public:
		CStockListElmUI();

		LPCTSTR GetClass() const;
		void SetStockData(int inx);
		void DoEvent(TEventUI& event);

	protected:
		void SetBntAction();

		virtual bool OnClickAdd(void* param);
		virtual bool OnClickDel(void* param);
		virtual bool OnClickModify(void* param);
		virtual bool OnClickUp(void* param);
		virtual bool OnClickDown(void* param);
	protected:

		CLabelUI * pCodeLbl;
		CLabelUI * pNameLbl;
		CLabelUI * pMinLbl;
		CLabelUI * pMaxLbl;
		CLabelUI * pNumberLbl;
		CLabelUI * pMLbl;
		 
		CHorizontalLayoutUI *pHor0;
		CHorizontalLayoutUI *pHor1;
		CHorizontalLayoutUI *pHor2;
		 
		CButtonUI *pBntAdd;
		CButtonUI *pBntDel;
		CButtonUI *pBntModify;
		CButtonUI *pBntUp;
		CButtonUI *pBntDown;
		int nIndex = 0;
	};

} // namespace DuiLib
 