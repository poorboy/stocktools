#pragma once 
namespace DuiLib {

	class CHotKeyUI :public CTextUI
	{
	public:
		CHotKeyUI();
		~CHotKeyUI();  
		LPCTSTR GetClass() const;
		void UpKeyInfo(TEventUI& event);
		void DoEvent(TEventUI& event); 
		bool IsSet() { return bIsSet; }
		bool GetKeyInfo(DWORD &dwHotKey, WCHAR &chKey);
	private:
		void ShowCaret(TEventUI& event);
		void HideCaret(); 
		void AdusyCaretPos(POINT &pt, RECT &rc);

		bool bShowCaret;
		CDuiString strOldStr;
		bool bIsSet = false;

		DWORD dwHotKey;
		WCHAR chKey;
	};
} // namespace DuiLib