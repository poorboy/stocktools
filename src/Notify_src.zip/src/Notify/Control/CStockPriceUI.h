#pragma once

#include "../DataDef/StockDef.h"
namespace DuiLib {
	class CStockPriceUI :public CControlUI
	{
	public:
		CStockPriceUI();
		~CStockPriceUI();
		void AdusyWndSize();
		SIZE GetTextSize(HDC hDC);
		RECT GetItemRect();
		bool IsWindTrans(void);
		void DrawTitle(HDC hDc, int nStep);
		void GetItemText1(int inx, SData &item);
		void GetItemText(int inx, SData &item);
		void GetTextRect(RECT &rc, int inx, UINT &uTextStyle, int nStep);
		void DrawBk(HDC hDc, SData &item, int nInx);
		void DrawTextBox(HDC hDc, RECT rc);
		void DrawTexeItem(HDC hDc, RECT rc, int inx, int nStep);
		void DrawGroubTexeItem(HDC hDc, RECT rc, map<wstring, vector<SData>> ::iterator itr,
			int inx, DWORD cr, int nStep);
		
		void GetClomWidth(HDC hDC);
		int GetStepWidth();
		void DrawTotal(HDC hDC, RECT rc, int nStep, int nTotal, double nTotal2);
		virtual void PaintText(HDC hDC);
		void DrawTime(HDC hDC, RECT rc);
		int GetPtInIndex(TEventUI& event);
		void ShowCaret(TEventUI& event);
		void HideCaret();
		void SetWindAttrib(HWND hwnd, bool Add = true);
		void AdusyCaretPos(void);
		void AdusyCaretPos(POINT &pt, RECT &rc);
		void MoveCaretPost(bool bFst = true);
		int GetMoustInIndex(TEventUI& event);
		wstring GetMoustOnGroup(TEventUI& event);
		int GetMoustInItem(TEventUI& event, int nIdx); 
		void ChkClickPt(TEventUI& event);
		virtual void DoEvent(TEventUI& event);
		int GetCartInPost(void);
		void DoDelString(bool bFst = true);
	private:
		vector <int> colmWidth;
		vector<CDuiString> vctTitle;
		bool bShowCaret = false;
		int nIndex = -1;
		int nTextSize = 0;
		int cxChar = 0;
		int cyChar = 0;
		CDuiString strBuffer;
		HWND m_hwndForegWnd;
		int nHotIndex = -1;
		bool bIsCapture = false;
		int nSelIndex = -1;

		map<wstring, RECT> m_rcGroup;
	};
} // namespace DuiLib