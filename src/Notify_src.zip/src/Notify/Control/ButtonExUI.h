#pragma once

namespace DuiLib {

	class CButtonExUI : public CButtonUI
	{
	public:
		CButtonExUI(void);

		LPCTSTR GetClass() const;
		LPVOID GetInterface(LPCTSTR pstrName);

		LPCTSTR GetIconImage();
		void SetIconImage(LPCTSTR pStrImage);

		void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue);

		void PaintStatusImage(HDC hDC);
		void DoEvent(TEventUI& event);
		void CleanInfo();
		void SetTitle(DWORD y, DWORD m, DWORD d);

	protected:
		CDuiString m_strIconImage;
	};

} // namespace DuiLib