#include "StdAfx.h"
#include "ButtonExUI.h"

namespace DuiLib {

	CButtonExUI::CButtonExUI(void)
	{
	}

	LPCTSTR CButtonExUI::GetClass() const
	{
		return _T("ButtonExUI");
	}

	LPVOID CButtonExUI::GetInterface(LPCTSTR pstrName)
	{
		if (_tcscmp(pstrName, _T("ButtonEx")) == 0) return static_cast<CButtonExUI*>(this);
		return CButtonUI::GetInterface(pstrName);
	}

	LPCTSTR CButtonExUI::GetIconImage()
	{
		return m_strIconImage;
	}

	void CButtonExUI::SetIconImage(LPCTSTR pStrImage)
	{
		m_strIconImage = pStrImage;
		Invalidate();
	}

	void CButtonExUI::DoEvent(TEventUI& event)
	{
		if (!IsMouseEnabled() && event.Type > UIEVENT__MOUSEBEGIN && event.Type < UIEVENT__MOUSEEND) {
			if (m_pParent != NULL) m_pParent->DoEvent(event);
			else CButtonUI::DoEvent(event);
			return;
		}

		/*   if( event.Type == UIEVENT_MOUSEMOVE )
		   {
			   m_pManager->SendNotify(this, DUI_MSGTYPE_HEADERCLICK);

		   }else*/ if (event.Type == UIEVENT_MOUSEENTER)
		   {
			   m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSEENTER);

		   }
		   else if (event.Type == UIEVENT_MOUSELEAVE)
		   {
			   m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSELEAVE);

		   }
		CButtonUI::DoEvent(event);
	}

	void CButtonExUI::SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue)
	{
		if (_tcscmp(pstrName, _T("iconimage")) == 0) SetIconImage(pstrValue);
		else CButtonUI::SetAttribute(pstrName, pstrValue);
	}

	void CButtonExUI::CleanInfo()
	{
		this->SetText(L"");
		this->SetToolTip(L"");
		this->SetUserData(L"");
		this->SetEnabled(false);
	}

	void CButtonExUI::SetTitle(DWORD y, DWORD m, DWORD d)
	{
		CDuiString strText;
		strText.Format(L"%d", d);
		this->SetText(strText);
		strText.Format(L"%d-%d-%d", y, m, d);
		this->SetUserData(strText);
		this->SetEnabled(true);
	}
	void CButtonExUI::PaintStatusImage(HDC hDC)
	{
		CButtonUI::PaintStatusImage(hDC);

		RECT rcItem = m_rcItem;

		if ((m_uButtonState & UISTATE_PUSHED) != 0)
			::OffsetRect(&m_rcItem, 1, 1);

		if (!m_strIconImage.IsEmpty())
		{
			TDrawInfo diBk;
			diBk.sDrawString = m_strIconImage.GetData();
			if (!DrawImage(hDC, diBk)) m_strIconImage.Empty();
		}

		m_rcItem = rcItem;
	}

} // namespace DuiLib