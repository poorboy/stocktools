#include "StdAfx.h"
#include "HotKeyUI.h"

namespace DuiLib {
	

	CHotKeyUI::CHotKeyUI()
	{
		bIsSet = false;
		dwHotKey = 0;
		chKey = 0;

		m_uTextStyle = DT_SINGLELINE | DT_CENTER | DT_VCENTER;
	}

	CHotKeyUI::~CHotKeyUI()
	{

	}

	LPCTSTR CHotKeyUI::GetClass()const
	{
		return L"CHotKeyUI";
	}

	void CHotKeyUI::UpKeyInfo(TEventUI& event)
	{
		m_sText = L"";

		dwHotKey = 0;
		chKey = 0;

		if (::GetAsyncKeyState(VK_CONTROL) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"Ctrl");
			dwHotKey |= MOD_CONTROL;
		}
		if (::GetAsyncKeyState(VK_SHIFT) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"Shift");
			dwHotKey |= MOD_SHIFT;
		}
		if (::GetAsyncKeyState(VK_MENU) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"Alt");
			dwHotKey |= MOD_ALT;
		}	if (::GetAsyncKeyState(VK_LEFT) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"<");
			chKey = VK_LEFT;
		}

		if (::GetAsyncKeyState(VK_RIGHT) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L">");
			chKey = VK_RIGHT;
		}
		if (::GetAsyncKeyState(VK_UP) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"��");
			chKey = VK_UP;
		}
		if (::GetAsyncKeyState(VK_DOWN) & 0x8000)
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");
			m_sText.Append(L"��");
			chKey = VK_DOWN;
		}
		if (iswalnum(event.chKey) || iswalpha(event.chKey))
		{
			if (m_sText.GetLength() > 0) m_sText.Append(L"+");

			chKey = event.chKey;
			m_sText += event.chKey;
		}

		if (event.Type == UIEVENT_KEYUP)
		{
			bIsSet = RegisterHotKey(m_pManager->GetPaintWindow(), WM_USER + 58000, dwHotKey, chKey);
			if (!bIsSet)
			{
				m_sText = L"��";
				dwHotKey = 0;
				chKey = 0;
			}
			else
			{
				UnregisterHotKey(m_pManager->GetPaintWindow(), WM_USER + 58000);
			}
		}
		if (m_sText.GetLength() < 1) m_sText = L"��";

		Invalidate();
	}
	void CHotKeyUI::DoEvent(TEventUI& event)
	{
		CTextUI::DoEvent(event);
		if (event.Type == UIEVENT_BUTTONUP) ShowCaret(event);   
		if (event.Type == UIEVENT_KILLFOCUS) HideCaret();
		if (event.Type == UIEVENT_KEYDOWN) UpKeyInfo(event); 
		if (event.Type == UIEVENT_KEYUP) UpKeyInfo(event);  
		if (event.Type == UIEVENT_SETCURSOR) ::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_IBEAM)));
		
		//CEditUI
	}

	bool CHotKeyUI::GetKeyInfo(DWORD &_dwHotKey, WCHAR &_chKey)
	{
		if (bIsSet)
		{
			_chKey = chKey;
			_dwHotKey = dwHotKey;
		} 
		return bIsSet;
	}
	void CHotKeyUI::ShowCaret(TEventUI& event)
	{
		strOldStr = m_sText;
		TEXTMETRIC tm;
		HWND hWnd = m_pManager->GetPaintWindow();
	 	if (!bShowCaret) CreateCaret(hWnd, NULL, 2, (m_rcItem.bottom - m_rcItem.top) - 4); 
		POINT pt = event.ptMouse;
		AdusyCaretPos(pt, m_rcItem);
		SetCaretPos(pt.x, pt.y);
		::ShowCaret(hWnd);
		bShowCaret = true;
		this->Invalidate();
	}
	void CHotKeyUI::AdusyCaretPos(POINT &pt, RECT &rc)
	{
		TEXTMETRIC tm;
		HWND hWnd = m_pManager->GetPaintWindow();
		GetTextMetrics(GetDC(hWnd), &tm);
		int cxChar = tm.tmAveCharWidth;
		int cyChar = tm.tmHeight;

		int nLen = m_sText.GetLength();
		int nMaxLen = nLen * cxChar;
		int nLeft = rc.left + 5;
		int nRight = nLeft +   nMaxLen;
		pt.y = rc.top;
		if (pt.x <= nLeft) pt.x = nLeft;
		else if (pt.x >= nRight) pt.x = nRight;

	}
	void CHotKeyUI::HideCaret()
	{ 
		bShowCaret = false;
		DestroyCaret(); 
		this->Invalidate();
	}

} // namespace DuiLib