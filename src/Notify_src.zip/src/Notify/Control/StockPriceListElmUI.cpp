#include "StdAfx.h"
#include "StockPriceListElmUI.h"

#define  APPLYATTRIBUTELIST(X, Y) if(X) X->SetAttributeList(Y);
#define  ADCON2CON(X,Y) if(X&&Y) X->Add(Y);
#define  SET_CONTOR_TXT(X,Y) if(X) X->SetText(Y);
#define  GET_CONTOR_TXT(X,Y) if(X) Y = X->GetText();
#define  SET_CONTOR_VISIBLE(X,Y) if(X) X->SetVisible(Y);

#define  ADD_X_SPACE(X,Y)					\
if(X)										\
{											\
	CControlUI *pCont = new CControlUI;		\
	if (pCont) pCont->SetFixedWidth(Y);		\
	ADCON2CON(X, pCont);					\
}


namespace DuiLib {
	StockPriceListElmUI::StockPriceListElmUI()
	{
		SetFixedHeight(25);

		pEtPrice = new CEditUI;
		pEtNumber = new CEditUI;
		pEtTime = new CEditUI;
		pbntTime = new CButtonUI;



		pHor0 = new CHorizontalLayoutUI;
		pHorTime = new CHorizontalLayoutUI;
		pHorBnt = new CHorizontalLayoutUI;
		pHorNumber = new CHorizontalLayoutUI;

		APPLYATTRIBUTELIST(pHor0, L"inset=\"5,0,0,0\" ");
		APPLYATTRIBUTELIST(pHorTime, L"inset=\"5,0,0,0\" width=\"150\" ");
		APPLYATTRIBUTELIST(pHorBnt, L"inset=\"5,0,0,0\"");
		APPLYATTRIBUTELIST(pHorNumber, L"inset=\"5,0,0,0\" width=\"265\" ");

		pBntAdd = new CButtonUI;
		pBntDel = new CButtonUI;

		APPLYATTRIBUTELIST(pBntAdd, L"width=\"18\" height=\"18\" tooltip=\"����\" normalimage=\"file='add_bg.png' source='0,0,18,18'\" hotimage=\"file='add_bg.png' source='18,0,36,18'\" ");

		APPLYATTRIBUTELIST(pBntDel, L"width=\"12\" height=\"12\" tooltip=\"ɾ��\" normalimage=\"file='del_btn.png' source='0,0,12,12'\" hotimage=\"file='del_btn.png' source='12,0,24,12'\" ");

		ADCON2CON(pHorTime, pEtTime);
		ADD_X_SPACE(pHorTime, 5);
		ADCON2CON(pHorTime, pbntTime);
		ADD_X_SPACE(pHorTime, 5);

		pHorTime->SetFixedHeight(25);

		ADCON2CON(pHorNumber, pEtPrice);
		ADD_X_SPACE(pHorNumber, 5);
		ADCON2CON(pHorNumber, pEtNumber);
		ADD_X_SPACE(pHorNumber, 5);
		ADCON2CON(pHorNumber, pHorTime);

		ADCON2CON(pHorBnt, pBntAdd);
		ADD_X_SPACE(pHorBnt, 5);
		ADCON2CON(pHorBnt, pBntDel);
		ADD_X_SPACE(pHorBnt, 5);

		ADCON2CON(pHor0, pHorNumber);
		ADD_X_SPACE(pHor0, 5);
		ADCON2CON(pHor0, pHorBnt);

		APPLYATTRIBUTELIST(pEtPrice, L"text=\"0\" height=\"20\" width=\"50\" bkcolor=\"#FFFFFFFF\" bordersize=\"1\" bordercolor=\"0xffd1d1d1\" textcolor=\"#FF000000\" disabledtextcolor=\"#FFA7A6AA\" ");

		APPLYATTRIBUTELIST(pEtNumber, L"text=\"0\" height=\"20\" numberonly=\"true\" width=\"65\" bkcolor=\"#FFFFFFFF\" bordersize=\"1\" bordercolor=\"0xffd1d1d1\" textcolor=\"#FF000000\" disabledtextcolor=\"#FFA7A6AA\" ");

		APPLYATTRIBUTELIST(pEtTime, L"text=\"0\" height=\"20\" readonly=\"true\" width=\"100\" bkcolor=\"#FFFFFFFF\" bordersize=\"1\" bordercolor=\"0xffd1d1d1\" textcolor=\"#FF000000\" disabledtextcolor=\"#FFA7A6AA\" ");

		APPLYATTRIBUTELIST(pbntTime, L"width=\"18\" height=\"18\" tooltip=\"����\" normalimage=\"query.png\" hotimage=\"query.png\" ");

		ADCON2CON(this, pHor0);
		SET_CONTOR_VISIBLE(pHorBnt, false);
		SetBntAction();
	}

	LPCTSTR StockPriceListElmUI::GetClass()const
	{
		return L"StockPriceListElmUI";
	}

	StockPrice StockPriceListElmUI::GetSoctkPriceData(void)
	{
		StockPrice priceData;
		CDuiString strTmp;
		GET_CONTOR_TXT(pEtPrice, strTmp);
		priceData.duPrice = _ttof(strTmp.GetData());
		GET_CONTOR_TXT(pEtNumber, strTmp);
		priceData.nCount = _tstoi(strTmp.GetData());
		GET_CONTOR_TXT(pEtTime, strTmp);
		priceData.addTime = strTmp.GetData();
		return priceData;
	}

	void StockPriceListElmUI::SetStockPriceData(StockPrice &priceData)
	{
		CDuiString strTmp;
		strTmp.Format(L"%.02f", priceData.duPrice);
		SET_CONTOR_TXT(pEtPrice, strTmp.GetData());
		strTmp.Format(L"%d", priceData.nCount);
		SET_CONTOR_TXT(pEtNumber, strTmp.GetData());
		SET_CONTOR_TXT(pEtTime, priceData.addTime.c_str());
	}

	void StockPriceListElmUI::SetTime(CDuiString &strTime)
	{
		SET_CONTOR_TXT(pEtTime, strTime.GetData());
	}

	void StockPriceListElmUI::ReSetData()
	{
		SET_CONTOR_TXT(pEtPrice, L""); 
		SET_CONTOR_TXT(pEtNumber, L"");
		SET_CONTOR_TXT(pEtTime, L"");
	}

	void StockPriceListElmUI::SetBntAction()
	{
		pBntAdd->OnNotify += MakeDelegate(this, &StockPriceListElmUI::OnClickAdd);
		pBntDel->OnNotify += MakeDelegate(this, &StockPriceListElmUI::OnClickDel);
		pbntTime->OnNotify += MakeDelegate(this, &StockPriceListElmUI::OnClickTime);
	}

	bool StockPriceListElmUI::OnClickAdd(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("AddSock"));
			return true;
		}
		return false;
	}

	bool StockPriceListElmUI::OnClickDel(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("DelSock"), nIndex);
			return true;
		}
		return false;
	}

	bool StockPriceListElmUI::OnClickTime(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("Time"), nIndex);
			return true;
		}
		return false;
	}

	void StockPriceListElmUI::DoEvent(TEventUI& event)
	{
		CListContainerElementUI::DoEvent(event);


		if (event.Type == UIEVENT_MOUSEENTER)
		{
			SET_CONTOR_VISIBLE(pHorBnt, true);
		}
		if (event.Type == UIEVENT_MOUSELEAVE)
		{
			SET_CONTOR_VISIBLE(pHorBnt, false);
		}
	}
} // namespace DuiLib

