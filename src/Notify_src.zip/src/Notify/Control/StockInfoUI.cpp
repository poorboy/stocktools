#include "StdAfx.h"
#include "StockInfoUI.h"

namespace DuiLib {
	StockLineUI::StockLineUI()
	{
		bDrawCloss = false;
	}

	StockLineUI::~StockLineUI()
	{

	}

	void StockLineUI::DrawVTitle(HDC hDC, double duMin, double duMax)
	{
		return;
		RECT rc = m_rcItem;
		rc.top = nYFix; 

		double duTMp = duMin; 
		double du = 20.000 / (double)nYStep;
		du /= 100;
		duTMp -= du;
		
		do
		{
			rc.bottom = rc.top;
			rc.top = rc.bottom - 20;
			m_sText.Format(L"%.02f", duTMp);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, DT_SINGLELINE | DT_LEFT);
			duTMp += du;
			if (rc.top < 40) break;
		} while (1);
	}

	void StockLineUI::DrawHTitle(HDC hDC)
	{

	}

	void StockLineUI::DrawTitle(HDC hDC, double duMin, double duMax)
	{
		RECT rc = m_rcItem;
		UINT uTextStyle = DT_SINGLELINE | DT_CENTER;

		do
		{
			if (!bDrawCloss) break;
			if (nXStep < 1) break;

			int nInx = pt.x - 35;
			nInx /= nXStep;

			if (nInx < 0) break;
			if (nInx >= g_DayData._vctP.size())break;

			rc = m_rcItem;
			rc.top += 10;
			rc.bottom = rc.top + 20;
			rc.left = rc.right - 200;

			m_sText.Format(L"ʱ��:%s", g_DayData[nInx].time.GetTimeStr().c_str());
			m_sText = m_sText.Left(8);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);

			rc.top = rc.bottom;
			rc.bottom = rc.top + 20;
			m_sText.Format(L"�ּ�:%.02f", g_DayData[nInx].dP);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);

			rc.top = rc.bottom;
			rc.bottom = rc.top + 20;
			m_sText.Format(L"����:%0.2f", g_DayData[nInx].dAvg);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);

			rc.top = rc.bottom;
			rc.bottom = rc.top + 20;
			m_sText.Format(L"�ܽ��:%d", g_DayData[nInx].nAllM);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);
			
			rc.top = rc.bottom;
			rc.bottom = rc.top + 20;
			m_sText = L"��   �� ��  ���";
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);
 
			SecondItem item;
			DWORD cr = RGB(0, 0, 0);
			for (size_t i = 0; i < g_DayData[nInx]._vctP.size(); i++)
			{
				rc.top = rc.bottom;
				rc.bottom = rc.top + 20;

				if (rc.bottom > m_rcItem.bottom) break;

				item = g_DayData[nInx]._vctP[i];
				m_sText.Format(L"%02d:  %0.2f  %d %d"
					, item.time.GetSecond()
					, item.dP
					, item.uCount
					, item.nAllM
				);

				if (item.uAtrr == 1)      cr = RGB(0, 0, 255);
				else if (item.uAtrr == 2) cr = RGB(0, 255, 0);
				else if (item.uAtrr == 3) cr = RGB(0, 0, 0);
				CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, cr, 0, uTextStyle);

			}

		} while (0);
	}

	void StockLineUI::ClacStep(double duMin, double duMax)
	{
		int nH = m_rcItem.bottom - m_rcItem.top;
		int nW = (m_rcItem.right - m_rcItem.left) - 35;

		nXStep = 0;
		if (nSize > 0) nXStep = nW / nSize;

		int nStart = duMin * 100;
		int nEnd = duMax * 100;
		int nAll = nEnd - nStart; 

		int nH1 = (nH - 40) / 3;
		nYFix = m_rcItem.bottom - nH1;
		nH1 *= 2;
		nYStep = 0;
		if(nAll > 0) nYStep = nH1 / nAll;
	}

	void StockLineUI::DrawTime(HDC hDC)
	{
		RECT rc = m_rcItem;
		CTimeEx time = CTimeEx(CTimeEx::GetCurrentTime().ToString().c_str());
		time.AddHour(9);
		for (int i = 0; i < 9; i++)
		{
			time.AddMinute(30);
			rc.top = nYFix;
			rc.bottom = nYFix + 20;
			rc.left = 35 + (i * 30 * nXStep);
			rc.left -= 30;
			rc.right = rc.left + 30;
			m_sText = time.GetTimeStr().c_str();
			m_sText = m_sText.Left(5);
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, DT_SINGLELINE | DT_CENTER);
			
			if (time.GetHour() == 11 && time.GetMinute() == 30) time.AddMinute(90);

		}
	}

	void StockLineUI::DrawBox(HDC hDC)
	{
		RECT rc = m_rcItem; 
		UINT uTextStyle = DT_SINGLELINE | DT_CENTER;

		rc.top += 10;
		rc.bottom = nYFix;
		rc.left = 35;
		rc.right = 35 + (nXStep*nSize);
		CRenderEngine::DrawRect(hDC, rc, 1, RGB(0, 0, 0));
		
		int nHight = rc.bottom - rc.top;
		nHight /= 8;

		RECT rc1 = rc;

		for (int x = 1; x < 8; x++)
		{
			rc1.left = 35 + (x * 30 * nXStep);
			rc1.right = rc1.left;
			CRenderEngine::DrawLine(hDC, rc1, 1, RGB(115, 115, 115), PS_DOT);
		}

		rc1 = rc;
		for (int x = 1; x < 8; x++)
		{
			rc1.top = 20 + (x*nHight);
			rc1.bottom = rc1.top;
			CRenderEngine::DrawLine(hDC, rc1, 1, RGB(115, 115, 115), PS_DOT);
		}

		rc = m_rcItem;
		rc.top = nYFix + 20;
		rc.left = 35;
		rc.right = 35 + (nXStep*nSize);
		CRenderEngine::DrawRect(hDC, rc, 1, RGB(0, 0, 0));

		rc1 = rc;
		for (int x = 1; x < 8; x++)
		{
			rc1.left = 35 + (x * 30 * nXStep);
			rc1.right = rc1.left;
			CRenderEngine::DrawLine(hDC, rc1, 1, RGB(115, 115, 115), PS_DOT);
		}

		DrawTime(hDC);
	}

	void StockLineUI::DrawMInfo(HDC hDC)
	{
		RECT rc = m_rcItem;
		DWORD dwCr = 0xFFFF0000;

		int nT = nYFix + 20;
		int nH = m_rcItem.bottom - nT;

		__int64 nMax = g_DayData.nMaxM;
		__int64 nCuuM = 0;
		double duTmp;

		for (int i = 0; i < nSize; i++)
		{
			rc.left = 35 + (nXStep*i);
			rc.right = rc.left + nXStep;

			nCuuM = g_DayData[i].nAllM;
			dwCr = 0xFFFF0000;
			if (nCuuM < 0)
			{
				nCuuM = abs(nCuuM);
				dwCr = 0xFF00FF00;
			}

			duTmp = (nCuuM * 100) / nMax;
			duTmp /= 100;

			if (duTmp > 1.000) duTmp = 1.000;
			duTmp *= nH;

			rc.top = rc.bottom - (int)(duTmp);
			CRenderEngine::DrawColor(hDC, rc, dwCr);
		}
	}

	void StockLineUI::InitLintPost()
	{
		if (vctPt.size() > 0) return;

		int nyPost = 0;
		for (int i = 0; i < nSize; i++)
		{
			pt.x = 35 + (nXStep*i);
			nyPost = (int)((g_DayData[i].dP - g_DayData.dMinP) * 100 * nYStep);
			pt.y = nYFix - nyPost;
			vctPt.push_back(pt);
		}
	}

	bool StockLineUI::DrawLine(HDC hDC)
	{
		bool bRet = false;
		do
		{
			if (g_DayData._vctP.size() < 4) break;

			nSize = g_DayData._vctP.size();
			int nSubSize = nSize % 3;

			if (nSubSize == 2) nSize -= 1;
			else if (nSubSize == 0) nSize -= 2;

			ClacStep(g_DayData.dMinP, g_DayData.dMaxp);

			if (nYStep < 1 || nXStep < 1) break;

			InitLintPost();

			DrawBox(hDC);
			DrawTitle(hDC, g_DayData.dMinP, g_DayData.dMaxp);
			DrawVTitle(hDC, g_DayData.dMinP, g_DayData.dMaxp);
			DrawHTitle(hDC);

			PolyBezier(hDC, (POINT*)(&vctPt[0]), vctPt.size());
			DrawMInfo(hDC);
			DrawCloss(hDC);
			bRet = true;
		} while (0);
		return bRet;
	}

	void StockLineUI::DrawCloss(HDC hDC)
	{
		if (!bDrawCloss) return;
		RECT rc = m_rcItem;
		rc.top = pt.y;
		rc.bottom = pt.y;

		CRenderEngine::DrawLine(hDC, rc, 1, RGB(0, 255, 0));

		rc = m_rcItem;
		rc.left = pt.x;
		rc.right = pt.x;
		CRenderEngine::DrawLine(hDC, rc, 1, RGB(0, 255, 0));
	}

	void StockLineUI::DrawTipInfo(HDC hDC)
	{
		UINT uTextStyle = DT_SINGLELINE | DT_VCENTER | DT_CENTER;
		RECT rc = m_rcItem;
		m_sText = L"��ȡ����ʧ��,�����������,��F5�������»�ȡ����.���ߵ�ǰ�����Ƿ�ڼ���";
		CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, 0, 0, uTextStyle);
	}

	void StockLineUI::PaintText(HDC hDC)
	{
		if(!DrawLine(hDC))
			DrawTipInfo(hDC);
	}

	void StockLineUI::UpData(SData &sData, CTimeEx &_time)
	{
		m_time = _time;
		_sData = sData;
		b_IsInit = (g_DayData._vctP.size() > 0);
		vctPt.clear();
		Invalidate();
	}

	void StockLineUI::DoEvent(TEventUI& event)
	{
		if (event.Type == UIEVENT_MOUSEMOVE)
		{
			pt = event.ptMouse;
			if (pt.x > 34 && pt.x < (35 + (nXStep*nSize))) bDrawCloss = true;
			else bDrawCloss = false;
			Invalidate();
		}
		else if (event.Type == UIEVENT_MOUSELEAVE)
		{
			bDrawCloss = false;
			Invalidate();
		}

		if (m_pParent != NULL) m_pParent->DoEvent(event);
	}

} // namespace DuiLib