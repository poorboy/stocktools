#include "StdAfx.h"
#include "StockListElmUI.h"

#define  APPLYATTRIBUTELIST(X, Y) if(X) X->SetAttributeList(Y);
#define  ADCON2CON(X,Y) if(X&&Y) X->Add(Y);
#define  SET_CONTOR_TXT(X,Y) if(X) X->SetText(Y);
#define  SET_CONTOR_VISIBLE(X,Y) if(X) X->SetVisible(Y);

#define  ADD_X_SPACE(X,Y)					\
if(X)										\
{											\
	CControlUI *pCont = new CControlUI;		\
	if (pCont) pCont->SetFixedWidth(Y);		\
	ADCON2CON(X, pCont);					\
}


namespace DuiLib {
	CStockListElmUI::CStockListElmUI()
	{
		SetFixedHeight(30);


		pCodeLbl = new CLabelUI;
		pNameLbl = new CLabelUI;
		pMinLbl = new CLabelUI;
		pMaxLbl = new CLabelUI;

		pNumberLbl = new CLabelUI;
		pMLbl = new CLabelUI;

		APPLYATTRIBUTELIST(pCodeLbl, L"width=\"70\"  textcolor=\"0xff333333\" ");
		APPLYATTRIBUTELIST(pNameLbl, L"width=\"50\"  textcolor=\"0xff333333\" ");
		APPLYATTRIBUTELIST(pMinLbl, L"width=\"50\"  textcolor=\"0xff333333\" ");
		APPLYATTRIBUTELIST(pMaxLbl, L"width=\"50\"  textcolor=\"0xff333333\" ");
		APPLYATTRIBUTELIST(pNumberLbl, L"width=\"50\"  textcolor=\"0xff333333\" ");
		APPLYATTRIBUTELIST(pMLbl, L"width=\"50\"  textcolor=\"0xff333333\" ");

		 
		pHor0 = new CHorizontalLayoutUI;
		pHor1 = new CHorizontalLayoutUI;
		pHor2 = new CHorizontalLayoutUI;

		APPLYATTRIBUTELIST(pHor0, L"inset=\"5,0,0,0\"");
		APPLYATTRIBUTELIST(pHor1, L"inset=\"5,0,0,0\"");
		APPLYATTRIBUTELIST(pHor2, L"inset=\"5,0,0,0\"");

		pBntAdd = new CButtonUI;
		pBntDel = new CButtonUI;
		pBntModify = new CButtonUI;

		pBntUp = new CButtonUI;
		pBntDown = new CButtonUI;

		APPLYATTRIBUTELIST(pBntAdd, L"width=\"18\" height=\"18\" tooltip=\"����\" normalimage=\"file='add_bg.png' source='0,0,18,18'\" hotimage=\"file='add_bg.png' source='18,0,36,18'\" ");

		APPLYATTRIBUTELIST(pBntDel, L"width=\"12\" height=\"12\" tooltip=\"ɾ��\" normalimage=\"file='del_btn.png' source='0,0,12,12'\" hotimage=\"file='del_btn.png' source='12,0,24,12'\" ");

		APPLYATTRIBUTELIST(pBntModify, L"width=\"12\" height=\"12\" tooltip=\"�޸�\" normalimage=\"file='detail.png' source='0,0,12,12'\" hotimage=\"file='detail.png' source='12,0,24,12'\"");


		APPLYATTRIBUTELIST(pBntUp, L"width=\"12\" height=\"12\" tooltip=\"�޸�\" normalimage=\"file='bntUp.png' source='0,0,12,12'\" hotimage=\"file='bntUp.png' source='12,0,24,12'\"");

		APPLYATTRIBUTELIST(pBntDown, L"width=\"12\" height=\"12\" tooltip=\"�޸�\" normalimage=\"file='bntDown.png' source='0,0,12,12'\" hotimage=\"file='bntDown.png' source='12,0,24,12'\"");

		ADCON2CON(pHor1, pCodeLbl);
		ADD_X_SPACE(pHor1, 5);
		ADCON2CON(pHor1, pNameLbl);
		ADD_X_SPACE(pHor1, 5);
		ADCON2CON(pHor1, pMinLbl);
		ADD_X_SPACE(pHor1, 5);
		ADCON2CON(pHor1, pMaxLbl);
		ADD_X_SPACE(pHor1, 5);
		ADCON2CON(pHor1, pNumberLbl);
		ADD_X_SPACE(pHor1, 5);
		ADCON2CON(pHor1, pMLbl);

		
		ADD_X_SPACE(pHor2, 5);
		ADCON2CON(pHor2, pBntAdd);
		ADD_X_SPACE(pHor2, 5);
		ADCON2CON(pHor2, pBntModify);
		ADD_X_SPACE(pHor2, 5);
		ADCON2CON(pHor2, pBntUp);
		ADD_X_SPACE(pHor2, 5);
		ADCON2CON(pHor2, pBntDown);
		ADD_X_SPACE(pHor2, 5);
		ADCON2CON(pHor2, pBntDel);

		ADCON2CON(pHor0, pHor1);
		ADCON2CON(pHor0, pHor2);
		ADCON2CON(this, pHor0);
		SET_CONTOR_VISIBLE(pHor2, false);
		SetBntAction();
	}

	LPCTSTR CStockListElmUI::GetClass()const
	{
		return L"CStockListElmUI";
	}


	void CStockListElmUI::SetStockData(int inx)
	{
		nIndex =  inx;

		if (nIndex >= 0 && g_sData.size() > 0)
		{
			_SData &SItem = g_sData[nIndex];
			CDuiString strTmp;

			SET_CONTOR_TXT(pCodeLbl, SItem.SNO.c_str());
			if (SItem.vctFd.size() > 0)
			{
				SET_CONTOR_TXT(pNameLbl, SItem.vctFd[0].c_str());
			}

			if (SItem.MinP > 0.0000001)
			{
				strTmp.Format(L"%.02f", SItem.MinP);
				SET_CONTOR_TXT(pMinLbl, strTmp.GetData());
			}

			if (SItem.MaxP > 0.0000001)
			{
				strTmp.Format(L"%.02f", SItem.MaxP);
				SET_CONTOR_TXT(pMaxLbl, strTmp.GetData());
			}

			if (SItem.dwAllNumber < 100) return;

			strTmp.Format(L"%d", SItem.dwAllNumber);
			SET_CONTOR_TXT(pNumberLbl, strTmp.GetData());
			
			strTmp.Format(L"%.02f", SItem.duFy);
			SET_CONTOR_TXT(pMLbl, strTmp.GetData()); 
		}
	}

	void CStockListElmUI::SetBntAction()
	{
		pBntAdd->OnNotify += MakeDelegate(this, &CStockListElmUI::OnClickAdd);
		pBntDel->OnNotify += MakeDelegate(this, &CStockListElmUI::OnClickDel);
		pBntModify->OnNotify += MakeDelegate(this, &CStockListElmUI::OnClickModify);
		pBntUp->OnNotify += MakeDelegate(this, &CStockListElmUI::OnClickUp);
		pBntDown->OnNotify += MakeDelegate(this, &CStockListElmUI::OnClickDown);
	}

	bool CStockListElmUI::OnClickAdd(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("AddSock"));
			return true;
		}
		return false;
	}

	bool CStockListElmUI::OnClickDel(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("DelSock"), nIndex);
			return true;
		}
		return false;
	}

	bool CStockListElmUI::OnClickModify(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			m_pManager->SendNotify(this, _T("ModSock"), nIndex);
			return true;
		}
		return false;
	}

	bool CStockListElmUI::OnClickUp(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			if (nIndex > 0)
			{
				m_pManager->SendNotify(this, _T("Up"), nIndex);

				_SData tItem = g_sData[nIndex];
				g_sData[nIndex --] = g_sData[nIndex]; 
				g_sData[nIndex] = tItem;
			}
			return true;
		}
		return false;
	}

	bool CStockListElmUI::OnClickDown(void* param)
	{
		TNotifyUI* pTNotifyUI = (TNotifyUI*)param;
		if (pTNotifyUI->sType == DUI_MSGTYPE_CLICK)
		{
			if (nIndex < g_sData.size())
			{
				m_pManager->SendNotify(this, _T("Down"), nIndex);

				_SData tItem = g_sData[nIndex];
				g_sData[nIndex ++] = g_sData[nIndex];
				g_sData[nIndex] = tItem; 
			}
			return true;
		}
		return false;
	}

	void CStockListElmUI::DoEvent(TEventUI& event)
	{
		CListContainerElementUI::DoEvent(event);


		if (event.Type == UIEVENT_MOUSEENTER)
		{
			SET_CONTOR_VISIBLE(pHor2, true);
		}
		if (event.Type == UIEVENT_MOUSELEAVE)
		{
			SET_CONTOR_VISIBLE(pHor2, false);
		}
	}


} // namespace DuiLib

