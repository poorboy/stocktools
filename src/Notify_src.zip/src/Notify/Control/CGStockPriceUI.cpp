#include "StdAfx.h"
#include "CGStockPriceUI.h"
#include "../Utils/CTimeEx.h"
#include "../DataDef/CommData.h"

namespace DuiLib {

	CStockGPriceUI::CStockGPriceUI()
	{
		vctTitle.push_back(L"����");
		vctTitle.push_back(L"����");
		vctTitle.push_back(L"�ּ�");
		vctTitle.push_back(L"����");
		vctTitle.push_back(L"�ܵ���");
		vctTitle.push_back(L"��ӯ");
		vctTitle.push_back(L"����");
		m_hwndForegWnd = NULL;
	}

	CStockGPriceUI::~CStockGPriceUI()
	{

	}

	void CStockGPriceUI::AdusyWndSize()
	{
		do
		{
			if (!m_pManager) break;
			HWND h_wnd = m_pManager->GetPaintWindow();
			if (!h_wnd) break;
			RECT rcWnd = { 0 };
			if (!GetWindowRect(h_wnd, &rcWnd)) break;

			int nHight = g_sData.size() * 20;
			nHight += g_Groub.size() * 20;
			nHight += 55;
			if (_set.IsNeedShow()) nHight += 30;
			//if (!IsWindTrans()) nHight += 20;

			int WindWidth = rcWnd.right - rcWnd.left;
			int WindHight = rcWnd.bottom - rcWnd.top;

			int nWidth = 0;
			int nCol = (_set.IsNeedShow() ? 7 : 4);
			for (int i = 0; i < nCol; i++)
			{
				nWidth += colmWidth[i];
				nWidth += 5;
			}

			bool bIsSet = false;

			if (WindWidth != nWidth)
			{
				rcWnd.right = rcWnd.left + nWidth;
				bIsSet = true;
			}

			if (WindHight != nHight)
			{
				rcWnd.bottom = rcWnd.top + nHight;
				bIsSet = true;
			}

			if (bIsSet)
			{
				m_pManager->SetMinInfo(rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top);
				//m_pManager->SendNotify(this, L"SetMINSIZE", rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top);
				SetWindowPos(h_wnd, NULL, rcWnd.left, rcWnd.top, rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top, SWP_NOMOVE);
			}

		} while (0);
	}

	SIZE CStockGPriceUI::GetTextSize(HDC hDC)
	{
		SIZE sz;
		::GetTextExtentPoint32(hDC, m_sText, m_sText.GetLength(), &sz);
		return sz;
	}

	RECT CStockGPriceUI::GetItemRect()
	{
		RECT rc = m_rcItem;
		rc.top += 5;
		rc.left += 5;
		rc.right -= 5;
		if (IsWindTrans()) rc.bottom -= 20;
		return rc;
	}

	bool CStockGPriceUI::IsWindTrans(void)
	{
		bool bRet = false;
		do
		{
			if (!m_pManager) break;
			HWND h_wnd = m_pManager->GetPaintWindow();
			if (!h_wnd) break;
			DWORD dwExStyle = ::GetWindowLong(h_wnd, GWL_EXSTYLE);
			bRet = (dwExStyle & WS_EX_TRANSPARENT);
		} while (0);

		return bRet;
	}

	void CStockGPriceUI::DrawTitle(HDC hDc, int nStep)
	{
		RECT rc = GetItemRect();
		RECT rcItem = rc;

		if ((rcItem.bottom - rcItem.top) > 20)
			rcItem.bottom = 20 + rcItem.top;

		UINT uTextStyle = DT_SINGLELINE | DT_CENTER;
		int nCol = (_set.IsNeedShow() ? vctTitle.size() : 4);
		for (int i = 0; i < nCol; i++)
		{
			GetTextRect(rcItem, i, uTextStyle, nStep);
			m_sText = vctTitle[i];
			//if ((i == 0) && (false ==IsWindTrans())) m_sText.Format(L"��%s��", vctTitle[0]);
			CRenderEngine::DrawText(hDc, m_pManager, rcItem, m_sText, 0, 0, uTextStyle);
		}
	}

	void CStockGPriceUI::GetItemText1(int inx, SData &item)
	{
		switch (inx)
		{
		case 0:
			m_sText = item.vctFd[0].c_str();
			break;
		case 1:
			m_sText.Format(L"%.02f", item.duOp);
			break;
		case 2:
			m_sText.Format(L"%.02f", item.duCp);
			break;
		case 3:
			m_sText.Format(L"%.02f", item.duXp);
			break;
		default:
			break;
		}
	}

	void CStockGPriceUI::GetItemText(int inx, SData &item)
	{
		m_sText = L"";
		if (item.vctFd.size() < 1)
		{
			if (inx == 0) m_sText = item.SNO.substr(2).c_str();
			else if (inx < 4) m_sText = L"--";
			return;
		}

		GetItemText1(inx, item);

		if (_set.IsNeedShow())
		{
			switch (inx)
			{
			case 4:
				m_sText.Format(L"%.02f", item.duZdf);
				break;
			case 5:
				m_sText.Format(L"%d", item.profit);
				break;
			case 6:
				m_sText.Format(L"%.02f", item.duFy);
				break;
			default:
				break;
			}
		}

		if (inx > 3 && item.vctSPrice.size() < 1) m_sText = L"";

		//item.dwColor = SData::dwCrMin;
		//if (item.duCp > item.duOp) item.dwColor = SData::dwCrMax;
		//if ((inx == 4) && (item.profit < 0))  item.dwColor = SData::dwCrMin;
		//if ((inx == 5) && (item.duZdf < 0))  item.dwColor = SData::dwCrMin;
	}

	void CStockGPriceUI::GetTextRect(RECT &rc, int inx, UINT &uTextStyle, int nStep)
	{
		if (inx == 0)
		{
			rc.right = rc.left + colmWidth[inx]; 
			uTextStyle = DT_SINGLELINE | DT_CENTER | DT_VCENTER;
			return;
		}

		uTextStyle = DT_SINGLELINE | DT_RIGHT | DT_VCENTER;
		rc.left = rc.right + nStep;
		rc.right = rc.left + colmWidth[inx];// +nStep;DT_RIGHT DT_LEFT
	}

	void CStockGPriceUI::DrawBk(HDC hDc, SData &item, int nInx)
	{
		do 
		{

			RECT rc = item.vctRc[0];
			if (nHotIndex == nInx)
			{
				if (IsWindTrans()) break;
				CRenderEngine::DrawColor(hDc, rc, 0xFFA6CADB);
				break;
			}
			//CRenderEngine::DrawRect(hDc, rc, 1, item.GetItemBkColor());
			CRenderEngine::DrawColor(hDc, rc, item.GetItemBkColor());
		} while (0); return; 
		//0xFFA6CADB  0xFFE9F5FF 
	}

	void CStockGPriceUI::DrawTextBox(HDC hDc, RECT rc)
	{
		rc.top -= 2;
		rc.bottom -= 4;
		CRenderEngine::DrawColor(hDc, rc, 0xFF000000);
		CRenderEngine::DrawRect(hDc, rc, 1, RGB(0, 0, 0), 0);
		rc.left += 5;
		rc.top += 3;
		m_sText = strBuffer;
		nTextSize = GetTextSize(hDc).cx;
		CRenderEngine::DrawText(hDc, m_pManager, rc, strBuffer, 0xFFFFFF, 0, DT_SINGLELINE | DT_LEFT);
	}

	void CStockGPriceUI::DrawTexeItem(HDC hDc, RECT rc, int inx, int nStep)
	{
		RECT rcItem = rc;
		if ((rcItem.bottom - rcItem.top) > 20)
			rcItem.bottom = 20 + rcItem.top;

		SData &item = g_sData[inx];
		item.vctRc.clear();
		item.vctRc.push_back(rcItem);
		//item.vctRc[0].bottom = item.vctRc[0].top + 20;
		UINT uTextStyle = DT_SINGLELINE | DT_CENTER  | DT_VCENTER;

		int nCol = (_set.IsNeedShow() ? 7 : 4);
		DrawBk(hDc, item, inx);
		for (int i = 0; i < nCol; i++)
		{
			if (item.vctSPrice.size() < 1 && i > 3) continue;
			GetTextRect(rcItem, i, uTextStyle, nStep);
			GetItemText(i, item);
			item.vctRc.push_back(rcItem);
			//item.vctRc[i + 1].bottom = item.vctRc[i + 1].top + 20;
			if (nIndex == inx && i == 0)
			{
				DrawTextBox(hDc, item.vctRc[i + 1]);
				continue;
			}

			CRenderEngine::DrawText(hDc, m_pManager, rcItem, m_sText, item.GetTxtColor(), 0, uTextStyle);
		}
	}

	void CStockGPriceUI::GetClomWidth(HDC hDC)
	{
		colmWidth.clear();
		for (int i = 0; i < 7; i++)
		{
			m_sText = vctTitle[i];
			colmWidth.push_back(GetTextSize(hDC).cx);
		}

		for (int i = 0; i < g_sData.size(); i++)
		{
			for (int j = 0; j < 7; j++)
			{
				GetItemText(j, g_sData[i]);
				colmWidth[j] = max(colmWidth[j], GetTextSize(hDC).cx);
			}
		}
	}

	int CStockGPriceUI::GetStepWidth()
	{
		RECT rc = GetItemRect();
		int nWidth = rc.right - rc.left;
		int txtWidth = 0;
		int nSetp = 0;

		for (int i = 0; i < 7; i++) txtWidth += colmWidth[i];

		if (txtWidth < nWidth) nSetp = (nWidth - txtWidth) / 6;

		return nSetp;
	}

	void CStockGPriceUI::DrawTotal(HDC hDC, RECT rc, int nStep, int nTotal, double nTotal2)
	{
		if (!_set.IsNeedShow()) return;

		RECT rcItem = rc;
		DWORD cr = _SData::dwCrMaxEx;
		double duTme = nTotal - nTotal2;
		//duTme -= nTotal;
		if (duTme < 0.000001) cr = _SData::dwCrMinEx;

		UINT uTextStyle = DT_SINGLELINE | DT_CENTER | DT_VCENTER;
		GetTextRect(rcItem, 0, uTextStyle, nStep);
		m_sText = L"�ܼ�:";
		CRenderEngine::DrawText(hDC, m_pManager, rcItem, m_sText, cr, 0, uTextStyle);


		GetTextRect(rcItem, 1, uTextStyle, nStep);
		rcItem.right += colmWidth[2];
		rcItem.right += nStep;
		m_sText.Format(L"%.02f", duTme);
		uTextStyle = DT_SINGLELINE | DT_CENTER | DT_VCENTER;
		CRenderEngine::DrawText(hDC, m_pManager, rcItem, m_sText, cr, 0, uTextStyle);


		for (int i = 3; i < 5; i++) GetTextRect(rcItem, i, uTextStyle, nStep);

		uTextStyle = DT_SINGLELINE | DT_RIGHT;
		GetTextRect(rcItem, 5, uTextStyle, nStep);
		m_sText.Format(L"%d", nTotal);
		CRenderEngine::DrawText(hDC, m_pManager, rcItem, m_sText, cr, 0, uTextStyle);

		GetTextRect(rcItem, 6, uTextStyle, nStep);
		m_sText.Format(L"%.02f", nTotal2);
		CRenderEngine::DrawText(hDC, m_pManager, rcItem, m_sText, cr, 0, uTextStyle);
	}

	void CStockGPriceUI::PaintText(HDC hDC)
	{
		RECT rc = GetItemRect();

		if (g_sData.size() < 1)
		{
			return;
		}

		GetClomWidth(hDC);
		int nStep = GetStepWidth();
		AdusyWndSize();

		int nTotal = 0;
		double nTotal2 = 0;
		if (!IsWindTrans()) DrawTitle(hDC, nStep);
		rc.top += 20;

		DWORD cr = _SData::dwCrMaxEx;

		for (int i = 0; i < g_sData.size(); i++)
		{
			DrawTexeItem(hDC, rc, i, nStep);
			if (g_sData[i].vctSPrice.size() > 0)
			{
				nTotal += g_sData[i].profit;
				nTotal2 += g_sData[i].duFy;
			}
			rc.top += 20;
		}
		
		map<wstring, vector<SData>> ::iterator itr = g_Groub.begin();
		int i = 1;

		rc.top -= 30;
		int nSize = g_sData.size();
		for (itr; itr != g_Groub.end(); ++itr)
		{
			//DrawGroubTexeItem(hDC, rc, itr, nSize+i,0, nStep);
			i++;
			rc.top += 30;
		}

		//rc.top -= 30;
		DrawTotal(hDC, rc, nStep, nTotal, nTotal2);

		//if (IsWindTrans())
		//{
		//	rc.bottom = m_rcItem.bottom;
		//	rc.top = rc.bottom - 20;
		//	DrawTime(hDC, rc);
		//}
		//AdusyWndSize();
	}

	void CStockGPriceUI::DrawTime(HDC hDC, RECT rc)
	{
		do
		{
			if (g_sData.size() < 1) break;
			vector<wstring> &strVct = g_sData.at(0).vctFd;
			int nSize = strVct.size();
			if (nSize < 1) break;
			m_sText.Format(L" ����ʱ��[%s %s]��ǰʱ��[%s]"
				, strVct[nSize - 2].c_str()
				, strVct[nSize - 1].c_str()
				, CTimeEx::GetCurrentTime().GetTimeStr().c_str());
			CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, RGB(0, 0, 0), 0, DT_SINGLELINE | DT_VCENTER | DT_CENTER);

		} while (0);
	}

	void CStockGPriceUI::ShowCaret(TEventUI& event)
	{
		TEXTMETRIC tm;
		HWND hWnd = m_pManager->GetPaintWindow();
		SetWindAttrib(hWnd, false);
		m_hwndForegWnd = GetForegroundWindow();
		::SetForegroundWindow(hWnd);
		::SetFocus(hWnd);
		GetTextMetrics(GetDC(hWnd), &tm);
		cxChar = tm.tmAveCharWidth;
		cyChar = tm.tmHeight;

		RECT &rc = g_sData[nIndex].vctRc[1];
		if (!bShowCaret) CreateCaret(hWnd, NULL, 2, (rc.bottom - rc.top) - 4);

		POINT pt = event.ptMouse;
		AdusyCaretPos(pt, rc);
		SetCaretPos(pt.x, pt.y);
		::ShowCaret(hWnd);
		bShowCaret = true;
		this->Invalidate();
	}

	void CStockGPriceUI::HideCaret()
	{
		HWND hWnd = m_pManager->GetPaintWindow();
		DestroyCaret();
		SetWindAttrib(hWnd);

		if (m_hwndForegWnd) ::SetForegroundWindow(m_hwndForegWnd);
		m_hwndForegWnd = NULL;
		bShowCaret = false;
		if (nIndex >= 0 && strBuffer.GetLength() == 6)
		{
			wstring sNo = strBuffer;
			_set.FormateSNo(sNo);
			g_sData[nIndex].SNO = sNo;
			m_pManager->SendNotify(this, L"SNOCHANGS", 0, 0);

		}
		strBuffer = L"";
		nTextSize = 0;
		nIndex = -1;
		this->Invalidate();
	}

	void CStockGPriceUI::SetWindAttrib(HWND hwnd, bool Add)
	{
		DWORD dwStyle = ::GetWindowLong(hwnd, GWL_EXSTYLE);
		if (Add)dwStyle |= WS_EX_NOACTIVATE;
		else dwStyle &= ~WS_EX_NOACTIVATE;
		::SetWindowLong(hwnd, GWL_EXSTYLE, dwStyle);
	}

	void CStockGPriceUI::AdusyCaretPos(void)
	{
		RECT &rc = g_sData[nIndex].vctRc[1];
		POINT pt;
		GetCaretPos(&pt);
		int nLen = strBuffer.GetLength();
		int nMaxLen = nLen * cxChar;
		if (nTextSize > 0) nMaxLen = min(nMaxLen, nTextSize);
		int nLeft = rc.left + 5;
		int nRight = nLeft + nMaxLen;
		pt.x = nRight;
		//if (pt.x <= nLeft) pt.x = nLeft;
		//else if (pt.x >= nRight) pt.x = nRight;
		SetCaretPos(pt.x, pt.y);
	}

	void CStockGPriceUI::AdusyCaretPos(POINT &pt, RECT &rc)
	{
		int nLen = strBuffer.GetLength();
		int nMaxLen = nLen * cxChar;
		int nLeft = rc.left + 5;
		int nRight = nLeft + (nTextSize > 0 ? nTextSize : nMaxLen);
		pt.y = rc.top;
		if (pt.x <= nLeft) pt.x = nLeft;
		else if (pt.x >= nRight) pt.x = nRight;

	}
	void CStockGPriceUI::MoveCaretPost(bool bFst)
	{
		POINT pt;
		GetCaretPos(&pt);
		if (bFst) pt.x -= cxChar;
		else pt.x += cxChar;
		SetCaretPos(pt.x, pt.y);
	}

	int CStockGPriceUI::GetMoustInIndex(TEventUI& event)
	{
		int _inx = -1;
		for (int i = 0; i < g_sData.size(); i++)
		{
			if (::PtInRect(&g_sData[i].vctRc[0], event.ptMouse))
			{
				_inx = i;
				break;
			}
		}
		return _inx;
	}

	int CStockGPriceUI::GetPtInIndex(TEventUI& event)
	{
		int _inx = -1;
		for (int i = 0; i < g_sData.size(); i++)
		{
			if (::PtInRect(&g_sData[i].vctRc[1], event.ptMouse))
			{
				if (_inx != i) strBuffer = g_sData[i].SNO.substr(2).c_str();
				_inx = i;
				break;
			}
		}
		return _inx;
	}

	int CStockGPriceUI::GetMoustInItem(TEventUI& event, int nIdx)
	{
		int _inx = -1;

		do
		{
			if (nIdx < 0) break;

			vector <RECT> &vctRc = g_sData[nIdx].vctRc;

			for (int i = 1; i < vctRc.size(); i++)
			{
				RECT &rc = vctRc[i];
				if (::PtInRect(&rc, event.ptMouse))
				{
					_inx = i;
					break;
				}
			}
		} while (0);

		return _inx;
	}

	void CStockGPriceUI::ChkClickPt(TEventUI& event)
	{
		int _inx = GetMoustInIndex(event);
		int nItem = GetMoustInItem(event, _inx);
		if (_inx >= 0) m_pManager->SendNotify(this, L"SHOW_CHART_DLG", _inx, nItem);
	}
	void CStockGPriceUI::DoEvent(TEventUI& event)
	{
		if (event.Type == UIEVENT_BUTTONDOWN)
		{
			bIsCapture = true;
			nSelIndex = GetMoustInIndex(event);

			/*m_pManager->SetCapture();
			m_pManager->ReleaseCapture();
			
			if (nIndex < g_sData.size())
			{
				m_pManager->SendNotify(this, _T("Down"), nIndex);

				_SData tItem = g_sData[nIndex];
				g_sData[nIndex ++] = g_sData[nIndex];
				g_sData[nIndex] = tItem;
			}
			*/
		}
		if (event.Type == UIEVENT_BUTTONUP)
		{
			bIsCapture = false;
			nSelIndex = -1;

			int ndx = GetPtInIndex(event);
  
			if (ndx >= 0)
			{
				nIndex = ndx;
				ShowCaret(event);
			}
			else if (bShowCaret) HideCaret();
			else ChkClickPt(event);
			return;
		}

		if (event.Type == UIEVENT_MOUSEMOVE)
		{
			nHotIndex = GetMoustInIndex(event);
			//if (bIsCapture && nSelIndex > -1)
			//{
			//	if (nHotIndex >= 0 && nHotIndex != nSelIndex)
			//	{
			//		_SData tItem = g_sData[nHotIndex];
			//		g_sData[nHotIndex] = g_sData[nSelIndex];
			//		g_sData[nSelIndex] = tItem;
			//	} 
			//}
			Invalidate();
			m_pManager->SendNotify(this, L"MOUSEMOVE", nHotIndex, 0);
		}

		if (event.Type == UIEVENT_MOUSELEAVE)
		{
			nHotIndex = -1;
		}
		
		//if (event.Type == UIEVENT_RBUTTONDOWN)
		//{
		//	 
		//	m_pManager->SendNotify(this, L"MOUSEMOVE", nHotIndex, 0);
		//}

		if (event.Type == UIEVENT_CONTEXTMENU)
		{
			m_pManager->SendNotify(this, L"CONTEXTMENU", nHotIndex, 0);
		}


		if (event.Type == UIEVENT_CHAR)
		{
			if (!bShowCaret) return;

			if (event.chKey == L'C') strBuffer = L"";
			if (event.chKey == L'c') strBuffer = L"";
			if (event.chKey == L'S') strBuffer = L"600";
			if (event.chKey == L's') strBuffer = L"600";
			if (event.chKey == L'Z') strBuffer = L"600";
			if (event.chKey == L'z') strBuffer = L"000";
			if (strBuffer.GetLength() >= 6) return;
			if ((event.chKey >= L'0') && (event.chKey <= L'9')) strBuffer += event.chKey;
			AdusyCaretPos();
			Invalidate();
		}

		if (event.Type == UIEVENT_KILLFOCUS)
		{
			//if (bShowCaret) HideCaret();
		}
		if (event.Type == UIEVENT_KEYDOWN)
		{
			if (bShowCaret == false) return;
			RECT &rc = g_sData[nIndex].vctRc[1];
			POINT pt = { 0 };
			GetCaretPos(&pt);
			bool bSet = true;

			switch (event.chKey)
			{
			case VK_LEFT:
			{
				pt.x -= cxChar;
				AdusyCaretPos(pt, rc);
			}
			break;
			case VK_RIGHT:
			{
				pt.x += cxChar;
				AdusyCaretPos(pt, rc);
			}
			break;
			case VK_HOME:
				pt.x = rc.left;
				break;
			case VK_END:
				pt.x = rc.right - (cxChar + cxChar);
				break;
			case VK_ESCAPE:
			{
				strBuffer = L"";
				nIndex = -1;
				HideCaret();
				return;
			}
			case VK_BACK:
				DoDelString();
				break;
			case VK_DELETE:
				DoDelString(false);
				break;
			case VK_RETURN:
				HideCaret();
				break;
			default:
				bSet = false;
				break;
			}

			if (bSet) SetCaretPos(pt.x, pt.y);
		}
		if (m_pParent != NULL) m_pParent->DoEvent(event);
	}

	int CStockGPriceUI::GetCartInPost(void)
	{
		POINT pt = { 0 };
		GetCaretPos(&pt);
		HWND hWnd = m_pManager->GetPaintWindow();
		HDC hdc1 = GetDC(hWnd);

		SIZE size = { 0 };
		int ncx = g_sData[nIndex].vctRc[1].left;
		int nAt = -1;
		CDuiString strTmp;

		for (int i = 1; i < strBuffer.GetLength(); i++)
		{
			strTmp = strBuffer.Left(i);
			::GetTextExtentPoint(hdc1, strTmp, strTmp.GetLength(), &size);
			if ((size.cx + ncx) >= pt.x)
			{
				nAt = i;
				break;
			}
		}
		::ReleaseDC(hWnd, hdc1);
		return nAt;
	}

	void CStockGPriceUI::DoDelString(bool bFst)
	{
		int nAt = GetCartInPost();

		if (nAt < 1) return;

		if (bFst) nAt--;
		CDuiString strTmp = L"";
		int nLen = strBuffer.GetLength();
		WCHAR szBuf[15] = { 0 };
		_tcsncpy(szBuf, strBuffer, nLen);
		for (int j = nAt; j < nLen; j++) szBuf[j] = szBuf[j + 1];

		strBuffer = szBuf;
		if (bFst)
		{
			MoveCaretPost();
			MoveCaretPost();
		}
		Invalidate();
	}


} // namespace DuiLib