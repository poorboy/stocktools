#pragma once
#include "../DataDef/CommData.h"
namespace DuiLib {

	class StockPriceListElmUI : public CListContainerElementUI
	{
	public:
		StockPriceListElmUI();

		LPCTSTR GetClass() const;
		void SetStockPriceData(StockPrice &priceData);
		StockPrice GetSoctkPriceData(void);
		void DoEvent(TEventUI& event);
		void SetTime(CDuiString &strTime);
		void ReSetData();

	protected:
		void SetBntAction();

		virtual bool OnClickAdd(void* param);
		virtual bool OnClickDel(void* param);
		virtual bool OnClickTime(void* param);

	protected:

		CEditUI *pEtPrice;
		CEditUI *pEtNumber;
		CEditUI *pEtTime;
		CButtonUI *pbntTime;
		//"�ɱ�  ���� ʱ��  
		CHorizontalLayoutUI *pHor0;
		CHorizontalLayoutUI *pHorTime;
		CHorizontalLayoutUI *pHorBnt;
		CHorizontalLayoutUI *pHorNumber;

		CButtonUI *pBntAdd;
		CButtonUI *pBntDel;

		int nIndex = 0;
	};

} // namespace DuiLib
 