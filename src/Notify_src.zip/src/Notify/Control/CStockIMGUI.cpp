#include "StdAfx.h"
#include "CStockIMGUI.h"

namespace DuiLib {

	StockIMG::StockIMG()
	{
	}

	StockIMG::~StockIMG()
	{

	}

	void StockIMG::PaintText(HDC hDC)
	{
		if (strBKimg.GetLength() < 1) return;
		TImageInfo* data = CRenderEngine::LoadImage(strBKimg.GetData(), NULL, 0);
		if (!data) return;
		HDC hCloneDC = ::CreateCompatibleDC(hDC);
		HBITMAP hOldBitmap = (HBITMAP) ::SelectObject(hCloneDC, data->hBitmap);
		::SetStretchBltMode(hDC, COLORONCOLOR);
		::StretchBlt(hDC, m_rcPaint.left, m_rcPaint.top, m_rcPaint.right - m_rcPaint.left, m_rcPaint.bottom - m_rcPaint.top, \
			hCloneDC, 0, 0, data->nX, data->nY, SRCCOPY);

		::SelectObject(hCloneDC, hOldBitmap);
		::DeleteDC(hCloneDC);
		if (data) CRenderEngine::FreeImage(data);
	}

	void StockIMG::SetBkImage(LPCTSTR pStrImage)
	{
		strBKimg = pStrImage;
		Invalidate();
	}

} // namespace DuiLib