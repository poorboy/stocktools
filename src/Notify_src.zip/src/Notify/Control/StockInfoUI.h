#pragma once

#include "../DataDef/CommData.h"

namespace DuiLib {

	class StockLineUI :public CControlUI
	{
	public:
		StockLineUI();
		~StockLineUI();
		void DrawVTitle(HDC hDC, double duMin, double duMax);

		void DrawHTitle(HDC hDC);

		void DrawTime(HDC hDC);

		void DrawTitle(HDC hDC, double duMin, double duMax);

		void ClacStep(double duMin, double duMax);

		void DrawBox(HDC hDC);

		void DrawMInfo(HDC hDC);

		void InitLintPost();
		bool DrawLine(HDC hDC);

		void DrawCloss(HDC hDC);

		void DrawTipInfo(HDC hDC);
		virtual void PaintText(HDC hDC);


		void UpData(SData &sData, CTimeEx &_time);

		virtual void DoEvent(TEventUI& event);

	protected:
		int nCuuPage = 1;
		int nPageSize = 0;
		int nPageTotal = 0;
		bool bDrawLine = true;
		bool bDrawCloss;
		int nSize;
		SData _sData;
		POINT pt;
		vector<POINT> vctPt;
		bool b_IsInit = false;
		CTimeEx m_time;
		int nXStep;
		int nYStep;
		int nYFix;
	};
} // namespace DuiLib