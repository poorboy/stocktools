#pragma once 

namespace DuiLib {

	class StockIMG :public CControlUI
	{
	public:
		StockIMG();
		~StockIMG();
		virtual void PaintText(HDC hDC);
		void SetBkImage(LPCTSTR pStrImage);
	private:
		CDuiString strBKimg;
	};
} // namespace DuiLib