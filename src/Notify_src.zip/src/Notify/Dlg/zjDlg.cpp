#include "stdafx.h"
#include "zjDlg.h"  

CzjDlg::CzjDlg(void)
{
	lst_Stock = NULL;

	m_skType = SK_ALL_A;
	m_nType = 1;

	hThread = CreateThread(
		NULL,
		0,
		CzjDlg::WorkThread,
		(LPVOID)this,
		0,
		&threadId
	);

	m_bNeedRefresh = false;
	bExit = false;
}

CzjDlg::~CzjDlg(void)
{

}

UILIB_RESOURCETYPE CzjDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR CzjDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

#define GET_EDIT_TXT(X,Y) GET_CONTROL_TEXT_BY_NAME(X,Y, m_PaintManager)

void CzjDlg::OnPrepare()
{
	lst_Stock = static_cast<CListUI*>(m_PaintManager.FindControl(L"lst_Stock")); 
	lst_Stock->SetTextCallback(NULL); 
	m_bNeedRefresh = true;
}

void CzjDlg::RefreshList()
{
	if (!lst_Stock) return;

	lst_Stock->RemoveAll();

	for (int i = 0; i < m_info.size(); i++)
	{
		CListTextElementUI * pElm = new CListTextElementUI;
		if (!pElm) continue;;
		lst_Stock->Add(pElm);
		for (int j = 1; j < 15; j++)
			pElm->SetText(j - 1, m_info[i][j].c_str());
	}
}

void CzjDlg::GetFilerInfos(ZJinfo &fInfo)
{
	CDuiString strZfs;
	CDuiString strZfe;
	CDuiString strZls;
	CDuiString strZle;
	CDuiString strPs;
	CDuiString strPe;


	GET_EDIT_TXT(L"et_zfs", strZfs);
	GET_EDIT_TXT(L"et_zfe", strZfe);
	GET_EDIT_TXT(L"et_zls", strZls);
	GET_EDIT_TXT(L"et_zle", strZle);
	GET_EDIT_TXT(L"et_ps", strPs);
	GET_EDIT_TXT(L"et_pe", strPe);

	double dZfs = _ttof(strZfs.GetData());
	double dZfe = _ttof(strZfe.GetData());
	double dZls = _ttof(strZls.GetData());
	double dZle = _ttof(strZle.GetData());
	double dPs = _ttof(strPs.GetData());
	double dPe = _ttof(strPe.GetData()); 

	double dcuuP;
	double dcuuzf;
	double dcuuzl;

	fInfo.clear();  
	for (int i = 0; i < m_info.size(); i++)
	{ 
		dcuuP = _ttof(m_info[i][3].c_str());
		dcuuzf = _ttof(m_info[i][4].c_str());
		dcuuzl = _ttof(m_info[i][5].c_str()); 

		if (dcuuP < dPs) continue;
		if (dcuuP > dPe) continue;

		if (dcuuzf < dZfs) continue;
		if (dcuuzf > dZfe) continue;


		if (dcuuzl < dZls) continue;
		if (dcuuzl > dZle) continue;
		
		fInfo.push_back(m_info[i]);

	} 
}
void CzjDlg::FilterInfo()
{
	if (!lst_Stock) return;

	lst_Stock->RemoveAll(); 
	ZJinfo vctF;
	GetFilerInfos(vctF);
	for (int i = 0; i < vctF.size(); i++)
	{
		CListTextElementUI * pElm = new CListTextElementUI;
		if (!pElm) continue;;
		lst_Stock->Add(pElm);
		for (int j = 1; j < 15; j++)
			pElm->SetText(j - 1, vctF[i][j].c_str());
	}
}

 
void CzjDlg::OnClick(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();
	if (strName == L"btnClose") { bExit = true; this->Close(); }
	if (strName == L"bnt_Refresh") FilterInfo();
	if (strName == L"bnt_hist") GetHist();
	if (strName == L"bnt_time") GetCuuDayTime(); 
}

void CzjDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit")) OnPrepare();
	else if (msg.sType == _T("click")) OnClick(msg);
	else if (msg.sType == DUI_MSGTYPE_SELECTCHANGED) OnOptChang(msg);
	else if (msg.sType == DUI_MSGTYPE_TEXTCHANGED) FilterInfo();
}

void CzjDlg::OnOptChang(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();

	bool bNeedUpData = true;

	if (strName == L"opt_skType_ALL")      m_skType = SK_ALL;
	else if (strName == L"opt_skType_A")   m_skType = SK_ALL_A;
	else if (strName == L"opt_skType_LA")  m_skType = SK_H_A;
	else if (strName == L"opt_skType_SA")  m_skType = SK_S_A;
	else if (strName == L"opt_skType_CYB") m_skType = SK_CYB;
	else if (strName == L"opt_skType_ZXB") m_skType = SK_ZXB;
	else if (strName == L"opt_DayType_1")  m_nType = 1;
	else if (strName == L"opt_DayType_3") m_nType = 3;
	else if (strName == L"opt_DayType_5") m_nType = 5;
	else if (strName == L"opt_DayType_10") m_nType = 10;
	else bNeedUpData = false;
	if (bNeedUpData)  m_bNeedRefresh = true;
	 
}

void CzjDlg::GetZJinfo()
{
	if (lst_Stock) lst_Stock->RemoveAll();
	if (m_http.GetZJ(m_nType, m_info)) RefreshList(); 
	m_bNeedRefresh = false;
}

bool CzjDlg::GetCurSelSkNo(UString &strNo, UString &strMarket)
{
	if (!lst_Stock) return false;
	int nAt = lst_Stock->GetCurSel();

	if (nAt < 0) return false; 
	strNo = m_info[nAt][1].c_str();
	strMarket = m_info[nAt][0].c_str();
	return true;
}

void CzjDlg::GetHist()
{
	UString  strNo;
	UString  strMarket;
	if (!GetCurSelSkNo(strNo, strMarket)) return;

	//ZJinfo vctTmp;
	//m_http.GetSkZJ(strNo.GetData(), vctTmp);
	//http://data.eastmoney.com/zjlx/000710.html
	UString strTmp;
	strTmp.Format(L"http://data.eastmoney.com/zjlx/%s.html", strNo.GetData());
	ShellExecute(NULL, L"open", strTmp.GetData(), NULL, NULL, SW_SHOW);

}

void CzjDlg::GetCuuDayTime()
{
	UString  strNo;
	UString  strMarket;
	if (!GetCurSelSkNo(strNo, strMarket)) return;


	//http://quote.eastmoney.com/f1.html?code=002497&market=2

	UString strTmp;
	strTmp.Format(L"http://quote.eastmoney.com/f1.html?code=%s&market=%s", strNo.GetData(), strMarket.GetData());
	ShellExecute(NULL, L"open", strTmp.GetData(), NULL, NULL, SW_SHOW);

	//ZJinfo vctTmp;
	//m_http.GetSkFS(strNo.GetData(), vctTmp);

}

int CzjDlg::ShowWind()
{
	Create(NULL,
		_T("CzjDlg"),
		WS_POPUP/*UI_WNDSTYLE_DIALOG*/,
		WS_EX_TOPMOST | WS_EX_TOOLWINDOW, 0, 0);

	this->CenterWindow();
	return this->ShowModal();
}

void CzjDlg::DoRefresh()
{
	while (true)
	{
		if (bExit) break;
		if (m_bNeedRefresh)GetZJinfo();
	}
}

DWORD WINAPI CzjDlg::WorkThread(LPVOID lpPara)
{
	CzjDlg * pWnd = (CzjDlg *)lpPara;
	if (pWnd)  pWnd->DoRefresh();
	return 0;
}