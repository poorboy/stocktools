#include "stdafx.h"
#include "DayRelLine.h" 
#include "../Utils/NetOpr.h"

CTimeEx m_time;

void AnalyzeData(string &strData)
{
	g_DayData.ReSetData(m_time);
	if (strData.length() < 100) return;

	wstring wstrData = C2Unicode(strData);

	wstring wTmp = L"";
	int i = wstrData.find_first_of(L'\n') + 1;
	wstrData = wstrData.substr(i);

	while ((i = wstrData.find_first_of(L'\n')) && (i != string::npos))
	{
		wTmp = wstrData.substr(0, i);
		wstrData = wstrData.substr(i + 1);
		g_DayData.AddTimeItem(wTmp);
	}

	g_DayData.ReSort();
}

DayRelLineDlg::DayRelLineDlg(void)
{
	hThread = NULL;
	threadId = 0;

	pStockCont = NULL;
	pClaDlg = NULL;
	pTitle = NULL;

	bNeedDowm = false;
	m_time = CTimeEx::GetCurrentTime();
	GetDayRelDate(-1);

	hThread = CreateThread(
		NULL,
		0,
		DayRelLineDlg::WorkThread,
		(LPVOID)this,
		0,
		&threadId);
}

DayRelLineDlg::~DayRelLineDlg(void)
{
	if (pClaDlg) pClaDlg->Close();
}

string DayRelLineDlg::GetData()
{
	string strData = "";
	if (_sData.SNO.length() < 1) return strData;
#define  DOWN_URL L"http://market.finance.sina.com.cn/downxls.php?date=%s&symbol=%s"

	CDuiString strUrl;
	strUrl.Format(DOWN_URL, m_time.ToString().c_str(), _sData.SNO.c_str());
	wstring _Url = strUrl.GetData();
	strData = GetNetData(_Url);
	return strData;
}

void DayRelLineDlg::UpDayRelLine()
{
	string strData = GetData();
	AnalyzeData(strData);
	if (pStockCont) pStockCont->UpData(_sData, m_time);
	UpDataTitle();
	::SetForegroundWindow(*this);
	::ShowWindow(*this, SW_SHOW);
	::SetFocus(*this);
	return;
}

UILIB_RESOURCETYPE DayRelLineDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR DayRelLineDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}
void DayRelLineDlg::OnPrepare()
{
	pStockCont = static_cast<StockLineUI*>(m_PaintManager.FindControl(_T("stock")));

	pTitle = static_cast<CLabelUI*>(m_PaintManager.FindControl(_T("lab_Title")));

	this->CenterWindow();
	SetFocus(*this);

	pClaDlg = new CalSelDlg(this);
	if (pClaDlg)
	{
		pClaDlg->Create(*this, L"����ѡ�����", UI_WNDSTYLE_DIALOG, 0, 0, 0, 0, 0, NULL);
		pClaDlg->ShowWindow(false, false);
	}

	UpDataTitle();
}

void DayRelLineDlg::OnClick(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();
	if (strName == L"exit") this->ShowWindow(false);
	if (strName == L"btn_Day_last") GetDayRelDate(-1);
	if (strName == L"btn_Day_next")  GetDayRelDate(1);
	//    
	if (strName == L"bnt_Data")
	{
		if (!pClaDlg) return;
		POINT pt = { 0 };
		CDuiRect rcBtn = msg.pSender->GetPos();
		CDuiRect rcWindow;
		GetWindowRect(m_hWnd, &rcWindow);
		pt.y = rcWindow.top + rcBtn.top;
		pt.x = rcWindow.left + rcBtn.left + static_cast<LONG>((rcBtn.right - rcBtn.left) / 2);
		pClaDlg->SetWindowsPost(pt);
		pClaDlg->ShowWindow(true, true);

	}
}

void DayRelLineDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit")) OnPrepare();
	else if (msg.sType == _T("click"))
	{
		OnClick(msg);
	}
}

LRESULT DayRelLineDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

void DayRelLineDlg::GetDayRelDate(int nDay)
{
	m_time.AddDay(nDay);

	if (m_time.GetDayOfWeek() == 1)
	{
		//����
		if (nDay > 0)
			m_time.AddDay(1);
		else
			m_time.AddDay(-2);
	}
	else if (m_time.GetDayOfWeek() == 7)
	{
		//����
		if (nDay > 0)
			m_time.AddDay(2);
		else
			m_time.AddDay(-1);
	}


	CTimeEx mCuuDate(CTimeEx::GetCurrentTime().ToString().c_str());
	if (m_time >= mCuuDate)
	{
		m_time = mCuuDate;
		m_time.AddDay(-1);
	}

	UpDayRelLine();
}

void DayRelLineDlg::UpDataDate(CDuiString &strData)
{
	m_time = CTimeEx(strData.GetData());
	bNeedDowm = true;
}

LRESULT DayRelLineDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);

	if (uMsg == WM_KEYDOWN)
	{
		bHandled = TRUE;
		switch (wParam)
		{
		case VK_LEFT: GetDayRelDate(-1);  break;
		case VK_RIGHT: GetDayRelDate(1); break;
		case VK_TAB: break;
		case VK_F5: UpDayRelLine(); break;
		default: bHandled = FALSE;
		}
	}
	return false;
}

LRESULT DayRelLineDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bExit = true;
	PostQuitMessage(0);
	return 0;
}



CControlUI* DayRelLineDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockIMG")) == 0) {
		return new StockLineUI;
	}
	return NULL;
}

void DayRelLineDlg::DoTask()
{
	int nTime = 0;
	while (true)
	{
		if (bExit) break;
		if (bNeedDowm)
		{
			UpDayRelLine();
			bNeedDowm = false;
		}
		Sleep(100);
	}
}

void DayRelLineDlg::UpDataTitle()
{
	if (!pTitle) return;

	CDuiString strTitle;
	if (_sData.vctFd.size() > 5)
		strTitle.Format(L"[%s]%s[%s],��߼�:%.02f,��ͼ�:%.02f"
			, m_time.ToString().c_str()
			, _sData.vctFd[0].c_str()
			, _sData.SNO.c_str()
			, g_DayData.dMaxp
			, g_DayData.dMinP);
	else
		strTitle.Format(L"[%s]", m_time.ToString().c_str());

	pTitle->SetText(strTitle.GetData());
}

void DayRelLineDlg::ShowWin(SData &sData)
{
	_sData = sData;
	bNeedDowm = true;
}

DWORD WINAPI DayRelLineDlg::WorkThread(LPVOID lpPara)
{
	DayRelLineDlg * pWnd = (DayRelLineDlg *)lpPara;
	if (pWnd)   pWnd->DoTask();
	return 0;
}