#pragma once 

#include "../http/HttpClientSyn.h"

class CzjDlg : public WindowImplBase
{
public:
	CzjDlg();
	~CzjDlg();
	LPCTSTR  GetWindowClassName() const { return _T("CSetDlg"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_DIALOG; } 
	virtual CDuiString  GetSkinFile() { return _T("zjdlg.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);
	void OnClick(TNotifyUI& msg);
	void OnOptChang(TNotifyUI& msg);
	 
	void RefreshList();
	void GetZJinfo(); 
	int ShowWind();
	void FilterInfo();

	void GetFilerInfos(ZJinfo &fInfo);
	static DWORD WINAPI WorkThread(LPVOID lpPara); 

	void DoRefresh();


	void GetHist();
	void GetCuuDayTime();

	bool GetCurSelSkNo(UString &strNo, UString &strMarket);

protected:
	void OnPrepare(); 


	HANDLE hThread;
	DWORD  threadId;

	CListUI * lst_Stock;

	ZJinfo m_info;

	CHttpClientSyn m_http;
	SK_TYPE m_skType;
	int		m_nType;
	bool    m_bNeedRefresh;
	bool    bExit;

};