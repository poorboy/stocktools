#pragma once

#include "../Control/CGStockPriceUI.h"

class GroupDlg : public WindowImplBase
{
public:
	GroupDlg();
	~GroupDlg();
	LPCTSTR  GetWindowClassName() const { return _T("StockGroupDlgUI"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_FRAME; }//CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("SkInfo.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
 
	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled); 
	void ShowWin(CDuiString &SNo);
protected:
	void InitWindow();
	CStockGPriceUI *pStockCont;
};

