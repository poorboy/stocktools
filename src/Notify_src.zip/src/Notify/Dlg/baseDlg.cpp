#include "stdafx.h"
#include "baseDlg.h"

BaseDlg::BaseDlg(void)
{

}

BaseDlg::~BaseDlg(void)
{

}



UILIB_RESOURCETYPE BaseDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR BaseDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

LPCTSTR BaseDlg::GetWindowClassName() const
{ 
	string strName = __FUNCTION__;
	int nFind = strName.find("::");
	if (nFind != string::npos) strName.substr(0, nFind);
	wstring Name = C2W(strName);
	CDuiString strInfo;
	strInfo.Format(L"\r\nBaseDlg::GetWindowClassName%s\r\n", Name.c_str());
	OutputDebugString(strInfo.GetData());
	return Name.c_str();
	//return _T("StockInfoDlgUI");
}

LRESULT BaseDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT BaseDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);
	return false;
}

LRESULT BaseDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	PostQuitMessage(0);
	return 0;
}