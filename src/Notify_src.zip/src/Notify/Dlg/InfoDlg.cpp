#include "stdafx.h"
#include "infoDlg.h"

InfoDlg::InfoDlg(void)
{
	pStockCont = NULL;

}

InfoDlg::~InfoDlg(void)
{

}



UILIB_RESOURCETYPE InfoDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR InfoDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}
void InfoDlg::OnPrepare()
{
	pStockCont = static_cast<StockNote*>(m_PaintManager.FindControl(_T("stock")));
	m_PaintManager.SetOpacity(255, RGB(255, 255, 255));
}

void InfoDlg::Notify(TNotifyUI& msg)
{
	if (msg.sType == _T("windowinit")) OnPrepare();
}

LRESULT InfoDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT InfoDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);
	return false;
}

LRESULT InfoDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	PostQuitMessage(0);
	return 0;
}



CControlUI* InfoDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockIMG")) == 0) {
		return new StockNote;
	}
	return NULL;
}


void InfoDlg::ShowWin(SData &sData)
{
	if (pStockCont) pStockCont->SetSData(sData);
	AdustPost();
}

void InfoDlg::AdustPost()
{
	SIZE sz = m_PaintManager.GetInitSize();
	int x = 0;
	int y = 0;
	CalcPos(x, y);
	::MoveWindow(m_hWnd, x, y, sz.cx, sz.cy, TRUE);
	//::SetForegroundWindow(*this);
	::ShowWindow(*this, SW_SHOW);
}

#define TASK_POS_LEFT		0
#define TASKBAR_POS_TOP		1
#define TASKBAR_POS_RIGHT	2
#define TASKBAR_POS_BOTTON	3
#define MSG_EDGE			5

void InfoDlg::CalcPos(int& x, int& y)
{
	RECT rcScreen;
	::GetWindowRect(GetDesktopWindow(), &rcScreen);
	ZeroMemory(&m_ad, sizeof APPBARDATA);
	m_ad.cbSize = sizeof APPBARDATA;
	SHAppBarMessage(ABM_GETTASKBARPOS, &m_ad);
	RECT rcTaskBar(m_ad.rc);
	//RECT rcTray;
	//HWND hWndTaskbar = ::FindWindow(_T("Shell_TrayWnd"), 0);
	//::GetWindowRect(hWndTaskbar, &rcTray);

	POINT pt = { 0 };
	GetCursorPos(&pt);
	x = pt.x + 2;
	y = pt.y + 2;

	SIZE sz = m_PaintManager.GetInitSize();

	//���ұ�
	if ((x + sz.cx) > rcScreen.right)
	{
		x -= 4;
		x -= sz.cx;
	}

	//���±�
	if ((y + sz.cy) > rcScreen.bottom)
	{
		y -= 4;
		y -= sz.cy;
	}

	////���ϱ�
	//if ((y + nWidth) > rcScreen.right)
	//{
	//	rcClient.right = X;
	//	x -= nWidth;
	//	rcClient.left = x - nWidth;
	//}

	////���±�
	//if ((x + nWidth) > rcScreen.right)
	//{
	//	rcClient.right = X;
	//	x -= nWidth;
	//	rcClient.left = x - nWidth;
	//}

	//// X =   Y= 
	////��
	//if (m_ad.uEdge == TASK_POS_LEFT)
	//{
	//	x = rcTaskBar.right;
	//	y = rcTaskBar.bottom - (rcClient.bottom - rcClient.top);
	//}
	////��
	//else if (m_ad.uEdge == TASKBAR_POS_TOP)
	//{
	//	x = rcTaskBar.right - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.bottom;
	//}
	////��
	//else if (m_ad.uEdge == TASKBAR_POS_RIGHT)
	//{
	//	x = rcTaskBar.left - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.bottom - (rcClient.bottom - rcClient.top);
	//}
	////��
	//else
	//{
	//	x = rcTaskBar.right - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.top - (rcClient.bottom - rcClient.top);
	//}
}