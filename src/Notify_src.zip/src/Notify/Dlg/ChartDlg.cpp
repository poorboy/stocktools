#include "stdafx.h"
#include "ChartDlg.h" 
#include "../Utils/NetOpr.h" 

static CDuiString  szType[4] =
{
	L"monthly",
	L"weekly",
	L"daily",
	L"min",
};

#define  MIN_IMAGE_FILE     3
#define  DAY_IMAGE_FILE     2
#define  WEEK_IMAGE_FILE    1
#define  MON_IMAGE_FILE     0

#define  DOWN_IMG_URL	    L"http://image.sinajs.cn/newchart/"


ChartDlg::ChartDlg(void)
{
	//ִ�е������߳̾߱�
	hThread = NULL;
	pStockCont = NULL;

	//ִ�е������߳�ID
	threadId = 0;
	CDuiString strAppDir = ::GetAppDir().c_str();

	strFiles[0] = strAppDir + L"Mon.gif";
	strFiles[1] = strAppDir + L"Week.gif";
	strFiles[2] = strAppDir + L"Day.gif";
	strFiles[3] = strAppDir + L"Min.gif";

	hThread = CreateThread(NULL, 0, ChartDlg::WorkThread, (LPVOID)this, 0, &threadId);
}

ChartDlg::~ChartDlg(void)
{
	DeleteFiles();
}

void ChartDlg::DeleteFiles()
{
	for (int i = 0; i < 4; i++)
	{
		if (::IsFileExists(strFiles[i])) ::DeleteFile(strFiles[i]);
	}
}

void ChartDlg::DownImages(int i)
{

	/*
	//��K�ߣ�
	//http://image.sinajs.cn/newchart/monthly/n/sh000001.gif
	//��K�ߣ�
	//http://image.sinajs.cn/newchart/weekly/n/sh000001.gif
	//��K�ߣ�
	//http://image.sinajs.cn/newchart/daily/n/sh000001.gif
	//��ʱ�ߣ�
	//http://image.sinajs.cn/newchart/min/n/sh000001.gif
	*/

	CDuiString strUrl;
	strUrl.Format(L"%s%s/n/%s.gif", DOWN_IMG_URL, szType[i].GetData(), _strSockNo.GetData());

	wstring _url = strUrl.GetData();
	wstring _File = strFiles[i].GetData();
	GetNetFile(_url, _File);
}

void ChartDlg::DownImg()
{
	DeleteFiles();
	for (int i = 0; i < 4; i++) DownImages(i);
	if (pStockCont) pStockCont->Invalidate();
	//this->ShowWindow(true, true);
	::SetForegroundWindow(*this);
	::ShowWindow(*this, SW_SHOW);
	::SetFocus(*this);
}

UILIB_RESOURCETYPE ChartDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR ChartDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}
void ChartDlg::OnPrepare()
{
	pStockCont = static_cast<StockIMG*>(m_PaintManager.FindControl(_T("stock")));
	if (pStockCont) pStockCont->SetBkImage(strFiles[MIN_IMAGE_FILE]);
	this->CenterWindow();
	SetFocus(*this);
}

void ChartDlg::OnClick(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();
	bool bSet = true;
	int nInx = MIN_IMAGE_FILE;
	if (strName == L"bnt_Mon")  nInx = MON_IMAGE_FILE;
	else if (strName == L"bnt_Day") nInx = DAY_IMAGE_FILE;
	else if (strName == L"bnt_Week") nInx = WEEK_IMAGE_FILE;
	else if (strName == L"bnt_Min") nInx = MIN_IMAGE_FILE;
	else  bSet = false;
	if (bSet) ChangBkImg(nInx);

	if (strName == L"exit") this->ShowWindow(false);
}


void ChartDlg::ChangBkImg(int nIndex)
{
	if (pStockCont) pStockCont->SetBkImage(strFiles[nIndex]);
}

void ChartDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit")) OnPrepare();
	else if (msg.sType == _T("click"))
	{
		OnClick(msg);
	}
}

LRESULT ChartDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT ChartDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);
	return false;
}

LRESULT ChartDlg::HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//if (WM_KILLFOCUS == uMsg && pStockCont) this->ShowWindow(false);	
	if (uMsg == WM_CHAR)
	{
		bool bSet = true;
		int nInx = MIN_IMAGE_FILE;
		switch (wParam)
		{
		case '1': nInx = MIN_IMAGE_FILE; break;
		case '2': nInx = DAY_IMAGE_FILE; break;
		case '3': nInx = WEEK_IMAGE_FILE; break;
		case '4': nInx = MON_IMAGE_FILE; break;
		default:bSet = false; break;
		}
		if (bSet) ChangBkImg(nInx);
	}
	return 0l;
}
LRESULT ChartDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bExit = true;
	PostQuitMessage(0);
	return 0;
}



CControlUI* ChartDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockIMG")) == 0) {
		return new StockIMG;
	}
	return NULL;
}

void ChartDlg::DoTask()
{
	int nTime = 0;
	while (true)
	{
		if (bExit) break;
		if (bNeedDowm)
		{
			DownImg();
			bNeedDowm = false;
		}
		Sleep(100);
	}
}

void ChartDlg::ShowWin(CDuiString &SNo)
{
	_strSockNo = SNo;
	bNeedDowm = true;
}
DWORD WINAPI ChartDlg::WorkThread(LPVOID lpPara)
{
	ChartDlg * pWnd = (ChartDlg *)lpPara;
	if (pWnd)   pWnd->DoTask();
	return 0;
}