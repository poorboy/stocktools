#ifndef CalSelDlg_h__
#define CalSelDlg_h__

#pragma once

#include "../Utils/CTimeEx.h"

class IDNotify
{
public:
	virtual void UpDataDate(CDuiString &strData) = 0;
	virtual void SelectFinsh() { return; };

	bool bOnClickClose = false;
};


class CalSelDlg : public WindowImplBase
{
public:
	CalSelDlg(IDNotify * pPDlg);
	~CalSelDlg(void);
	virtual CDuiString  GetSkinFile() { return _T("CalendarSelDlg.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	LPCTSTR  GetWindowClassName() const { return _T("DayRelLineDlg"); }

	UINT GetClassStyle() const { return CS_DBLCLKS; };

	CControlUI* CreateControl(LPCTSTR pstrClass);
	void OnPrepare();
	void Notify(TNotifyUI& msg);
	LRESULT OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void SetWindowsPost(POINT &pt);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


private:
	void UpDateCal();
	void HideWind();
	void SetMouseMoveNote(CDuiString &name, CControlUI * pControl);

private:
	UINT m_CurYear;
	UINT m_CurMonth;
	CTimeEx m_cuuTime;
private:
	CLabelUI * m_pCurentDate;
	CLabelUI * m_pCurentNote;
	IDNotify * pPDlg;
};

#endif // CalSelDlg_h__