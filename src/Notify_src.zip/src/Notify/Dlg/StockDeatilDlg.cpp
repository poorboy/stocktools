#include "stdafx.h"
#include "StockDeatilDlg.h"
#include "../DataDef/CommData.h"

CStockDeatilDlg::CStockDeatilDlg(HWND _pHwnd, _SData * _pSData)
{
	pSData = _pSData;
	bOnClickClose = true;
	et_MinP = NULL;
	et_stNo = NULL;
	et_MaxP = NULL;

	pClaDlg = NULL;
	pLastElm = NULL;

	Create(_pHwnd, _T("CStockDeatilDlg"), UI_WNDSTYLE_DIALOG, WS_EX_TOPMOST | WS_EX_TOOLWINDOW, 0, 0);
	this->CenterWindow();
	this->ShowModal();
}

CStockDeatilDlg::~CStockDeatilDlg(void)
{
	if (pClaDlg) pClaDlg->Close();
}

UILIB_RESOURCETYPE CStockDeatilDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR CStockDeatilDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

void CStockDeatilDlg::OnPrepare()
{
	lst_Stock = static_cast<CListUI*>(m_PaintManager.FindControl(L"lst_Stock"));

	et_MinP = static_cast<CEditUI*>(m_PaintManager.FindControl(L"et_MinP"));
	et_stNo = static_cast<CEditUI*>(m_PaintManager.FindControl(L"et_stNo"));
	et_MaxP = static_cast<CEditUI*>(m_PaintManager.FindControl(L"et_MaxP"));

	pClaDlg = new CalSelDlg(this);
	if (pClaDlg)
	{
		pClaDlg->Create(*this, L"����ѡ�����", UI_WNDSTYLE_DIALOG, 0, 0, 0, 0, 0, NULL);
		pClaDlg->ShowWindow(false, false);
	}
	lst_Stock->SetTextCallback(NULL);
	InitStock();
}

void CStockDeatilDlg::InitStock()
{
	if (!lst_Stock) return;
	CDuiString strTmp;

	do
	{
		if (pSData->SNO.length() < 2) break;

		if (et_stNo)
		{
			et_stNo->SetEnabled(false);
			et_stNo->SetText(pSData->SNO.c_str());
		}

		if (et_MinP)
		{
			strTmp.Format(L"%0.2f", pSData->MinP);
			et_MinP->SetText(strTmp.GetData());
		}

		if (et_MaxP)
		{
			strTmp.Format(L"%0.2f", pSData->MaxP);
			et_MaxP->SetText(strTmp.GetData());
		}

		for (int i = 0; i < pSData->vctSPrice.size(); i++)
		{
			StockPriceListElmUI * pElm = new StockPriceListElmUI;
			if (!pElm) continue;
			pElm->SetOwner(lst_Stock);
			pElm->SetStockPriceData(pSData->vctSPrice[i]);
			lst_Stock->Add(pElm);
		}
	} while (0);

	if (lst_Stock->GetCount() < 1)
	{
		StockPriceListElmUI * pElm = new StockPriceListElmUI;
		if (!pElm) return;
		pElm->SetOwner(lst_Stock);
		lst_Stock->Add(pElm);
	}
}

void CStockDeatilDlg::Save()
{
	CDuiString strTmp;
	double duT;

	pSData->vctSPrice.clear();
	pSData->MaxP = 0.00000;
	pSData->MinP = 0.00000;

	do
	{
		if (!et_stNo) break;
		strTmp = et_stNo->GetText();
		 
		if (!_set.ValidStockNO(strTmp))
		{
			MessageBox(m_hWnd, L"��������ȷ�Ĺ�Ʊ����!", L"����", MB_OK);
			return;
		}
		pSData->SNO = strTmp.GetData();
		_set.FormateSNo(pSData->SNO);
	} while (0);

	do
	{
		if (!et_MinP) break;

		strTmp = et_MinP->GetText();
		duT = _ttof(strTmp.GetData());
		if (duT > 0.00001) pSData->MinP = duT;

	} while (0);


	do
	{
		if (!et_MaxP) break;
		strTmp = et_MaxP->GetText();
		duT = _ttof(strTmp.GetData());
		if (duT > 0.00001) pSData->MaxP = duT;
	} while (0);
	
	do 
	{
		if (!lst_Stock) break;
		StockPriceListElmUI  * pElm = NULL;
		StockPrice sPItem;
		for (int i = 0; i < lst_Stock->GetCount(); i++)
		{
			pElm = static_cast<StockPriceListElmUI*>(lst_Stock->GetItemAt(i));
			if (!pElm) continue;
			sPItem = pElm->GetSoctkPriceData();
			if (sPItem.nCount > 0 && sPItem.duPrice > 0.000001)
			{
				pSData->vctSPrice.push_back(sPItem);
			}
		}
	} while (0);

	Close();
}
void CStockDeatilDlg::OnCloseMe()
{
	pSData->SNO = L"";
	Close();
}

void CStockDeatilDlg::OnClick(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();
	if (strName == L"btnClose") this->OnCloseMe();
	if (strName == L"btn_Set") this->Save();
}

void CStockDeatilDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit")) OnPrepare();
	else if (msg.sType == _T("click"))
	{
		OnClick(msg);
	}
	else if (msg.sType == _T("AddSock"))
	{
		do
		{
			if (!lst_Stock) break;
			StockPriceListElmUI  * pElm = new StockPriceListElmUI;
			if (!pElm) break;
			pElm->SetOwner(lst_Stock);
			lst_Stock->Add(pElm);
		} while (0);
	}
	else if (msg.sType == _T("DelSock"))
	{
		do
		{
			if (!lst_Stock) break;
			if (lst_Stock->GetCount() < 2)
			{
				StockPriceListElmUI  * pElm = static_cast<StockPriceListElmUI*>(msg.pSender);
				if (pElm) pElm->ReSetData(); 
				break;
			}
			lst_Stock->Remove(msg.pSender);

		} while (0);
	}
	else if (msg.sType == _T("Time"))
	{
		pLastElm = static_cast<StockPriceListElmUI*>(msg.pSender);
		POINT pt;
		::GetCursorPos(&pt);
		pClaDlg->SetWindowsPost(pt);
		pClaDlg->ShowWindow(true, true);
	}
	if (msg.sType == DUI_MSGTYPE_ITEMSELECT)
	{
		CComboUI * pCmb = static_cast<CComboUI*>(msg.pSender);
		if (!et_stNo) return;
		if (pCmb->GetName() == L"cm_Other")
		{
			et_stNo->SetText(pCmb->GetItemAt(pCmb->GetCurSel())->GetUserData());
		}
	}
}

void CStockDeatilDlg::UpDataDate(CDuiString &strData)
{
	if (pLastElm) pLastElm->SetTime(strData);
}

void CStockDeatilDlg::SelectFinsh()
{
	if (pLastElm) pLastElm = NULL;
}

CControlUI* CStockDeatilDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockPriceListElm")) == 0) {
		return new StockPriceListElmUI;
	}
	return NULL;
}