#pragma once

#include "../DataDef/CfgSet.h" 
#include "../Control/StockNoteUI.h"

class InfoDlg : public WindowImplBase
{
public:
	InfoDlg();
	~InfoDlg();
	LPCTSTR  GetWindowClassName() const { return _T("StockInfoDlgUI"); }
	UINT     GetClassStyle() const { return CS_IME | CS_VREDRAW | CS_HREDRAW; ; }//CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("Info.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	static DWORD WINAPI WorkThread(LPVOID lpPara);
	void ShowWin(SData &sData);
	void AdustPost();
	void InfoDlg::CalcPos(int& x, int& y);

protected:
	void OnPrepare();

private:
	StockNote *pStockCont;
	APPBARDATA		m_ad;
};

