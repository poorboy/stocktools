#include "stdafx.h"
#include "CalSelDlg.h"
#include "../Control/ButtonExUI.h"
#include "DayRelLine.h"

CalSelDlg::CalSelDlg(IDNotify * _pPDlg)
{
	pPDlg = _pPDlg;
}

CalSelDlg::~CalSelDlg(void)
{
	if (pPDlg) pPDlg->SelectFinsh();
}

CControlUI* CalSelDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("ButtonEx")) == 0)
		return new CButtonExUI;
	return NULL;
}
void CalSelDlg::HideWind()
{
	if (pPDlg) pPDlg->SelectFinsh();
	this->ShowWindow(false, false);
}
void CalSelDlg::UpDateCal()
{
	CButtonExUI * pBnt = NULL;
	CDuiString strText;

	CTimeEx _Tim = CTimeEx(m_CurYear, m_CurMonth, 1, 0, 0, 0);

	UINT MonthOfDays = _Tim.GetMonthOfDays(m_CurYear, m_CurMonth);

	UINT FirstDay = _Tim.GetDayOfWeek() - 1;

	for (int i = 0; i < 35; )
	{
		strText.Format(L"cal_Bnt_%d", ++i);
		pBnt = static_cast<CButtonExUI*>(m_PaintManager.FindControl(strText));
		if (!pBnt) continue;
		pBnt->CleanInfo();
	}

	/*
		if (m_time.GetDayOfWeek() == 1) //����
		 if (m_time.GetDayOfWeek() == 7) //����
	*/

	int nDofW = 0;
	for (int i = 1; i <= MonthOfDays; i++)
	{
		strText.Format(L"cal_Bnt_%d", (i + FirstDay));
		pBnt = static_cast<CButtonExUI*>(m_PaintManager.FindControl(strText));
		if (!pBnt) continue;
		pBnt->SetTitle(m_CurYear, m_CurMonth, i);
		_Tim = CTimeEx(m_CurYear, m_CurMonth, i, 0, 0, 0);

		nDofW = _Tim.GetDayOfWeek();
		if (nDofW == 1 || nDofW == 7 || _Tim > m_cuuTime)
		{
			pBnt->SetEnabled(false);
		}
	}


	if (m_pCurentDate)
	{
		strText.SmallFormat(_T("%4d-%02d"), m_CurYear, m_CurMonth);
		m_pCurentDate->SetText(strText);
	}
}

void CalSelDlg::OnPrepare()
{
	m_pCurentDate = static_cast<CLabelUI*>(m_PaintManager.FindControl(_T("lab_year_month")));
	m_pCurentNote = static_cast<CLabelUI*>(m_PaintManager.FindControl(_T("lab_Notes")));

	CTimeEx tmpTime = CTimeEx::GetCurrentTime();
	m_cuuTime = CTimeEx(tmpTime.GetYear(), tmpTime.GetMonth(), tmpTime.GetDay(), 0, 0, 0);

	m_CurYear = m_cuuTime.GetYear();
	m_CurMonth = m_cuuTime.GetMonth();

	UpDateCal();
}

void CalSelDlg::SetMouseMoveNote(CDuiString &name, CControlUI * pControl)
{

	if (name == L"btn_monthcal_close")
	{
		m_pCurentNote->SetText(L"�ر�");

	}
	else if (name == _T("btn_month_next"))
	{
		//�¸��·� 
		m_pCurentNote->SetText(L"��һ��");
	}
	else if (name == _T("btn_month_last"))
	{
		//�ϸ��·�
		m_pCurentNote->SetText(L"��һ��");
	}
	else if (name == _T("btn_year_next"))
	{
		//��һ���
		m_pCurentNote->SetText(L"��һ��");
	}
	else if (name == _T("btn_year_last"))
	{
		//��һ��� 
		m_pCurentNote->SetText(L"��һ��");
	}
	else if (name.Find(L"cal_Bnt_") >= 0)
	{
		m_pCurentNote->SetText(pControl->GetUserData());
	}
}

void CalSelDlg::Notify(TNotifyUI& msg)
{
	CDuiString name = msg.pSender->GetName();

	if (msg.sType == _T("windowinit"))
	{
		OnPrepare();
		return;
	}
	else if (msg.sType == _T("click"))
	{
		if (name == L"btn_monthcal_close")
		{
			this->ShowWindow(false, false);
			return;
		}
		else if (name == _T("btn_month_next"))
		{
			//�����¸��·�
			if (m_CurMonth == 12)
			{
				++m_CurYear;
				m_CurMonth = 1;
			}
			else ++m_CurMonth;
			UpDateCal();
		}
		else if (name == _T("btn_month_last"))
		{
			//�����ϸ��·�
			if (m_CurMonth == 1)
			{
				--m_CurYear;
				m_CurMonth = 12;
			}
			else --m_CurMonth;
			UpDateCal();
		}
		else if (name == _T("btn_year_next"))
		{
			//������һ���
			++m_CurYear;
			UpDateCal();
		}
		else if (name == _T("btn_year_last"))
		{
			//������һ���
			--m_CurYear;
			UpDateCal();
		}
		else if (name.Find(L"cal_Bnt_") >= 0)
		{
			if (pPDlg)
			{
				CDuiString strData = msg.pSender->GetUserData();
				pPDlg->UpDataDate(strData);
				if (pPDlg->bOnClickClose) HideWind();
			}
		}
	}
	else if (msg.sType == DUI_MSGTYPE_MOUSEENTER/*DUI_MSGTYPE_SETFOCUS*/)
	{
		if (name == L"btn_monthcal_close")
		{
			m_pCurentNote->SetText(L"�ر�");

		}
		else if (name == _T("btn_month_next"))
		{
			//�¸��·� 
			m_pCurentNote->SetText(L"��һ��");

		}
		else if (name == _T("btn_month_last"))
		{
			//�ϸ��·�
			m_pCurentNote->SetText(L"��һ��");

		}
		else if (name == _T("btn_year_next"))
		{
			//��һ���
			m_pCurentNote->SetText(L"��һ��");

		}
		else if (name == _T("btn_year_last"))
		{
			//��һ��� 
			m_pCurentNote->SetText(L"��һ��");

		}
		else if (name.Find(L"cal_Bnt_") >= 0)
		{
			m_pCurentNote->SetText(msg.pSender->GetUserData());
		}
	}
	else if (msg.sType == DUI_MSGTYPE_MOUSEENTER)
	{
		SetMouseMoveNote(name, msg.pSender);
	}
	return;
}

LRESULT CalSelDlg::OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	HideWind();
	return 0;
}

void CalSelDlg::SetWindowsPost(POINT &pt)
{
	SIZE size = m_PaintManager.GetInitSize();
	//MoveWindow(GetHWND(), pt.x - static_cast<LONG>(size.cx / 2), pt.y - size.cy, size.cx, size.cy, FALSE);
	MoveWindow(GetHWND(), pt.x - static_cast<LONG>(size.cx / 2), pt.y, size.cx, size.cy, FALSE);
}

LRESULT CalSelDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);

	return false;
}

LRESULT CalSelDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}