#include "stdafx.h"
#include "setDlg.h"
#include "../DataDef/CommData.h"
#include "color_skin.h"

#define  SET_BKCLR(X,Y) if(X){ DWORD cr = Y; if(cr < 0xFF000000) cr +=0xFF000000; X->SetBkColor(cr);}
#define  SET_TXTCLR(X,Y) if(X){ DWORD cr = Y; if(cr < 0xFF000000) cr +=0xFF000000; X->SetTextColor(cr);}

#define SET_IF_BKCR(X, Y) if(msg.pSender == X){SET_BKCLR(Y, msg.pSender->GetBkColor());}
#define SET_IF_TXTCR(X, Y) if(msg.pSender == X){SET_TXTCLR(Y, msg.pSender->GetBkColor());}

CSetDlg::CSetDlg(void)
{
	pTabControl = NULL;
	lst_Stock = NULL;

	bnt_crMax = NULL;
	bnt_crMin = NULL;
	bnt_crMaxEx = NULL;
	bnt_crMinEx = NULL;

	bnt_crMaxExBK = NULL;
	bnt_crMinExBK = NULL;
	et_Brokerage = NULL;

	opt_IsShowInfo = NULL;

	lb_crMax = NULL;
	lb_crMin = NULL;
	lb_crMaxEx = NULL;
	lb_crMinEx = NULL;

	hk_ID1 = NULL;
	hk_ID2 = NULL;
	hk_ID3 = NULL;
	hk_ID4 = NULL;
	hk_ID5 = NULL;
	hk_ID6 = NULL;
	hk_ID7 = NULL;
	hk_ID8 = NULL;

}

CSetDlg::~CSetDlg(void)
{

}

UILIB_RESOURCETYPE CSetDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR CSetDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

void CSetDlg::OnPrepare()
{
	pTabControl = static_cast<CTabLayoutUI*>(m_PaintManager.FindControl(L"tabs"));

	lst_Stock = static_cast<CListUI*>(m_PaintManager.FindControl(L"lst_Stock"));
	bnt_crMax = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMax"));
	bnt_crMin = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMin"));
	bnt_crMaxEx = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMaxEx"));
	bnt_crMinEx = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMinEx"));
	bnt_crMaxExBK = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMaxExBK"));
	bnt_crMinExBK = static_cast<CButtonUI*>(m_PaintManager.FindControl(L"bnt_crMinExBK"));
	et_Brokerage = static_cast<CEditUI*>(m_PaintManager.FindControl(L"et_Brokerage"));

	opt_IsShowInfo = static_cast<COptionUI*>(m_PaintManager.FindControl(L"opt_IsShowInfo"));

	lb_crMax = static_cast<CLabelUI*>(m_PaintManager.FindControl(L"lb_crMax"));
	lb_crMin = static_cast<CLabelUI*>(m_PaintManager.FindControl(L"lb_crMin"));
	lb_crMaxEx = static_cast<CLabelUI*>(m_PaintManager.FindControl(L"lb_crMaxEx"));
	lb_crMinEx = static_cast<CLabelUI*>(m_PaintManager.FindControl(L"lb_crMinEx"));

	hk_ID1 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID1"));
	hk_ID2 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID2"));
	hk_ID3 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID3"));
	hk_ID4 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID4"));
	hk_ID5 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID5"));
	hk_ID6 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID6"));
	hk_ID7 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID7"));
	hk_ID8 = static_cast<CHotKeyUI *>(m_PaintManager.FindControl(L"hk_ID8"));


	lst_Stock->SetTextCallback(NULL);
	InitBaseSet();
	InitStock();
}

void CSetDlg::InitHotKey()
{
	if (hk_ID1) hk_ID1->SetText(_set.MapHotKey[1].GetKeyDes().c_str());
	if (hk_ID2) hk_ID2->SetText(_set.MapHotKey[2].GetKeyDes().c_str());
	if (hk_ID3) hk_ID3->SetText(_set.MapHotKey[3].GetKeyDes().c_str());
	if (hk_ID4) hk_ID4->SetText(_set.MapHotKey[4].GetKeyDes().c_str());
	if (hk_ID5) hk_ID5->SetText(_set.MapHotKey[5].GetKeyDes().c_str());
	if (hk_ID6) hk_ID6->SetText(_set.MapHotKey[6].GetKeyDes().c_str());
	if (hk_ID7) hk_ID7->SetText(_set.MapHotKey[7].GetKeyDes().c_str());
	if (hk_ID8) hk_ID8->SetText(_set.MapHotKey[8].GetKeyDes().c_str());

/*
��ʾ���������� hk_ID1
����ȡ����괩͸ hk_ID2
���¼������� hk_ID3
��ʾ���������� hk_ID4
���ʹ���͸���� hk_ID5
��ߴ���͸���� hk_ID6
��ʾ������ͣ��ʾ���� hk_ID8
�˳����� hk_ID7
*/ 

}

void CSetDlg::AddItem2List(int index)
{
	CStockListElmUI * pElm = new CStockListElmUI;
	if (!pElm) return;
	pElm->SetOwner(lst_Stock);
	pElm->SetStockData(index);
	lst_Stock->Add(pElm);
}

void CSetDlg::InitStock()
{
	if (!lst_Stock)return;

	CDuiString strTmp;
	for (int i = 0; i < g_sData.size(); i++)
		AddItem2List(i);

	if (lst_Stock->GetCount() < 1) AddItem2List(-1);

}
 
void CSetDlg::GetColorSet()
{												
	_SData::dwCrMax = bnt_crMax->GetBkColor();
	_SData::dwCrMin = bnt_crMin->GetBkColor();
	_SData::dwCrMaxEx = bnt_crMaxEx->GetBkColor();
	_SData::dwCrMinEx = bnt_crMinEx->GetBkColor();
	_SData::dwCrMaxExBK = bnt_crMaxExBK->GetBkColor();
	_SData::dwCrMinExBK = bnt_crMinExBK->GetBkColor(); 
}

void CSetDlg::GetHotKeyInfo(CHotKeyUI * phkC, int nIndex)
{
	if (!phkC) return;

	if(phkC->GetKeyInfo(_set.MapHotKey[nIndex].dwHotKey,
		_set.MapHotKey[nIndex].chKey))

		_set.MapHotKey[nIndex].UpKeyDes();

	/*
	��ʾ���������� hk_ID1
	����ȡ����괩͸ hk_ID2
	���¼������� hk_ID3
	��ʾ���������� hk_ID4
	���ʹ���͸���� hk_ID5
	��ߴ���͸���� hk_ID6
	�˳����� hk_ID7
	��ʾ������ͣ��ʾ���� hk_ID8
	*/
}

void CSetDlg::GetHotKeyInfoS()
{
	GetHotKeyInfo(hk_ID1, 1);
	GetHotKeyInfo(hk_ID2, 2);
	GetHotKeyInfo(hk_ID3, 3);
	GetHotKeyInfo(hk_ID4, 4);
	GetHotKeyInfo(hk_ID5, 5);
	GetHotKeyInfo(hk_ID6, 6);
	GetHotKeyInfo(hk_ID7, 7);
	GetHotKeyInfo(hk_ID8, 8);

}


void CSetDlg::InitHotKeyInfo()
{
	if (hk_ID1)
	{
		hk_ID1->SetText(_set.MapHotKey[1].GetKeyDes().c_str());
		hk_ID1->SetToolTip(_set.MapHotKey[1].strName.c_str());
	}

	if (hk_ID2)
	{
		hk_ID2->SetText(_set.MapHotKey[2].GetKeyDes().c_str());
		hk_ID2->SetToolTip(_set.MapHotKey[2].strName.c_str());
	}
	if (hk_ID3)
	{
		hk_ID3->SetText(_set.MapHotKey[3].GetKeyDes().c_str());
		hk_ID3->SetToolTip(_set.MapHotKey[3].strName.c_str());
	}
	if (hk_ID4)
	{
		hk_ID4->SetText(_set.MapHotKey[4].GetKeyDes().c_str());
		hk_ID4->SetToolTip(_set.MapHotKey[4].strName.c_str());
	}
	if (hk_ID5)
	{
		hk_ID5->SetText(_set.MapHotKey[5].GetKeyDes().c_str());
		hk_ID5->SetToolTip(_set.MapHotKey[5].strName.c_str());
	}
	if (hk_ID6)
	{
		hk_ID6->SetText(_set.MapHotKey[6].GetKeyDes().c_str());
		hk_ID6->SetToolTip(_set.MapHotKey[6].strName.c_str());
	}
	if (hk_ID7)
	{
		hk_ID7->SetText(_set.MapHotKey[7].GetKeyDes().c_str());
		hk_ID7->SetToolTip(_set.MapHotKey[7].strName.c_str());
	}
	if (hk_ID8)
	{
		hk_ID8->SetText(_set.MapHotKey[8].GetKeyDes().c_str());
		hk_ID8->SetToolTip(_set.MapHotKey[8].strName.c_str());
	}

}

void CSetDlg::InitBaseSet()
{
	CDuiString strTmp;
	SET_BKCLR(bnt_crMax, _SData::dwCrMax);
	SET_BKCLR(bnt_crMin, _SData::dwCrMin);
	SET_BKCLR(bnt_crMaxEx, _SData::dwCrMaxEx);
	SET_BKCLR(bnt_crMinEx, _SData::dwCrMinEx);
	SET_BKCLR(bnt_crMaxExBK, _SData::dwCrMaxExBK);
	SET_BKCLR(bnt_crMinExBK, _SData::dwCrMinExBK);

	SET_TXTCLR(lb_crMax, _SData::dwCrMax);
	SET_TXTCLR(lb_crMin, _SData::dwCrMin);
	SET_TXTCLR(lb_crMaxEx, _SData::dwCrMaxEx);
	SET_TXTCLR(lb_crMinEx, _SData::dwCrMinEx);
	SET_BKCLR(lb_crMaxEx, _SData::dwCrMaxExBK);
	SET_BKCLR(lb_crMinEx, _SData::dwCrMinExBK);

	strTmp.Format(L"%f", _SData::_duBrokerage);
	if (et_Brokerage) et_Brokerage->SetText(strTmp.GetData());
	if (opt_IsShowInfo) opt_IsShowInfo->Selected(_set.IsShowInfoDlg());
	InitHotKeyInfo();
}

void CSetDlg::Saves()
{
	GetHotKeyInfoS();
	GetColorSet();

	if (opt_IsShowInfo) _set.SetShowInfoDlg(opt_IsShowInfo->IsSelected());
	_set.Save2Cfg();
	Close(1); 
}
void CSetDlg::OnCloseMe()
{
	Close(0);
}

void CSetDlg::OnClick(TNotifyUI& msg)
{
	CDuiString strName = msg.pSender->GetName();
	if (strName == L"btnClose") this->OnCloseMe();
	if (strName == L"btn_Set") Saves();

	if (strName.Find(L"bnt_cr") >= 0)
	{
		ColorSkinWindow pColorDlg(m_hWnd, msg.pSender);

		bool bIsBk = false;
		CLabelUI * pCont = NULL;
		if (msg.pSender == bnt_crMax) pCont = lb_crMax;
		else if (msg.pSender == bnt_crMin) pCont = lb_crMin;
		else if (msg.pSender == bnt_crMaxEx) pCont = lb_crMaxEx;
		else if (msg.pSender == bnt_crMinEx) pCont = lb_crMinEx;
		else if (msg.pSender == bnt_crMaxExBK)
		{
			bIsBk = true;
			pCont = lb_crMaxEx;
		}
		else if (msg.pSender == bnt_crMinExBK)
		{
			pCont = lb_crMinEx;
			bIsBk = true;
		}

		if (!pCont) return;

		DWORD cr = msg.pSender->GetBkColor();
		if (cr < 0xFF000000) cr += 0xFF000000;

		if (bIsBk) pCont->SetBkColor(cr);
		else  pCont->SetTextColor(cr);

		//SET_IF_TXTCR(bnt_crMax, lb_crMax);
		//SET_IF_TXTCR(bnt_crMin, lb_crMin);
		//SET_IF_TXTCR(bnt_crMaxEx, lb_crMaxEx);
		//SET_IF_TXTCR(bnt_crMinEx, lb_crMinEx);

		//SET_IF_BKCR(bnt_crMaxExBK, lb_crMaxEx);
		//SET_IF_BKCR(bnt_crMinExBK, lb_crMinEx);
	}

}
void CSetDlg::OnFinalMessage(HWND hWnd)
{
	WindowImplBase::OnFinalMessage(hWnd);
	delete this;
}
void CSetDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit")) OnPrepare();
	else if (msg.sType == _T("click"))
	{
		OnClick(msg);
	}
	else if (msg.sType == DUI_MSGTYPE_SELECTCHANGED)
	{
		if (!pTabControl) return;
		if (strName == L"set1") pTabControl->SelectItem(0);
		else if (strName == L"set2") pTabControl->SelectItem(1);
		else if (strName == L"set3") pTabControl->SelectItem(2);
	}
	else if (msg.sType == L"AddSock")
	{
		_SData tItem;
		CStockDeatilDlg _Dlg(*this, &tItem);
		if (tItem.SNO.length() < 3) return;
		g_sData.push_back(tItem);
		AddItem2List(g_sData.size() - 1);
	}
	else if (msg.sType == L"ModSock")
	{
		int nIndex = (int)msg.wParam;
		_SData tItem = g_sData[nIndex];
		CStockDeatilDlg _Dlg(*this, &tItem); 
		if (tItem.SNO.length() < 3) return; 
		g_sData[nIndex] = tItem;
		CStockListElmUI * pTmp = static_cast<CStockListElmUI *>(msg.pSender);
		if (pTmp)pTmp->SetStockData(nIndex);
	}
	else if (msg.sType == L"DelSock")
	{
		do
		{
			RemoveItem2Vct((int)msg.wParam);
			if (!lst_Stock) break;
			if (lst_Stock->GetCount() < 2) break;
			lst_Stock->Remove(msg.pSender);
		} while (0);
	}
	else if(msg.sType == L"Up")
	{
		CStockListElmUI * pTmp = static_cast<CStockListElmUI *>(msg.pSender);
		if (!(pTmp&& lst_Stock)) return;
		int nAt = lst_Stock->GetItemIndex(pTmp);
		if (nAt < 1) return;
		lst_Stock->SetItemIndex(pTmp, nAt - 1);
	}
	else if (msg.sType == L"Down")
	{
		CStockListElmUI * pTmp = static_cast<CStockListElmUI *>(msg.pSender);
		if (!(pTmp&& lst_Stock)) return; 
		int nAt = lst_Stock->GetItemIndex(pTmp);
		if (nAt > lst_Stock->GetCount() - 1) return;
		lst_Stock->SetItemIndex(pTmp, nAt + 1);
	}
}

void CSetDlg::RemoveItem2Vct(int nIndex)
{
	if (nIndex < 0) return; 
	if (nIndex >= g_sData.size()) return;

	vector<SData> t_sData;
	for (int i=0; i< g_sData.size(); i++)
	{
		if (i == nIndex) continue;
		t_sData.push_back(g_sData[i]); 
	}
	g_sData = t_sData;
}

LRESULT CSetDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT CSetDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->OnCloseMe();
	return false;
}

int CSetDlg::ShowWind()
{
	Create(NULL,
		_T("CSetDlg"),
		UI_WNDSTYLE_DIALOG,
		WS_EX_TOPMOST | WS_EX_TOOLWINDOW, 0, 0);

	this->CenterWindow();
	return this->ShowModal();
}

CControlUI* CSetDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("HotKey")) == 0) 
	{
		return new CHotKeyUI;
	}
	return NULL;
}