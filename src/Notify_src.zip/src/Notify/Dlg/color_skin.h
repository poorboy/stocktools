#ifndef COLORSKIN_HPP
#define COLORSKIN_HPP 
using namespace DuiLib;

class ColorSkinWindow : public WindowImplBase
{
public:
	ColorSkinWindow(HWND _hwnd, CControlUI * pBkCont);

	LPCTSTR  GetWindowClassName() const { return _T("ColorSkinWindow"); }
	UINT     GetClassStyle() const { return CS_DBLCLKS; }
	virtual CDuiString  GetSkinFile() { return _T("ColorWnd.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;

	virtual void OnFinalMessage(HWND hWnd);
	void OnPrepare();
	void Notify(TNotifyUI& msg);
	void UpDataColor(DWORD cr, bool bSet = false); 
	virtual void InitWindow();
	virtual LRESULT OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

private: 
	CHorizontalLayoutUI *  pHColorLayout; 
	CControlUI * lb_crTxt;
	CControlUI * lb_crBK; 

	CSliderUI* AdjustColorSliderR;
	CSliderUI* AdjustColorSliderG;
	CSliderUI* AdjustColorSliderB;

	POINT m_pt;
	DWORD m_dwOldColor;

	CControlUI * pBkCont;

};

#endif // COLORSKIN_HPP