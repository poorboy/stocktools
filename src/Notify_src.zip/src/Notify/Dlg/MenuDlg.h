#pragma once

class MainDlg;

class MenuDlg : public WindowImplBase
{
public:
	MenuDlg(MainDlg * pMainDlg);
	~MenuDlg();
	LPCTSTR  GetWindowClassName() const { return _T("MenuDlgUI"); }
	UINT     GetClassStyle() const { return CS_IME | CS_VREDRAW | CS_HREDRAW; ; }//CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("mainMenu.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	 
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled); 
	LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	
	void InitMenuItem();
	void ShowMenu();
	void AdustPost();
	void CalcPos(int& x, int& y);
	void CreateWin();

protected:
	void OnPrepare();

private:
	APPBARDATA		m_ad;
	MainDlg *  _pMainDlg;
 
	CSliderUI *pSliderUI;
	COptionUI *pOptShowMainDlg;
	COptionUI *pOptTips;
	COptionUI *pOptShowTatol;
	COptionUI *pOptMoustTran;
	COptionUI *pOptTrayIcon;

};

