#pragma once
#include "CalSelDlg.h"
#include "../Control/StockPriceListElmUI.h"

class CStockDeatilDlg : public WindowImplBase, public IDNotify
{
public:
	CStockDeatilDlg(HWND _pHwnd, _SData * pSData);
	~CStockDeatilDlg();
	LPCTSTR  GetWindowClassName() const { return _T("CStockDeatilDlg"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_DIALOG; }//UI_CLASSSTYLE_FRAME CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("StockDetail.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	virtual void UpDataDate(CDuiString &strData);
	virtual void SelectFinsh();
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);
	void OnClick(TNotifyUI& msg);
	void OnCloseMe();
	void InitStock();
	void Save();
	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
protected:
	void OnPrepare();

	CListUI * lst_Stock;
	CEditUI * et_MinP;
	CEditUI * et_stNo;
	CEditUI * et_MaxP;
	CalSelDlg * pClaDlg;
	StockPriceListElmUI  * pLastElm;
	_SData * pSData;
};

