﻿#include "StdAfx.h"
#include "MainDlg.h" 
#include <Shlobj.h>
#include <time.h>
#include <Psapi.h>
#include <CommDlg.h>
#include "../../commApi/debugnew.h"
#include "../DataDef/CommData.h"
#include "../Utils/NetOpr.h"
#include "../Control/UIMenu.h"
#include "color_skin.h"
#include "SetDlg.h"
#include "zjDlg.h" 

///////////////////////////////////////////////////////////////////////////////////////
DECLARE_HANDLE(HZIP);	// An HZIP identifies a zip file that has been opened
typedef DWORD ZRESULT;
typedef struct
{
	int index;                 // index of this file within the zip
	char name[MAX_PATH];       // filename within the zip
	DWORD attr;                // attributes, as in GetFileAttributes.
	FILETIME atime, ctime, mtime;// access, create, modify filetimes
	long comp_size;            // sizes of item, compressed and uncompressed. These
	long unc_size;             // may be -1 if not yet known (e.g. being streamed in)
} ZIPENTRY;
typedef struct
{
	int index;                 // index of this file within the zip
	TCHAR name[MAX_PATH];      // filename within the zip
	DWORD attr;                // attributes, as in GetFileAttributes.
	FILETIME atime, ctime, mtime;// access, create, modify filetimes
	long comp_size;            // sizes of item, compressed and uncompressed. These
	long unc_size;             // may be -1 if not yet known (e.g. being streamed in)
} ZIPENTRYW;
#define OpenZip OpenZipU
#define CloseZip(hz) CloseZipU(hz)
extern HZIP OpenZipU(void *z, unsigned int len, DWORD flags);
extern ZRESULT CloseZipU(HZIP hz);
#ifdef _UNICODE
#define ZIPENTRY ZIPENTRYW
#define GetZipItem GetZipItemW
#define FindZipItem FindZipItemW
#else
#define GetZipItem GetZipItemA
#define FindZipItem FindZipItemA
#endif
extern ZRESULT GetZipItemA(HZIP hz, int index, ZIPENTRY *ze);
extern ZRESULT GetZipItemW(HZIP hz, int index, ZIPENTRYW *ze);
extern ZRESULT FindZipItemA(HZIP hz, const TCHAR *name, bool ic, int *index, ZIPENTRY *ze);
extern ZRESULT FindZipItemW(HZIP hz, const TCHAR *name, bool ic, int *index, ZIPENTRYW *ze);
extern ZRESULT UnzipItem(HZIP hz, int index, void *dst, unsigned int len, DWORD flags);
///////////////////////////////////////////////////////////////////////////////////////


#define  DOWN_NAME        "Notify.7z"
#define  SOFT_NAME        "股价提醒小工具"
#define  SOFT_VER          "V0.001"

//#define XML_FROM_RES


const UINT WM_TASKBARCREATED = ::RegisterWindowMessage(_T("TaskbarCreated"));

#define  SET_CONTROL_BY_NAME(X,Y) ENABLE_CONTROL_BY_NAME(X, Y, m_PaintManager);

#define  GET_OPT_SELECT(X, Y)      { Y = false; COptionUI * pOpt = static_cast<COptionUI *> (m_PaintManager.FindControl(X)); if(pOpt) Y = pOpt->IsSelected(); }
#define  SET_OPT_SELECT(X, Y)      { COptionUI * pOpt = static_cast<COptionUI *> (m_PaintManager.FindControl(X)); if(pOpt) pOpt->Selected(Y,false); }



#define WM_MSG_ADD_SCAN_LOG      WM_USER + 1
#define WM_MSG_SHOW_MAIN_WND     WM_USER + 2 
#define IDR_EXIT                 14
#define IDR_SHOW                 15  
#define IDR_SET_TRAN             16  
#define IDR_RELOADCFG            17  
#define IDR_SHOWORHIDETOTAL      19  
#define IDR_ADD_OPACTIY          20  
#define IDR_SUB_OPACTIY          21  
#define IDR_SHOWORHIDEINFODLG    22  

#define  SELF_CLOS(X) if(X){X->Close(); delete X;}

//#define WM_MYHOTKEY        WM_USER + 1000 
//#define WM_HOTKEY_SUB_OPACITY  WM_USER + 1001 
//#define WM_HOTKEY_ADD_OPACITY  WM_USER + 1002  
//#define WM_MOUSE_TRANS         WM_USER + 1003 
//#define WM_EXIT_APP            WM_USER + 1004 
//#define WM_RELOAD_CFG          WM_USER + 1005 
//#define WM_SHOW_TOTAL          WM_USER + 1005 


//WS_EX_TRANSPARENT
//WM_MOUSE_TRANS

void GetStringVct(string &strData, vector<string> &vctItem)
{
	string tmp;
	vctItem.clear();
	int nFst = strData.find("=\"");
	int nEnd = strData.find("\";");
	int nLen = 0;

	while (nEnd != string::npos)
	{
		nFst += 2;
		nLen = nEnd - nFst;
		tmp = strData.substr(nFst, nLen);
		vctItem.push_back(tmp);
		nFst = strData.find("=\"", nEnd);

		if (nFst == string::npos) break;
		nEnd = strData.find("\";", nFst);
	}
}

void AnalyzeItem(string &strData, _SData &Item)
{
	char ch = ' ';
	string strTmp = "";
	Item.vctFd.clear();
	for (int i = 0; i < strData.length(); i++)
	{
		ch = strData[i];

		if (ch == ',')
		{
			if (strTmp[0] == '0' && strTmp[0] == '0' && strTmp.size() > 1 && strTmp.find(':') == string::npos)
				strTmp = strTmp.substr(2);

			Item.vctFd.push_back(C2Unicode(strTmp.c_str()));
			strTmp = "";
		}
		else strTmp += ch;
	}
	Item.analyze();
}

void GetStockVctData(vector<string> &vctItem)
{
	if (vctItem.size() < 1) return;

	string tmp = "";
	for (int i = 0; i < g_sData.size(); i++)
	{
		tmp = vctItem[i];
		_SData &item = g_sData[i];
		AnalyzeItem(tmp, item);
	}


	map <wstring, vector<SData>>::iterator itr = g_Groub.begin();
	int nStart = g_sData.size() - 1;
	int nEnd = 0;
	for (; itr != g_Groub.end(); ++itr)
	{
		vector<SData> &vct = itr->second;
		nEnd = nStart + vct.size();
		int inx = 0;
		for (; nStart<nEnd; nStart++)
		{
			tmp = vctItem[nStart];
			_SData &item = vct[inx++];
			AnalyzeItem(tmp, item);
		} 
	}
}

MainDlg::MainDlg(void)
{
	//执行导出的线程具柄
	hThread = NULL;
	pStockCont = NULL;
	pH1 = NULL;

	pbk_ver = NULL;
	//执行导出的线程ID
	threadId = 0;

	pInfoDlg = NULL;
	pChartDlg = NULL;
	pDayRelDlg = NULL;
	pGruopDlg = NULL;

	nLastHotIndex = -1;
	//// 9:30  //9:30_11:30 下午13:00_15;00
	CDuiString strYear = CTimeEx::GetCurrentTime().ToString().c_str();

	CDuiString strTmp = strYear;
	strTmp.Append(L" 9:00");
	OpenTime1 = CTimeEx(strTmp);

	strTmp = strYear;
	strTmp.Append(L" 11:31");
	CloseTime1 = CTimeEx(strTmp);

	strTmp = strYear;
	strTmp.Append(L" 12:59");
	OpenTime2 = CTimeEx(strTmp);

	strTmp = strYear;
	strTmp.Append(L" 15:01");
	CloseTime2 = CTimeEx(strTmp);
	bIsNeedAdd2Tary = false;
	
}

MainDlg::~MainDlg(void)
{
	SELF_CLOS(pChartDlg);
	SELF_CLOS(pInfoDlg);
	SELF_CLOS(pDayRelDlg);
	SELF_CLOS(pMenu);
	SELF_CLOS(pGruopDlg); 
}

wstring GetVctNoID(vector<SData> &vct)
{
	wstring strID;
	for (int i = 0; i < vct.size(); i++)
	{
		SData item = g_sData.at(i);
		strID.append(item.SNO);
		strID.append(L",");
	}

	return strID;
}

wstring GetGroupStr()
{
	wstring strID;
	map <wstring, vector<SData>>::iterator itr = g_Groub.begin();
	for (; itr != g_Groub.end(); ++itr)
	{
		strID.append(GetVctNoID(itr->second));
	} 

	return strID;
}

void MainDlg::UpStockData()
{
	wstring strUrl = L"http://hq.sinajs.cn/list=";
	//vector<SData> &g_sData = pStockCont->GetSockData();
	//_set.g_sData.size()
	//for (int i = 0; i < g_sData.size(); i++)
	//{
	//	SData item = g_sData.at(i);
	//	strUrl.append(item.SNO);
	//	strUrl.append(L",");
	//}


	strUrl.append(GetVctNoID(g_sData));
	strUrl.append(GetGroupStr());

	string strData = GetNetData(strUrl);

	vector<string> vctItem;
	GetStringVct(strData, vctItem);
	GetStockVctData(vctItem);

	if (pStockCont) pStockCont->Invalidate();
	//lstTime
	CControlUI * pCont = m_PaintManager.FindControl(L"lstTime");

	if (!pCont || g_sData.size() < 1) return;

	vector<wstring> &strVct = g_sData.at(0).vctFd;
	int nSize = strVct.size();
	if (nSize < 1) return;

	{
		CDuiString strTitle;
		strTitle.Format(L"更新时间:%s", strVct[nSize - 1].c_str());
		//, CTimeEx::GetCurrentTime().GetTimeStr().c_str()
		pCont->SetText(strTitle);
	}
}

void MainDlg::SetMouseTran()
{
	//设置取消鼠标穿透
	DWORD dwExStyle = ::GetWindowLong(m_hWnd, GWL_EXSTYLE);
	if (pStockCont) pStockCont->HideCaret();
	int nFlg = 0;
	CDuiString strBkImg = L"file='login_bg.png' corner='3,3,3,3' ";

	if (dwExStyle & WS_EX_TRANSPARENT) dwExStyle &= ~(WS_EX_NOACTIVATE | WS_EX_TRANSPARENT);
	else
	{
		nFlg = RGB(255, 255, 255);
		dwExStyle |= (WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
		strBkImg = L"file='login_bg.png' corner='3,3,3,3' source='20,20,40,40'";
	}

	if (pbk_ver) pbk_ver->SetBkImage(strBkImg);
	if (pH1) pH1->SetVisible(nFlg == 0);

	::SetWindowLong(m_hWnd, GWL_EXSTYLE, dwExStyle);
 
	m_PaintManager.SetOpacity(m_PaintManager.GetOpacity(), nFlg);
	//SetLayeredWindowAttributes(m_hWnd, nFlg, 0, LWA_COLORKEY); 

	if (nFlg > 0)
	{
		if (pInfoDlg) pInfoDlg->ShowWindow(false);
		if (pChartDlg) pChartDlg->ShowWindow(false);
		if (pGruopDlg) pGruopDlg->ShowWindow(false); 
		if (pStockCont) pStockCont->Invalidate();
	}
}


void MainDlg::AdjustPost()
{
	RECT rcScreen;
	::GetWindowRect(GetDesktopWindow(), &rcScreen);
	SIZE sz = m_PaintManager.GetInitSize();
	int x = rcScreen.right - 250;// sz.cx - 20;
	int y = 100;// ((rcScreen.bottom - rcScreen.top) - sz.cy) / 2;
	::MoveWindow(m_hWnd, x, y, sz.cx, sz.cy, TRUE);
}

UILIB_RESOURCETYPE MainDlg::GetResourceType() const
{
	//UILIB_FILE=1,				// 来自磁盘文件
	//UILIB_ZIP,				// 来自磁盘zip压缩包
	//UILIB_RESOURCE,			// 来自资源
	//UILIB_ZIPRESOURCE,	// 来自资源的zip压缩包
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR MainDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

bool MainDlg::RegHotKey()
{
	bool bRet = true;
	CDuiString strRet = L"";
	if (!_set.RegHotKey(strRet, m_hWnd))
	{
		bIsNeedAdd2Tary = true;
		bRet = false;
		AddIcon2Tary();
		DWORD dwExStyle = ::GetWindowLong(m_hWnd, GWL_EXSTYLE);
		if (dwExStyle & WS_EX_TRANSPARENT)  SetMouseTran();
		ShowTips(strRet.GetData(), 15);
		//MessageBox(NULL, strRet.GetData(), L"注册热键失败", MB_OK);
	}
	return bRet;
}

void MainDlg::UpDataTaryIcon()
{
	if (bIsNeedAdd2Tary)
	{
		bIsNeedAdd2Tary = false;
		Shell_NotifyIcon(NIM_DELETE, &m_nid);
	}
	else
	{
		bIsNeedAdd2Tary = true;
		AddIcon2Tary();
	}
}

#include "../utils/NetData.h"

void MainDlg::UnRegHotKey()
{
	_set.UnRegHotKey(m_hWnd);
}

void MainDlg::OnPrepare()
{
	//SetIcon(IDR_MAINFRAME);

	hThread = CreateThread(
		NULL,
		0,
		MainDlg::WorkThread,
		(LPVOID)this,
		0,
		&threadId
	);

	//m_PaintManager.SetLayered(true);
	//m_PaintManager.SetOpacity(80);
	
	pStockCont = static_cast<CStockPriceUI *>(m_PaintManager.FindControl(_T("stock")));


	pH1 = m_PaintManager.FindControl(_T("hr_foor"));
	pbk_ver = m_PaintManager.FindControl(_T("bk_ver"));

	if (pH1) pH1->SetBkColor(RGB(255, 0, 0));

	UpStockData();
	if (!hThread) SetTimer(m_hWnd, 1, 3000, NULL);

	InitDlg();

	AdjustPost();
	//_set.UpShowInfo();
	//SetMouseTran();
	CreateMenu();
	RegHotKey(); 

	//// Ask the window and its children to repaint  
	//RedrawWindow(m_hWnd,
	//	NULL,
	//	NULL,
	//	RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);

	//NetStockData _data;

	//string sz_data = _data.GetStockData(g_sData[0].SNO);
	//sz_data = _data.GetStockData(g_sData[0].SNO, URL_TYPE_Hexun);

}
void MainDlg::AddIcon2Tary()
{
	m_nid.cbSize = sizeof(m_nid);
	m_nid.hWnd = *this;
	m_nid.uID = 0;
	m_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	m_nid.uCallbackMessage = WM_USER;
	//128
	m_nid.hIcon = LoadIcon(DuiLib::CPaintManagerUI::GetInstance(), MAKEINTRESOURCE(107));
	lstrcpy(m_nid.szTip, L"小工具");
	Shell_NotifyIcon(NIM_SETVERSION, &m_nid);
	Shell_NotifyIcon(NIM_ADD, &m_nid);
	//Shell_NotifyIcon(NIM_DELETE, &m_nid);

}
void MainDlg::ShowTips(LPCTSTR tisp, DWORD  flg)
{
	wcscpy_s(m_nid.szTip, _T("小工具"));
	wcscpy_s(m_nid.szInfo, tisp);
	wcscpy_s(m_nid.szInfoTitle, _T("小工具"));
	m_nid.uVersion = NOTIFYICON_VERSION_4; //打开高版本    
										   //m_nid.dwInfoFlags= NIIF_USER | NIIF_LARGE_ICON ;    //打开自定义及大图标提示    

	m_nid.uFlags = NIF_INFO;
	// respect quiet time since this balloon did not come from a direct user action.
	m_nid.dwInfoFlags = flg;
	Shell_NotifyIcon(NIM_MODIFY, &m_nid);
}

int MainDlg::GetOpacityValue()
{
	return (int)m_PaintManager.GetOpacity();
}

void MainDlg::UpOpacity(int nValue)
{
	DWORD cr = 0;
	if (pStockCont && pStockCont->IsWindTrans())
		cr = RGB(255, 255, 255);

	m_PaintManager.SetOpacity(nValue, cr);

	CControlUI * pCont = m_PaintManager.FindControl(L"appl");
	if (pCont)
	{
		CDuiString strTitle;
		strTitle.Format(L"窗口透明度:%d", nValue);
		pCont->SetText(strTitle);
	}
}

void MainDlg::Notify(TNotifyUI& msg)
{
	CDuiString strClass = msg.pSender->GetClass();
	CDuiString strName = msg.pSender->GetName();

	if (msg.sType == _T("windowinit"))  OnPrepare();
	else if (msg.sType == _T("click"))  OnClick(msg);
	else if (msg.sType == L"SNOCHANGS") UpStockData();
	else if (msg.sType == L"SHOW_CHART_DLG")
	{
		int nInx = msg.wParam;
		int nItem = msg.lParam;

		if (nInx < 0) return;

		if (nItem == 2 && pChartDlg)
		{
			CDuiString sNo = g_sData[nInx].SNO.c_str();
			pChartDlg->ShowWin(sNo);
		}

		if (nItem == 3 && pDayRelDlg)
		{
			CDuiString sNo = g_sData[nInx].SNO.c_str();
			pDayRelDlg->ShowWin(g_sData[nInx]);
		}
	}
	else if (msg.sType == L"MOUSEMOVE")
	{
		if (!_set.IsShowInfoDlg()) return;
		if (!pInfoDlg) return;

		int nInx = msg.wParam;
		if (nInx >= 0)
		{
			if (nInx != nLastHotIndex) pInfoDlg->ShowWin(g_sData[nInx]);
			else pInfoDlg->AdustPost();
		}
		else {

			pInfoDlg->ShowWindow(false);
			wstring str = (LPWSTR)msg.lParam;
			//pGruopDlg
		}
	}
	else if (msg.sType == DUI_MSGTYPE_MOUSELEAVE)
	{
		if (pChartDlg) pChartDlg->ShowWindow(false);
	}
	else if (msg.sType == L"CONTEXTMENU")
	{
		ShowMenu();
	}
}

void MainDlg::OnClick(TNotifyUI& msg)
{

	CDuiString strName = msg.pSender->GetName();

	if (strName == L"reLoad")
	{
		ReLoadCfg();
	}
	else if (strName == L"exit")
	{
		Close();
	}
	else if(strName == L"bnt_zj")
	{
		DoSShowZJDlg();
	}
}


LRESULT MainDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT MainDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bExit = true;
	if (bIsNeedAdd2Tary) Shell_NotifyIcon(NIM_DELETE, &m_nid);
	UnRegHotKey();
	PostQuitMessage(0);
	if (!hThread) KillTimer(m_hWnd, 1);
	return 0;
}

LRESULT MainDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	return false;
}

void MainDlg::InitDlg()
{
	pChartDlg = new ChartDlg();
	if (pChartDlg)
	{
		DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;
		pChartDlg->CreateDuiWindow(NULL,
			_T("StockChartDlgUI"),
			UI_WNDSTYLE_FRAME,
			dwExstyle);
		::ShowWindow(*pChartDlg, SW_HIDE);
	}

	pInfoDlg = new InfoDlg();
	if (pInfoDlg)
	{
		DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;
		pInfoDlg->CreateDuiWindow(NULL,
			_T("StockInfoDlgUI"),
			UI_WNDSTYLE_FRAME,
			dwExstyle);

		::ShowWindow(*pInfoDlg, SW_HIDE);
	}

	//pGruopDlg = new GroupDlg();
	//if (pGruopDlg)
	//{
	//	DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW;
	//	pGruopDlg->CreateDuiWindow(NULL,
	//		_T("GruopDlg"),
	//		UI_WNDSTYLE_FRAME,
	//		dwExstyle);

	//	::ShowWindow(*pGruopDlg, SW_HIDE);
	//}


	pDayRelDlg = new DayRelLineDlg();
	if (pDayRelDlg)
	{
		DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;
		pDayRelDlg->CreateDuiWindow(NULL,
			_T("pDayRelDlgUI"),
			WS_POPUP/*UI_WNDSTYLE_FRAME*/,
			dwExstyle);
		//::ShowWindow(*pDayRelDlg, SW_HIDE);
	}

	pMenu = new MenuDlg(this);
	if (pMenu) pMenu->CreateWin();
}
void MainDlg::ShowMenu()
{
	if (pMenu) pMenu->ShowMenu();
}

void MainDlg::OnTrayMsg(WPARAM wParam, LPARAM lParam)
{
	switch (lParam)
	{
	case WM_LBUTTONDBLCLK: SetWinVisb();  break;
	case WM_RBUTTONDOWN: ShowMenu(); break;
		break;
	}
	//::SetForegroundWindow(GetHWND());  
}

LRESULT MainDlg::HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (uMsg == WM_TIMER)	OnTimer(uMsg, wParam, lParam, bHandled);
	else if (WM_HOTKEY == uMsg) OnHotKey(uMsg, wParam, lParam, bHandled);
	else if (WM_KILLFOCUS == uMsg && pStockCont) pStockCont->HideCaret();
	else if (uMsg == WM_TASKBARCREATED)
	{
		if (bIsNeedAdd2Tary) AddIcon2Tary();
		bHandled = TRUE;
	}
	else if (uMsg == WM_USER)
	{
		OnTrayMsg(wParam, lParam);
		bHandled = TRUE;
	}
	return 1L;
}

void MainDlg::SetWinVisb()
{
	//显示隐藏界面 
	if (pInfoDlg && IsWindowVisible(GetHWND()))
		pInfoDlg->ShowWindow(false);

	if (pGruopDlg && IsWindowVisible(GetHWND()))
		pGruopDlg->ShowWindow(false);
	
	::ShowWindow(GetHWND(), IsWindowVisible(GetHWND()) ? SW_HIDE : SW_SHOW);
}

void MainDlg::ShowOrHideTotal()
{
	//显示隐藏总收益(伸缩窗口)
	_set.UpShowInfo();
	if (pStockCont) pStockCont->Invalidate();
}

void MainDlg::SetWindOpactiy(bool bSub)
{
	//降低窗口透明度 
	//提高窗口透明度
	int nValue = (int)m_PaintManager.GetOpacity(); 
	nValue += (bSub ? -10 : 10);
	UpOpacity(nValue);
}

void MainDlg::ShowOrHideInfoDlg()
{
	//显示隐藏涨停提示界面
	_set.UpShowInfoDlg();
	if ((!_set.IsShowInfoDlg()) && pInfoDlg)
		pInfoDlg->ShowWindow(false);

	if ((!_set.IsShowInfoDlg()) && pGruopDlg)
		pGruopDlg->ShowWindow(false);

	

}

LRESULT MainDlg::OnHotKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = TRUE;
	//UINT uID = _set.GetHotKeyID(wParam);
	UINT uID2 = wParam - (WM_USER + 5000);
	switch (uID2)
	{
	case 1: SetWinVisb(); break;
	case 2: SetMouseTran(); break;
	case 3: ReLoadCfg(true); break;
	case 4: ShowOrHideTotal();  break;
	case 5: SetWindOpactiy(true); break;
	case 6: SetWindOpactiy(false); break;
	case 7: Close(); break;
	case 8: ShowOrHideInfoDlg(); break;
	}
	return 0L;
}

void MainDlg::ReLoadCfg(bool bSet)
{
	UnRegHotKey();
	//重新加载配置
	_set.InitFromCfg();
	UpStockData();
	RegHotKey();

	if (bSet)
	{
		bool bIsShowInfoDlg = _set.IsShowInfoDlg();
		if (pInfoDlg &&
			bIsShowInfoDlg &&
			(_set.IsShowInfoDlg() == false))
			pInfoDlg->ShowWindow(false);
	}
}

void MainDlg::ChkAndUpData()
{
	// 9:30 11:30 
	//下午13:00 15:00 
	// 9:00 OpenTime1 
	// 11 : 31  CloseTime1
	// 12 : 59 OpenTime2
	// 15 : 01 CloseTime2
	cuTime = CTimeEx::GetCurrentTime();
	nDayOfW = CTimeEx::GetCurrentTime().GetDayOfWeek();
	//if (nDayOfW == 0 || nDayOfW == 7) KillTimer(m_hWnd, 1);
	if ((cuTime > OpenTime1 && cuTime < CloseTime1) || (cuTime > OpenTime2 && cuTime < CloseTime2))
	{
		UpStockData();
	}
}
LRESULT MainDlg::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	UINT nIDEvent = UINT(wParam);
	if (nIDEvent == 1) ChkAndUpData();
	return 0;
}

CControlUI* MainDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockC")) == 0) {
		return new CStockPriceUI;
	}
	return NULL;
}

void MainDlg::DoTask()
{
	int nTime = 0;
	while (true)
	{
		if (bExit) break;
		if ((++nTime) > 25)
		{
			ChkAndUpData();
			nTime = 0;
		}
		Sleep(100);
	}
}

DWORD WINAPI MainDlg::WorkThread(LPVOID lpPara)
{
	MainDlg * pWnd = (MainDlg *)lpPara;
	if (pWnd)   pWnd->DoTask();
	return 0;
}

bool MainDlg::MakeVerInfo()
{
	string strTime = __DATE__;
	strTime += " ";
	strTime += __TIME__;

	CTimeEx tTime = CTimeEx();
	tTime.GetBldTime(strTime);

	CDuiString strTmp;
	CXMLMarkup XmlPrase;
	XmlPrase.SetDoc(_T("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"));
	XmlPrase.AddElem(_T("Updater"));
	XmlPrase.IntoElem();
	XmlPrase.AddElem(_T("LastVersion"));
	strTmp.Format(L"%s (build%s)", _T(SOFT_VER), tTime.GetDate().c_str());
	XmlPrase.AddAttrib(_T("version"), strTmp.GetData());
	XmlPrase.AddAttrib(_T("VerNumber"), tTime.GetTime());
	XmlPrase.AddAttrib(_T("fileName"), _T(DOWN_NAME));
	XmlPrase.AddAttrib(_T("NOTE"), _T("增加了设置界面,可以不用自己修改XML配置文件"));

	strTmp.Format(L"%sver.xml", ::GetAppDir());

	return XmlPrase.Save(strTmp.GetData());
}


bool MainDlg::ChkNewVer(CDuiString &strNotify)
{
#define  VER_URL L"http://git.oschina.net/zuzong/stocktools/raw/master/ver.xml"
	string strTime = __DATE__;
	strTime += " ";
	strTime += __TIME__;
	CTimeEx tBldTime = CTimeEx();
	tBldTime.GetBldTime(strTime);
	wstring strUrl = VER_URL;
	string strData = GetNetData(strUrl);
	wstring strDoc = C2W(strData);
	CTimeEx tLastUpTime;

	CXMLMarkup xmlParser;
	xmlParser.SetDoc(strDoc);
	xmlParser.ResetMainPos();
	xmlParser.FindElem(L"Updater");
	xmlParser.IntoElem();
	while (xmlParser.FindElem(L"LastVersion"));
	{
		CDuiString strVer = xmlParser.GetAttrib(L"VerNumber").c_str();
		tLastUpTime = CTimeEx(_tstoi64(strVer));
		strNotify = xmlParser.GetAttrib(L"NOTE").c_str();
	}
	if (tLastUpTime > tBldTime) return true;
	return false;
}
bool MainDlg::DownAndRun()
{
	wstring _File1 = ::GetAppDir() + L"Notify.exe";
	wstring _File2 = ::GetAppDir() + L"Notify_u.exe";
	wstring _File3 = ::GetAppDir() + L"Notify_bak.exe";
	DWORD lstErr = ERROR_SUCCESS;

	do
	{
		if (::IsFileExists(_File3.c_str())) ::DeleteFile(_File3.c_str());

		if (!DownNewVer())
		{
			lstErr = ERROR_INVALID_HANDLE;
			break;
		}

		CloseHandle(NULL);
		if (!::MoveFile(_File1.c_str(), _File3.c_str()))
		{
			lstErr = GetLastError();
			break;
		}

		if (!::MoveFile(_File2.c_str(), _File1.c_str()))
		{
			lstErr = GetLastError();
			break;
		}

		ShellExecute(NULL, L"open", _File1.c_str(), NULL, NULL, SW_SHOW);

	} while (0);

	if (lstErr != ERROR_SUCCESS)
	{
		MessageBox(NULL, L"自动更新失败,请手动下载更新", L"更新", MB_OK);
		ShellExecute(NULL, L"open", L"http://git.oschina.net/zuzong/stocktools/raw/master/Notify.zip", NULL, NULL, SW_SHOW);

		wstring strExe = L"";
		if (IsFileExists(_File1.c_str()))  strExe = _File1;
		else if (IsFileExists(_File2.c_str())) strExe = _File2;
		else if (IsFileExists(_File3.c_str())) strExe = _File3;
		ShellExecute(NULL, L"open", strExe.c_str(), NULL, NULL, SW_SHOW);
	}

	return lstErr == ERROR_SUCCESS;
}

bool  MainDlg::DownNewVer()
{
	wstring _url = L"http://git.oschina.net/zuzong/stocktools/raw/master/Notify.zip";
	wstring _File = ::GetAppDir() + L"Notify.zip";
	wstring _File2 = ::GetAppDir() + L"Notify_u.exe";

	LPBYTE pData = NULL;
	DWORD dwSize = 0;
	bool bRet = false;

	if (::IsFileExists(_File.c_str())) ::DeleteFile(_File.c_str());
	if (::IsFileExists(_File2.c_str())) ::DeleteFile(_File2.c_str());

	do
	{
		if (!GetNetFile(_url, _File)) break;

		HZIP hz = OpenZip((void*)_File.c_str(), 0, 2);
		if (hz == NULL) break;
		ZIPENTRY ze;
		int i;
		if (FindZipItem(hz, L"Notify.exe", true, &i, &ze) != 0) break;
		dwSize = ze.unc_size;
		if (dwSize == 0) break;
		pData = new BYTE[dwSize];
		int res = UnzipItem(hz, i, pData, dwSize, 3);
		if (res == 0x00000000 || res == 0x00000600)
		{
			HANDLE hdFile = ::CreateFile(_File2.c_str(), GENERIC_ALL, FILE_SHARE_READ, NULL, CREATE_NEW, \
				FILE_ATTRIBUTE_NORMAL, NULL);

			if (hdFile != INVALID_HANDLE_VALUE)
			{
				::WriteFile(hdFile, (PVOID)pData, ze.unc_size, &dwSize, NULL);
				CloseHandle(hdFile);
				bRet = true;
			}
		}
		delete[] pData;
		pData = NULL;
		CloseZip(hz);
	} while (0);
	return bRet;
}

void MainDlg::DoSet()
{
	CSetDlg *pSetDlg = new CSetDlg;
	if (pSetDlg)
	{
		this->ShowWindow(false);
		if(pSetDlg->ShowWind()) ReLoadCfg();
		this->ShowWindow(true,false);
	}
}

void MainDlg::DoSShowZJDlg()
{
	CzjDlg dlg;
	dlg.ShowWind();
}

/*
CMenuWnd* pMenu = new CMenuWnd();
POINT pt;
GetCursorPos(&pt);
//ClientToScreen(m_hWnd, &pt);
pMenu->Init(NULL, _T("mainMenu.xml"), pt, &m_PaintManager, &m_MenuCheckInfo, eMenuAlignment_Right | eMenuAlignment_Bottom);
//左侧打开菜单
//pMenu->Init(NULL, _T("mainMenu.xml"), point, &m_PaintManager, &m_MenuCheckInfo, eMenuAlignment_Right );
//左上侧打开菜单
//pMenu->Init(NULL, _T("mainMenu.xml"), point, &m_PaintManager, &m_MenuCheckInfo, eMenuAlignment_Right | eMenuAlignment_Bottom);

*/