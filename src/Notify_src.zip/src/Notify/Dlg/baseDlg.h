#pragma once

using namespace DuiLib;
class BaseDlg : public WindowImplBase
{
public:
	BaseDlg();
	~BaseDlg();
	virtual	LPCTSTR  GetWindowClassName() const;
	UINT     GetClassStyle() const { return CS_IME | CS_VREDRAW | CS_HREDRAW; ; }//CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("Info.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	virtual LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	virtual LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
};

