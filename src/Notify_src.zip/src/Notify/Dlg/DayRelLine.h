#pragma once

#include "../Control/StockInfoUI.h"
#include "CalSelDlg.h"

class DayRelLineDlg : public WindowImplBase, public IDNotify
{
public:
	DayRelLineDlg();
	~DayRelLineDlg();
	LPCTSTR  GetWindowClassName() const { return _T("DayRelLineDlg"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_DIALOG; }//UI_CLASSSTYLE_FRAME CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("DayRelLineDlg.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);
	void OnClick(TNotifyUI& msg);

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	static DWORD WINAPI WorkThread(LPVOID lpPara);
	void DoTask();

	void UpDayRelLine();

	void ShowWin(SData &sData);

	virtual void UpDataDate(CDuiString &strData);

protected:
	void OnPrepare();
	string GetData();
	void GetDayRelDate(int nDay);
	void UpDataTitle();

private:
	//ִ�е��߳̾߱�
	HANDLE hThread;
	//ִ�е��߳�ID
	DWORD  threadId;

	StockLineUI *pStockCont;

	bool bExit = false;
	bool bNeedDowm = false;
	SData _sData;
	CalSelDlg * pClaDlg;
	CLabelUI *  pTitle;
};

