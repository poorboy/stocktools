#include "stdafx.h"
#include "MenuDlg.h"
#include "../DataDef/CfgSet.h" 
#include "MainDlg.h"

#define TASK_POS_LEFT		0
#define TASKBAR_POS_TOP		1
#define TASKBAR_POS_RIGHT	2
#define TASKBAR_POS_BOTTON	3
#define MSG_EDGE			5

MenuDlg::MenuDlg(MainDlg * pMainDlg)
{
	_pMainDlg = pMainDlg;

	pSliderUI = NULL;
	pOptTips = NULL;
	pOptShowTatol = NULL;
	pOptMoustTran = NULL;
	pOptShowMainDlg = NULL;
	pOptTrayIcon = NULL;
}

MenuDlg::~MenuDlg(void)
{

}

UILIB_RESOURCETYPE MenuDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR MenuDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}
void MenuDlg::OnPrepare()
{
	pSliderUI = static_cast<CSliderUI *>(m_PaintManager.FindControl(_T("sli")));

	pOptTips = static_cast<COptionUI *>(m_PaintManager.FindControl(_T("opt_Tips")));
	pOptShowMainDlg = static_cast<COptionUI *>(m_PaintManager.FindControl(_T("opt_ShowMainDlg")));
	pOptShowTatol = static_cast<COptionUI *>(m_PaintManager.FindControl(_T("opt_ShowTatol")));
	pOptMoustTran = static_cast<COptionUI *>(m_PaintManager.FindControl(_T("opt_MoustTran")));
	pOptTrayIcon = static_cast<COptionUI *>(m_PaintManager.FindControl(_T("opt_TrayIcon")));

	InitMenuItem();
}

void MenuDlg::Notify(TNotifyUI& msg)
{

	if (msg.sType == _T("windowinit")) OnPrepare();

	do
	{
		if (!_pMainDlg) break;

		//msg.sType == DUI_MSGTYPE_CLICK
		if ( msg.sType == DUI_MSGTYPE_ITEMCLICK)
		{
			CDuiString strName = msg.pSender->GetName(); 
			if (strName == L"bntExit") _pMainDlg->Close();
			if (strName == L"bntReLoad") _pMainDlg->ReLoadCfg(true);
			if (strName == L"bntSet") _pMainDlg->DoSet();
		}
		else if (msg.sType == DUI_MSGTYPE_VALUECHANGED)
		{
			if (pSliderUI) _pMainDlg->UpOpacity(pSliderUI->GetValue());
		}
		else if (msg.sType == DUI_MSGTYPE_SELECTCHANGED)
		{
			if (msg.pSender == pOptShowMainDlg)_pMainDlg->SetWinVisb();
			if (msg.pSender == pOptTips)_pMainDlg->ShowOrHideInfoDlg();
			if (msg.pSender == pOptShowTatol)_pMainDlg->ShowOrHideTotal();
			if (msg.pSender == pOptMoustTran)_pMainDlg->SetMouseTran();
			if (msg.pSender == pOptTrayIcon)_pMainDlg->UpDataTaryIcon();
		}
		else break;
		this->ShowWindow(false);
	} while (0);

}

LRESULT MenuDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT MenuDlg::HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (WM_KILLFOCUS == uMsg) this->ShowWindow(false);
	return 0L;
}
LRESULT MenuDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);
	if (uMsg == WM_KILLFOCUS) this->ShowWindow(false);
	return false;
}

LRESULT MenuDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	PostQuitMessage(0);
	return 0;
}

void MenuDlg::InitMenuItem()
{
	if (!_pMainDlg) return;

	if (pSliderUI) pSliderUI->SetValue(_pMainDlg->GetOpacityValue());

	if (pOptShowMainDlg)
		pOptShowMainDlg->Selected(::IsWindowVisible(_pMainDlg->GetHWND()), false);

	if (pOptTips)
		pOptTips->Selected(_set.IsShowInfoDlg(), false);

	if (pOptShowTatol)
		pOptShowTatol->Selected(_set.IsNeedShow(), false);

	if (pOptMoustTran)
		pOptMoustTran->Selected((::GetWindowLong(_pMainDlg->GetHWND(), GWL_EXSTYLE) && WS_EX_TRANSPARENT), false);

	if (pOptTrayIcon)
		pOptTrayIcon->Selected(_pMainDlg->IsAdd2Tary(), false);


	//<List name="menuLst" i
	CListUI * pList = static_cast<CListUI *>(m_PaintManager.FindControl(_T("menuLst")));
	if (pList) pList->SelectItem(-1,false,false); 

}
void MenuDlg::ShowMenu()
{
	InitMenuItem();
	AdustPost();
}

void MenuDlg::AdustPost()
{
	SIZE sz = m_PaintManager.GetInitSize();
	int x = 0;
	int y = 0;
	CalcPos(x, y);

	SetForegroundWindow(m_hWnd);
	::MoveWindow(m_hWnd, x, y, sz.cx, sz.cy, FALSE);
	::SetWindowPos(m_hWnd, HWND_TOPMOST, x, y, sz.cx, sz.cy, SWP_SHOWWINDOW);

	HWND hWndParent = m_hWnd;
	while (::GetParent(hWndParent) != NULL) hWndParent = ::GetParent(hWndParent);

	::ShowWindow(m_hWnd, SW_SHOW);
	::SendMessage(hWndParent, WM_NCACTIVATE, TRUE, 0L);

	//::SetForegroundWindow(*this); 
}

void MenuDlg::CreateWin()
{
	DWORD dwExstyle = WS_EX_TOPMOST | WS_EX_TOOLWINDOW;
	CreateDuiWindow(NULL,
		_T("MenuDlgDlgUI"),
		UI_WNDSTYLE_DIALOG/*UI_WNDSTYLE_FRAME*/,
		dwExstyle);
	::ShowWindow(*this, SW_HIDE);
}

void MenuDlg::CalcPos(int& x, int& y)
{
	RECT rcScreen;
	::GetWindowRect(GetDesktopWindow(), &rcScreen);
	ZeroMemory(&m_ad, sizeof APPBARDATA);
	m_ad.cbSize = sizeof APPBARDATA;
	SHAppBarMessage(ABM_GETTASKBARPOS, &m_ad);
	RECT rcTaskBar(m_ad.rc);
	//RECT rcTray;
	//HWND hWndTaskbar = ::FindWindow(_T("Shell_TrayWnd"), 0);
	//::GetWindowRect(hWndTaskbar, &rcTray);

	POINT pt = { 0 };
	GetCursorPos(&pt);
	x = pt.x + 2;
	y = pt.y + 2;

	SIZE sz = m_PaintManager.GetInitSize();

	//���ұ�
	if ((x + sz.cx) > rcScreen.right)
	{
		x -= 4;
		x -= sz.cx;
	}

	//���±�
	if ((y + sz.cy) > rcScreen.bottom)
	{
		y -= 4;
		y -= sz.cy;
	}

	////���ϱ�
	//if ((y + nWidth) > rcScreen.right)
	//{
	//	rcClient.right = X;
	//	x -= nWidth;
	//	rcClient.left = x - nWidth;
	//}

	////���±�
	//if ((x + nWidth) > rcScreen.right)
	//{
	//	rcClient.right = X;
	//	x -= nWidth;
	//	rcClient.left = x - nWidth;
	//}

	//// X =   Y= 
	////��
	//if (m_ad.uEdge == TASK_POS_LEFT)
	//{
	//	x = rcTaskBar.right;
	//	y = rcTaskBar.bottom - (rcClient.bottom - rcClient.top);
	//}
	////��
	//else if (m_ad.uEdge == TASKBAR_POS_TOP)
	//{
	//	x = rcTaskBar.right - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.bottom;
	//}
	////��
	//else if (m_ad.uEdge == TASKBAR_POS_RIGHT)
	//{
	//	x = rcTaskBar.left - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.bottom - (rcClient.bottom - rcClient.top);
	//}
	////��
	//else
	//{
	//	x = rcTaskBar.right - (rcClient.right - rcClient.left);
	//	y = rcTaskBar.top - (rcClient.bottom - rcClient.top);
	//}
}


/*



LRESULT CMenuWnd::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
m_pm.Init(m_hWnd);



CDialogBuilder builder;

CControlUI* pRoot = builder.Create(m_xml, UINT(0), this, &m_pm);
m_pm.AttachDialog(pRoot);
m_pm.AddNotifier(this);
MONITORINFO oMonitor = {};
oMonitor.cbSize = sizeof(oMonitor);
::GetMonitorInfo(::MonitorFromWindow(*this, MONITOR_DEFAULTTOPRIMARY), &oMonitor);
CDuiRect rcWork = oMonitor.rcWork;

SIZE szAvailable = { rcWork.right - rcWork.left, rcWork.bottom - rcWork.top };
szAvailable = pRoot->EstimateSize(szAvailable);
//if (szAvailable.cy > (rcWork.bottom - rcWork.top)) szAvailable.cy = (rcWork.bottom - rcWork.top);
m_pm.SetInitSize(szAvailable.cx, szAvailable.cy);

//������Menu��ǩ��Ϊxml�ĸ��ڵ�
CMenuUI *pMenuRoot = static_cast<CMenuUI*>(pRoot);
ASSERT(pMenuRoot);

SIZE szInit = m_pm.GetInitSize();
CDuiRect rc;
CDuiPoint point = m_BasedPoint;
rc.left = point.x;
rc.top = point.y;
rc.right = rc.left + szInit.cx;
rc.bottom = rc.top + szInit.cy;

int nWidth = rc.GetWidth();
int nHeight = rc.GetHeight();

if (m_dwAlignment & eMenuAlignment_Right)
{
	rc.right = point.x;
	rc.left = rc.right - nWidth;
}

if (m_dwAlignment & eMenuAlignment_Bottom)
{
	rc.bottom = point.y;
	rc.top = rc.bottom - nHeight;
}

SetForegroundWindow(m_hWnd);
MoveWindow(m_hWnd, rc.left, rc.top, rc.GetWidth(), rc.GetHeight(), FALSE);
SetWindowPos(m_hWnd, HWND_TOPMOST, rc.left, rc.top,
	rc.GetWidth(), rc.GetHeight() + pMenuRoot->GetInset().bottom + pMenuRoot->GetInset().top,
	SWP_SHOWWINDOW);
return 0;
	}

	LRESULT CMenuWnd::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
		LRESULT lRes = 0;
		BOOL bHandled = TRUE;
		switch (uMsg)
		{
		case WM_CREATE:
			lRes = OnCreate(uMsg, wParam, lParam, bHandled);
			break;
		case WM_KILLFOCUS:
			lRes = OnKillFocus(uMsg, wParam, lParam, bHandled);
			break;
		case WM_KEYDOWN:
			if (wParam == VK_ESCAPE || wParam == VK_LEFT)
				Close();
			break;
		case WM_SIZE:
			lRes = OnSize(uMsg, wParam, lParam, bHandled);
			break;
		case WM_CLOSE:
			if (m_pOwner != NULL)
			{
				m_pOwner->SetManager(m_pOwner->GetManager(), m_pOwner->GetParent(), false);
				m_pOwner->SetPos(m_pOwner->GetPos());
				m_pOwner->SetFocus();
			}
			break;
		case WM_RBUTTONDOWN:
		case WM_CONTEXTMENU:
		case WM_RBUTTONUP:
		case WM_RBUTTONDBLCLK:
			return 0L;
			break;
		default:
			bHandled = FALSE;
			break;
		}

		if (m_pm.MessageHandler(uMsg, wParam, lParam, lRes)) return lRes;
		return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
	}

*/