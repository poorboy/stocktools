#pragma once

#include "../Control/CStockIMGUI.h"

class ChartDlg : public WindowImplBase
{
public:
	ChartDlg();
	~ChartDlg();
	LPCTSTR  GetWindowClassName() const { return _T("StockChartDlgUI"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_FRAME; }//CS_IME | CS_VREDRAW | CS_HREDRAW;
	virtual CDuiString  GetSkinFile() { return _T("ChartDlg.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);
	void OnClick(TNotifyUI& msg);

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);


	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	static DWORD WINAPI WorkThread(LPVOID lpPara);
	void DoTask();

	void DownImg();
	void DownImg(CDuiString &strUrl, CDuiString &strFile);
	void ShowWin(CDuiString &SNo);


protected:
	void OnPrepare();
	void DownImages(int i);
	void DeleteFiles();
	void ChangBkImg(int nIndex);

private:
	//ִ�е��߳̾߱�
	HANDLE hThread;
	//ִ�е��߳�ID
	DWORD  threadId;

	StockIMG *pStockCont;

	bool bExit = false;
	bool bNeedDowm = false;
	CDuiString _strSockNo;

	CDuiString strFiles[4];
};

