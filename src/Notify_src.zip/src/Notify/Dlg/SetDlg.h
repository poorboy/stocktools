#pragma once

#include "StockDeatilDlg.h"
#include "../Control/StockListElmUI.h"
#include "../Control/HotKeyUI.h"

class CSetDlg : public WindowImplBase
{
public:
	CSetDlg();
	~CSetDlg();
	LPCTSTR  GetWindowClassName() const { return _T("CSetDlg"); }
	UINT     GetClassStyle() const { return UI_CLASSSTYLE_DIALOG; } 
	virtual CDuiString  GetSkinFile() { return _T("setwnd.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void Notify(TNotifyUI& msg);
	void OnClick(TNotifyUI& msg);
	void OnCloseMe();
	void InitBaseSet();
	void InitHotKeyInfo();
	void GetColorSet();
	void GetHotKeyInfo(CHotKeyUI * phkC, int nindex);
	void GetHotKeyInfoS();
	void Saves();
	void InitStock();
	void AddItem2List(int index);
	void RemoveItem2Vct(int nIndex);
	void InitHotKey();

	virtual void OnFinalMessage(HWND hWnd); 
	virtual CControlUI* CreateControl(LPCTSTR pstrClass);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
 
	int ShowWind();

protected:
	void OnPrepare(); 

	CListUI * lst_Stock;

	CButtonUI *  bnt_crMax;
	CButtonUI *  bnt_crMin;
	CButtonUI *  bnt_crMaxEx;
	CButtonUI *  bnt_crMinEx; 

	CButtonUI *  bnt_crMaxExBK;
	CButtonUI *  bnt_crMinExBK;
	CEditUI *	  et_Brokerage; 
	COptionUI *  opt_IsShowInfo;

	CTabLayoutUI* pTabControl;

	CLabelUI* lb_crMax;
	CLabelUI* lb_crMin;
	CLabelUI* lb_crMaxEx;
	CLabelUI* lb_crMinEx; 

	CHotKeyUI * hk_ID1;
	CHotKeyUI * hk_ID2;
	CHotKeyUI * hk_ID3;
	CHotKeyUI * hk_ID4;
	CHotKeyUI * hk_ID5;
	CHotKeyUI * hk_ID6;
	CHotKeyUI * hk_ID7;
	CHotKeyUI * hk_ID8;
};