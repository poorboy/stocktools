#include "stdafx.h"
#include "GroupDlg.h" 


GroupDlg::GroupDlg(void)
{
	pStockCont = NULL; 
}

GroupDlg::~GroupDlg(void)
{

}
 
 
UILIB_RESOURCETYPE GroupDlg::GetResourceType() const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR GroupDlg::GetResourceID() const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}

void GroupDlg::InitWindow()
{
	pStockCont = static_cast<CStockGPriceUI*>(m_PaintManager.FindControl(_T("stock")));
	this->CenterWindow();
	SetFocus(*this);
}



LRESULT GroupDlg::OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{

	if (uMsg != WM_SYSCOMMAND) return 0L;

	if (wParam == SC_CLOSE)
	{
		bHandled = TRUE;
		return 1;
	}

	if (
		(wParam == SC_MAXIMIZE)
		||
		(wParam == SC_MINIMIZE)
		||
		(wParam == SC_RESTORE)
		||
		(wParam == 61490)
		||
		(wParam == 61730)  //SC_MOVE
		)
	{
		return 0;
	}

	return WindowImplBase::OnSysCommand(uMsg, wParam, lParam, bHandled);
}

LRESULT GroupDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) this->ShowWindow(false);
	return false;
}

CControlUI* GroupDlg::CreateControl(LPCTSTR pstrClass)
{
	if (_tcsicmp(pstrClass, _T("StockC")) == 0) {
		return new CStockGPriceUI;
	}
	return NULL;
}

void GroupDlg::ShowWin(CDuiString &SNo)
{
	//_strSockNo = SNo; 
}
 