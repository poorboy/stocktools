/********************************************************************
�ļ���:		MainDlg.h
������:		poorboy
����ʱ��:	[7/2/2014 15:23]
�޸�ʱ��:
�ļ�˵��:	������
*********************************************************************/
#ifndef MainDlg_h__
#define MainDlg_h__
#pragma once
#include "baseDlg.h"
#include "../utils/CTimeEx.h"   
#include "../DataDef/CfgSet.h"
#include "ChartDlg.h"
#include "InfoDlg.h"
#include "DayRelLine.h"
#include "MenuDlg.h"
#include "GroupDlg.h"
#include "../Control/CStockPriceUI.h"

class MainDlg : public WindowImplBase
{
public:
	MainDlg(void);
	~MainDlg(void);
	LPCTSTR  GetWindowClassName() const { return _T("StockNofifyToolsUI"); }
	UINT     GetClassStyle() const { return CS_IME | CS_VREDRAW | CS_HREDRAW; }
	virtual CDuiString  GetSkinFile() { return _T("Main.xml"); }
	virtual CDuiString GetSkinFolder() { return L"Skin"; }
	UILIB_RESOURCETYPE GetResourceType() const;
	LPCTSTR GetResourceID() const;
	void    Notify(TNotifyUI& msg);

	void	OnClick(TNotifyUI& msg);
	virtual LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);
	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	virtual LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	virtual LRESULT OnHotKey(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	virtual LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void OnTrayMsg(WPARAM wParam, LPARAM lParam);


	virtual CControlUI* CreateControl(LPCTSTR pstrClass);

	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	static DWORD WINAPI WorkThread(LPVOID lpPara);
	void DoTask();
	void ReLoadCfg(bool bSet = false);
	void SetWinVisb();
	void ChkAndUpData();
	void UpOpacity(int nValue);
	int GetOpacityValue(); 

	void UpStockData();
	void SetMouseTran();
	void ShowOrHideInfoDlg();
	void SetWindOpactiy(bool bSub);
	void ShowOrHideTotal();
	void AdjustPost();
	void AddIcon2Tary();
	void ShowTips(LPCTSTR tisp, DWORD  flg = NIIF_INFO);

	bool MakeVerInfo();
	bool ChkNewVer(CDuiString &strNotify);
	bool DownNewVer();
	bool DownAndRun();

	bool IsAdd2Tary() { return bIsNeedAdd2Tary; };
	void UpDataTaryIcon(); 

	void DoSet();
	void DoSShowZJDlg();
protected:
	void OnPrepare();
	bool RegHotKey();
	void UnRegHotKey();
	void ShowMenu();
	void InitDlg();

private:
	NOTIFYICONDATA m_nid;

private:
	//ִ�е��߳̾߱�
	HANDLE hThread;
	//ִ�е��߳�ID
	DWORD  threadId;

	CStockPriceUI *pStockCont;
	CControlUI* pH1; 
	CControlUI* pbk_ver;
	CDuiString strLstTime;

	// 9:30  //9:30_11:30 ����13:00_15;00
	CTimeEx OpenTime1;
	CTimeEx CloseTime1;
	CTimeEx OpenTime2;
	CTimeEx CloseTime2;
	CTimeEx cuTime;
	int nDayOfW;
	bool bExit = false;

	bool bIsNeedAdd2Tary;

	ChartDlg * pChartDlg;
	DayRelLineDlg *  pDayRelDlg;
	MenuDlg * pMenu;

	GroupDlg *pGruopDlg;

	InfoDlg * pInfoDlg;
	int nLastHotIndex = 0;
};
#endif // MainDlg_h__