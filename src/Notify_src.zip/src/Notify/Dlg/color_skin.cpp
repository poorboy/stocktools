#include "stdafx.h"
#include <windows.h>
#if !defined(UNDER_CE)
#include <shellapi.h>
#endif

#include "color_skin.h" 

const TCHAR* const kAdjustColorSliderRControlName = _T("AdjustColorSliderR");
const TCHAR* const kAdjustColorSliderGControlName = _T("AdjustColorSliderG");
const TCHAR* const kAdjustColorSliderBControlName = _T("AdjustColorSliderB");

ColorSkinWindow::ColorSkinWindow(HWND _hwnd, CControlUI * _pBkCont)
{ 
	pBkCont = _pBkCont;
	Create(_hwnd, _T("colorskin"), UI_WNDSTYLE_DIALOG, WS_EX_TOPMOST | WS_EX_TOOLWINDOW, 0, 0);

	AdjustColorSliderR = NULL;
	AdjustColorSliderG = NULL;
	AdjustColorSliderB = NULL;
	pHColorLayout = NULL;
	lb_crTxt = NULL;
	lb_crBK = NULL;

	ShowModal();
}

UILIB_RESOURCETYPE ColorSkinWindow::GetResourceType()const
{
#ifdef XML_FROM_RES
	return UILIB_ZIPRESOURCE;
#else
	return UILIB_FILE;
#endif 
}

LPCTSTR ColorSkinWindow::GetResourceID()const
{
#ifdef XML_FROM_RES
	return MAKEINTRESOURCE(IDR_ZIPRES1);
#else
	return  L"";
#endif 
}
void ColorSkinWindow::OnFinalMessage(HWND hWnd)
{
	WindowImplBase::OnFinalMessage(hWnd);
	//delete this;
}

// CHorizontalLayoutUI *  pHColorLayout;
void ColorSkinWindow::OnPrepare()
{
	pHColorLayout = static_cast<CHorizontalLayoutUI*>(m_PaintManager.FindControl(L"HColorLayout"));

	 lb_crTxt = m_PaintManager.FindControl(L"lb_crTxt");
	 lb_crBK = m_PaintManager.FindControl(L"lb_crBK");

	AdjustColorSliderR = static_cast<CSliderUI*>(m_PaintManager.FindControl(kAdjustColorSliderRControlName));
	AdjustColorSliderG = static_cast<CSliderUI*>(m_PaintManager.FindControl(kAdjustColorSliderGControlName));
	AdjustColorSliderB = static_cast<CSliderUI*>(m_PaintManager.FindControl(kAdjustColorSliderBControlName));

	if(pBkCont) UpDataColor(pBkCont->GetBkColor(), true);

}
void ColorSkinWindow::UpDataColor(DWORD dwColor, bool bSet)
{
	if (!(AdjustColorSliderR && AdjustColorSliderG && AdjustColorSliderB)) return;

	do
	{
		if (!bSet) break;
		AdjustColorSliderR->SetValue(static_cast<BYTE>(GetRValue(dwColor)));
		AdjustColorSliderG->SetValue(static_cast<BYTE>(GetGValue(dwColor)));
		AdjustColorSliderB->SetValue(static_cast<BYTE>(GetBValue(dwColor)));
	} while (0);

	do
	{
		if (!lb_crTxt) break;
		CDuiString strTmp;
		DWORD cr = dwColor;
		if (dwColor  > 0xFF000000) cr = dwColor - 0xFF000000;
		strTmp.Format(L"��ǰ��ɫ:%02X,%02X,%02X  ", 
			GetRValue(cr), GetGValue(cr), GetBValue(cr));
		lb_crTxt->SetText(strTmp.GetData()); 
	} while (0);

	DWORD cr = dwColor;
	if (dwColor  < 0xFF000000) cr = 0xFF000000 + dwColor; 
	if (lb_crBK) lb_crBK->SetBkColor(cr);
	if (pBkCont) pBkCont->SetBkColor(cr);

}
void ColorSkinWindow::Notify(TNotifyUI& msg)
{
	if (msg.sType == _T("windowinit")) OnPrepare();
	if (_tcsicmp(msg.sType, _T("click")) == 0)
	{
		if (msg.pSender->GetName() == L"btnClose") Close(); 
		if (_tcsstr(msg.pSender->GetName(), _T("colour_")) != 0)
		{ 
			DWORD dwColor = msg.pSender->GetBkColor();
			UpDataColor(dwColor,true); 
		}
	}
	else if (_tcsicmp(msg.sType, _T("valuechanged")) == 0)
	{
		 if(
			 msg.pSender == AdjustColorSliderR ||
			 msg.pSender == AdjustColorSliderG ||
			 msg.pSender == AdjustColorSliderB
			 )
		{
			DWORD dwColor = RGB(
				AdjustColorSliderR->GetValue(),
				AdjustColorSliderG->GetValue(),
				AdjustColorSliderB->GetValue()
				);
			UpDataColor(dwColor);
		}
	}
}

void ColorSkinWindow::InitWindow()
{
	SIZE size = m_PaintManager.GetInitSize();
	::GetCursorPos(&m_pt);
	MoveWindow(GetHWND(), m_pt.x - static_cast<LONG>(size.cx / 2), m_pt.y + 10, size.cx, size.cy, FALSE);
	//HWND hWndParent = m_hWnd;
	//while (::GetParent(hWndParent) != NULL) hWndParent = ::GetParent(hWndParent);
	//::ShowWindow(m_hWnd, SW_SHOW);
	//::SendMessage(hWndParent, WM_NCACTIVATE, TRUE, 0L);

	/*
	
	bnt_crLast = static_cast<CButtonUI*>(msg.pSender);
		ColorSkinWindow *pColorDlg = new ColorSkinWindow(this);
		if (!pColorDlg) return;

		POINT pt = { 0 };
		CDuiRect rcBtn = msg.pSender->GetPos();
		CDuiRect rcWindow;
		GetWindowRect(m_hWnd, &rcWindow);
		pt.y = rcWindow.top + rcBtn.top;
		pt.x = rcWindow.left + rcBtn.left + static_cast<LONG>((rcBtn.right - rcBtn.left) / 2);
		pColorDlg->SetWindowsPost(pt);
		pColorDlg->UpDataColor(bnt_crLast->GetBkColor());
		pColorDlg->ShowWindow(true, true);
	*/
}
 

LRESULT ColorSkinWindow::OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	//Close();
	return 0;
}
