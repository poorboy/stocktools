#include "stdafx.h"
#include "../stdafx.h" 
#include "../../commApi/CommApi.h"
#include "HttpClientSyn.h"

#define MAXSTATICPARAMCOUNT 32

#define SAFE_CLOSE_INTERNET_HANDLE(X) if(X) WinHttpCloseHandle(X);
#define CHK_API_RET(X, Y) if(!X) {/*LOG_ERR(L"����API:%s ����,���������:%d",Y, GetLastError());*/ bResults = FALSE; goto END;}

#define API_ERROR(X)  break;//{m_strError.Format( L"%s����:%d", X, ::GetLastError()); 	LOG_ERR(m_strError); 	break;}


//#pragma comment( lib, "Wininet.lib" )
#pragma comment( lib, "Winhttp.lib" ) 

CHttpClientSyn::CHttpClientSyn()
{
	m_hSession = NULL;
	m_hConnect = NULL;
	m_hRequest = NULL;
	m_dwTimeout = 0;
	m_lpReceiveData = NULL;
	m_dwReceiveDataLength = 0;
	bIsNeeGetInfo = false;
	InitHeaderMap();

}


CHttpClientSyn::~CHttpClientSyn(void)
{
	ClearEvn();
}


void CHttpClientSyn::InitHeaderMap()
{
	UString szValue = L"";

	ADD_STR_2_POST_HEADER(L"Content-Type", L"application/x-www-form-urlencoded; charset=UTF-8");

	//szValue.Format(_T("%s_%s"), _T(AGENT), _T(Ver));
	//m_mapPostHeard.Set(L"User-Agent", szValue.GetData());
	ADD_STR_2_POST_HEADER(L"User-Agent", AGENT);
	ADD_STR_2_POST_HEADER(L"Cache-Contro", L"no-cache");
	ADD_STR_2_POST_HEADER(L"Connection", L"keep-alive");
	ADD_STR_2_POST_HEADER(L"Accept", L"*/*");

	//if (GResManager::Instance()->m_bIsLogin)
	//{
	//	ADD_STR_2_POST_HEADER(L"User-SSID", GResManager::Instance()->GetSSID());

	//	if (GResManager::Instance()->bIsDomanUser)
	//	{
	//		ADD_STR_2_POST_HEADER(L"Authorization", GResManager::Instance()->strNtlmAuth);
	//	}
	//}
	//else
	//{
	//	AddOsInfo();
	//}
}

void CHttpClientSyn::AddParam(LPCTSTR szName, DWORD nValue)
{
	StParam st;
	UString strTmp;
	strTmp.Format(L"%d", nValue);
	st.wstrKey = szName;
	st.wstrValue = strTmp;
	m_VecExtInfo.push_back(st);
}

void CHttpClientSyn::AddParam(LPCTSTR szName, int nValue)
{
	StParam st;
	UString strTmp;
	strTmp.Format(L"%d", nValue);
	st.wstrKey = szName;
	st.wstrValue = strTmp;
	m_VecExtInfo.push_back(st);
}

void CHttpClientSyn::AddParam(LPCTSTR szName, ULONGLONG nValue)
{
	StParam st;
	UString strTmp;
	strTmp.Format(L"%I64u", nValue);
	st.wstrKey = szName;
	st.wstrValue = strTmp;
	m_VecExtInfo.push_back(st);
}
void CHttpClientSyn::AddParam(LPCTSTR szName, LPCTSTR szValue, BOOL bBinary)
{
	StParam st;
	st.wstrKey = szName;
	st.wstrValue = szValue;
	m_VecExtInfo.push_back(st);
}

// ����Url���� UTF-8 
UString CHttpClientSyn::UrlEncode(LPCTSTR strUnicode)
{
	string unicode = W2UTF8((wchar_t *)strUnicode);
	int len = unicode.length();

	char *utf8 = (char *)alloca(len + 1);//new char[len + 1];
	memset(utf8, '\0', len + 1);
	memcpy_s(utf8, len, unicode.c_str(), len);

	char *utf8temp = utf8;
	utf8[len] = '\0';
	UString strEncodeData = L"";
	TCHAR szTmp[10] = { 0 };
	while (*utf8 != '\0')
	{
		memset(szTmp, 0, sizeof(szTmp));
		wsprintf(szTmp, _T("%%%02x"), (BYTE)*utf8);
		strEncodeData += szTmp;
		++utf8;
	}
	return strEncodeData;
}

UString CHttpClientSyn::UrlDeEncode(LPCTSTR strUnicode)
{

#define IsHexNum(c) ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'))

	int nLen = wcslen(strUnicode);
	if (nLen <= 0) return L"";
	nLen;
	string  str = W2A(strUnicode);
	char * retsz = (char *)alloca((nLen + 10));
	memset(retsz, 0, (nLen + 10));

	int i = 0;
	char * p = retsz;
	char szTmp[3];
	while (i < nLen)
	{
		if (i <= nLen - 3 && str[i] == '%' && IsHexNum(str[i + 1]) && IsHexNum(str[i + 2]))
		{
			szTmp[0] = str[i + 1];
			szTmp[1] = str[i + 2];
			szTmp[2] = '\0';
			sscanf(szTmp, "%x", p++);
			i += 3;
		}
		else
		{
			*(p++) = str.at(i++);
		}
	}
	UString strRet = C2W(retsz).c_str();
	return strRet;
}

void CHttpClientSyn::ClearParam()
{
	m_VecExtInfo.clear();
	return;
}

BOOL CHttpClientSyn::Request(LPCTSTR szURL, EType eType, DWORD dTimeOut)
{
	wstring wstrUrl = szURL;
	//CTimeEx tTimeStart = CTimeEx::GetCurrentTime();
	DWORD dwStart = GetTickCount();
	BOOL bSuc = FALSE;
	do {
		if (FALSE == InitializeHttp(wstrUrl, dTimeOut, eType)) break;

		if (FALSE == TransmiteData(eType)) break;
		ReceiveData();
		ParseHeaders();
		//UninitializeHttp();
		bSuc = TRUE;
	} while (0);

	DWORD dwEnd = GetTickCount();
	DWORD uTime = dwEnd - dwStart;
	//ULONGLONG tTime = CTimeEx::GetCurrentTime() - tTimeStart;
	//if (uTime > 100) LOG_DBG(L"���ýӿ�[%s]����[%d]����", m_wstrUrlPath.c_str(), uTime);

	return bSuc;
}


BOOL CHttpClientSyn::InitializeHttp(const wstring& wstrUrl, DWORD dwTimeout, EType eType)
{
	BOOL bSuc = FALSE;
	do {
		URL_COMPONENTS urlCom;
		memset(&urlCom, 0, sizeof(urlCom));
		urlCom.dwStructSize = sizeof(urlCom);
		WCHAR wchScheme[64] = { 0 };
		urlCom.lpszScheme = wchScheme;
		urlCom.dwSchemeLength = ARRAYSIZE(wchScheme);
		WCHAR wchHostName[1024] = { 0 };
		urlCom.lpszHostName = wchHostName;
		urlCom.dwHostNameLength = ARRAYSIZE(wchHostName);
		WCHAR wchUrlPath[1024] = { 0 };
		urlCom.lpszUrlPath = wchUrlPath;
		urlCom.dwUrlPathLength = ARRAYSIZE(wchUrlPath);
		WCHAR wchExtraInfo[1024] = { 0 };
		urlCom.lpszExtraInfo = wchExtraInfo;
		urlCom.dwExtraInfoLength = ARRAYSIZE(wchExtraInfo);

		if (FALSE == WinHttpCrackUrl(wstrUrl.c_str(), wstrUrl.length(), ICU_ESCAPE, &urlCom))
		{
			API_ERROR(L"WinHttpCrackUrl");
		}

		wstring wstrExtraInfo;
		if (eGet == eType)
		{
			wstrExtraInfo = urlCom.lpszExtraInfo;
			//ParseParams(wstrExtraInfo);
			//AddExtInfo(m_VecExtInfo);
		}

		m_hSession = WinHttpOpen(NULL, WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
		if (NULL == m_hSession)
		{
			API_ERROR(L"WinHttpOpen");
		}

		if (FALSE == WinHttpSetTimeouts(m_hSession, dwTimeout, dwTimeout, dwTimeout, dwTimeout))
		{
			API_ERROR(L"WinHttpSetTimeouts");
		}

		m_hConnect = WinHttpConnect(m_hSession, urlCom.lpszHostName, urlCom.nPort, 0);
		if (NULL == m_hConnect)
		{
			API_ERROR(L"WinHttpConnect");
		}

		m_wstrUrlPath = urlCom.lpszUrlPath;
		if (eGet != eType) {
			m_wstrUrlPath += urlCom.lpszExtraInfo;
		}

		bSuc = TRUE;
	} while (0);
	return bSuc;
}

VOID CHttpClientSyn::UninitializeHttp()
{
	if (NULL != m_hRequest) {
		WinHttpCloseHandle(m_hRequest);
		m_hRequest = NULL;
	}

	if (NULL != m_hConnect) {
		WinHttpCloseHandle(m_hConnect);
		m_hConnect = NULL;
	}

	if (NULL != m_hSession) {
		WinHttpCloseHandle(m_hSession);
		m_hSession = NULL;
	}
}

BOOL CHttpClientSyn::ReceiveData()
{
	BOOL bSuc = FALSE;
	DWORD dwReceivedBufferLength = 0;
	LPBYTE lpReceivedBuffer = NULL;
	m_dwReceiveDataLength = 0;
	m_readDate = "";

	do {
		if (FALSE == WinHttpReceiveResponse(m_hRequest, NULL))
		{
			API_ERROR(L"WinHttpReceiveResponse");
		}

		DWORD dwRetLength = 0;

		do {
			bSuc = FALSE;
			if (FALSE == WinHttpQueryDataAvailable(m_hRequest, &dwRetLength))
			{
				API_ERROR(L"WinHttpQueryDataAvailable");
			}

			if (0 == dwRetLength)
			{
				bSuc = TRUE;
				break;
			}

			LPBYTE lpReceivedData = new BYTE[dwRetLength + 1];

			if (NULL == lpReceivedData) break;

			memset(lpReceivedData, 0, sizeof(lpReceivedData));

			DWORD dwRead = 0;
			if (FALSE == WinHttpReadData(m_hRequest, lpReceivedData, dwRetLength, &dwRead))
			{
				API_ERROR(L"WinHttpReadData");
			}

			if (0 == dwRead) break;

			lpReceivedData[dwRead] = 0;
			m_dwReceiveDataLength += dwRead;
			m_readDate += reinterpret_cast<const char *>(lpReceivedData);
			delete[] lpReceivedData;
			lpReceivedData = NULL;

			bSuc = TRUE;
		} while (dwRetLength > 0);
	} while (0);

	return bSuc;
}

BOOL CHttpClientSyn::ReceiveData(LPBYTE lpBuffer, DWORD& dwBufferSize)
{
	BOOL bSuc = FALSE;
	do {
		if (NULL == m_lpReceiveData) {
			::SetLastError(ERROR_WINHTTP_NOT_INITIALIZED);
			break;
		}
		if (NULL == lpBuffer) {
			::SetLastError(ERROR_INVALID_ADDRESS);
			break;
		}

		if (m_dwReceiveDataLength > dwBufferSize) {
			dwBufferSize = m_dwReceiveDataLength;
			::SetLastError(ERROR_INSUFFICIENT_BUFFER);
			break;
		}

		errno_t e = memcpy_s(lpBuffer, dwBufferSize, m_lpReceiveData, m_dwReceiveDataLength);
		if (0 != e) {
			break;
		}

		ClearEvn();

		bSuc = TRUE;
	} while (0);
	return bSuc;
}

VOID CHttpClientSyn::ClearEvn()
{
	UninitializeHttp();
	m_dwTimeout = 0;
	if (NULL != m_lpReceiveData) {
		delete[] m_lpReceiveData;
		m_lpReceiveData = NULL;
	}
	m_dwReceiveDataLength = 0;
}

BOOL CHttpClientSyn::TransmiteData(const wstring& wstrUrl, EType eType, DWORD dwTimeout)
{
	BOOL bSuc = FALSE;
	do {
		if (FALSE == InitializeHttp(wstrUrl, dwTimeout, eType)) {
			break;
		}
		if (FALSE == TransmiteData(eType)) {
			break;
		}
		// if(eType  ==  eFileUpload) 
		bSuc = TRUE;
	} while (0);

	ReceiveData();
	ParseHeaders();
	UninitializeHttp();
	return bSuc;
}

BOOL CHttpClientSyn::TransmiteData(EType eType)
{
	BOOL bSuc = FALSE;
	switch (eType) {
	case eGet: {
		bSuc = TransmiteDataToServerByGet();
	}break;
	case ePost: {
		bSuc = TransmiteDataToServerByPost();
	}break;
	case eUpload: {
		bSuc = TransmiteDataToServerByUpload();
	}break;
	case eFileUpload: {
		bSuc = TransmiteFileDataToServer();
	}break;
	default: break;
	}
	return bSuc;
}

BOOL CHttpClientSyn::GetData(LPVOID lpBuffer, DWORD dwBufferSize, DWORD& dwWrite)
{
	return FALSE;
}

BOOL CHttpClientSyn::TransmiteDataToServerByGet()
{
	BOOL bSuc = FALSE;
	do {

		wstring wstrUrlPathAppend = m_wstrUrlPath;
		// ����Get��ʽʱ��Ҫ����������OpenRequest��
		if (false == wstrUrlPathAppend.empty()) {
			wstrUrlPathAppend += L"?";
		}

		wstrUrlPathAppend += GenerateExtInfo(m_VecExtInfo);

		m_hRequest = WinHttpOpenRequest(m_hConnect, L"GET",
			wstrUrlPathAppend.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (NULL == m_hRequest)
		{
			API_ERROR(L"WinHttpOpenRequest");
		}

		ModifyRequestHeader(m_hRequest);

		if (FALSE == WinHttpSendRequest(m_hRequest,
			WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0))
		{
			API_ERROR(L"WinHttpSendRequest");
		}

		bSuc = TRUE;
	} while (0);
	return bSuc;

}

BOOL CHttpClientSyn::TransmiteDataToServerByPost()
{
	BOOL bSuc = FALSE;
	do {
		m_hRequest = WinHttpOpenRequest(m_hConnect, L"POST",
			m_wstrUrlPath.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (NULL == m_hRequest) {
			API_ERROR(L"WinHttpOpenRequest");
		}

		ModifyRequestHeader(m_hRequest);

		wstring wstrExtInfo = GenerateExtInfo(m_VecExtInfo);
		string strExtInfo = W2UTF8(wstrExtInfo);

		DWORD dwTotal = strExtInfo.length();
		dwTotal += GetDataSize();

		if (FALSE == WinHttpSendRequest(m_hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, dwTotal, 0)) {
			API_ERROR(L"WinHttpSendRequest");
		}

		if (0 != strExtInfo.length()) {
			// Ĭ�Ͽ���һ��ȫ��д��
			if (FALSE == WinHttpWriteData(m_hRequest, strExtInfo.c_str(), strExtInfo.length(), NULL)) {
				API_ERROR(L"WinHttpWriteData");
			}
		}

		// ��̬����һ������
		BYTE buffer[1024] = { 0 };
		BOOL bContinue = FALSE;
		BOOL bSendOK = FALSE;

		do {
			DWORD dwBufferLength = sizeof(buffer);
			SecureZeroMemory(buffer, dwBufferLength);
			DWORD dwWriteSize = 0;
			bContinue = GetData(buffer, dwBufferLength, dwWriteSize);
			if (0 != dwWriteSize) {
				bSendOK = WinHttpWriteData(m_hRequest, buffer, dwWriteSize, NULL);
			}
			else {
				bSendOK = TRUE;
			}
		} while (bContinue && bSendOK);

		bSuc = bSendOK;

	} while (0);
	return bSuc;
}

BOOL CHttpClientSyn::TransmiteDataToServerByUpload()
{
	BOOL bSuc = FALSE;
	do {
		m_hRequest = WinHttpOpenRequest(m_hConnect, L"POST",
			m_wstrUrlPath.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (NULL == m_hRequest) {
			API_ERROR(L"WinHttpOpenRequest");
		}

		ModifyRequestHeader(m_hRequest);

		wstring wstrExtInfo = GenerateExtInfo(m_VecExtInfo);
		string strExtInfo = W2UTF8((wchar_t *)wstrExtInfo.c_str());

		DWORD dwTotal = strExtInfo.length();
		dwTotal += GetDataSize();

		if (FALSE == WinHttpSendRequest(m_hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, dwTotal, 0)) {

			API_ERROR(L"WinHttpSendRequest");
		}

		// ��̬����һ������
		BYTE buffer[1024] = { 0 };
		BOOL bContinue = FALSE;
		BOOL bSendOK = FALSE;

		do {
			DWORD dwBufferLength = sizeof(buffer);
			SecureZeroMemory(buffer, dwBufferLength);
			DWORD dwWriteSize = 0;
			bContinue = GetData(buffer, dwBufferLength, dwWriteSize);
			if (0 != dwWriteSize) {
				bSendOK = WinHttpWriteData(m_hRequest, buffer, dwWriteSize, NULL);
			}
			else {
				bSendOK = TRUE;
			}
		} while (bContinue && bSendOK);

		if (0 != strExtInfo.length()) {
			if (FALSE == WinHttpWriteData(m_hRequest, strExtInfo.c_str(), strExtInfo.length(), NULL)) {
				API_ERROR(L"WinHttpWriteData");
			}
		}
		bSuc = bSendOK;
	} while (0);
	return bSuc;
}



BOOL CHttpClientSyn::GetDataEx(LPVOID lpBuffer, DWORD dwBufferSize, DWORD& dwWrite, DWORD& dwFileSize)
{
	OVERLAPPED ov;
	memset(&ov, 0, sizeof(ov));
	ov.Offset = m_ReadInfo.dwReadIndex;

	HANDLE hFile = CreateFile(m_wstrFilePath.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	BOOL bContinue = FALSE;
	dwFileSize = 0;

	do {
		if (INVALID_HANDLE_VALUE == hFile) {
			dwWrite = 0;
			break;
		}

		LARGE_INTEGER lgFileSize = { 0 };
		if (FALSE == GetFileSizeEx(hFile, &lgFileSize)) {
			break;
		}

		dwFileSize = lgFileSize.LowPart;
		if (lpBuffer == NULL) break;

		if (FALSE == ReadFile(hFile, lpBuffer, dwBufferSize, &dwWrite, &ov)) break;

		bContinue = TRUE;
	} while (0);

	if (INVALID_HANDLE_VALUE != hFile) {
		CloseHandle(hFile);
		hFile = NULL;
	}
	m_ReadInfo.dwReadIndex += dwWrite;
	if (m_ReadInfo.dwReadIndex == dwFileSize) {
		m_ReadInfo.dwReadIndex = 0;
		bContinue = FALSE;
	}

	return TRUE;
}

BOOL CHttpClientSyn::TransmiteFileDataToServer()
{
	BOOL bSuc = FALSE;
	do {
		m_hRequest = WinHttpOpenRequest(m_hConnect, L"POST",
			m_wstrUrlPath.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (NULL == m_hRequest) {
			API_ERROR(L"WinHttpOpenRequest");
		}

		ModifyRequestHeader(m_hRequest);

		// ��̬����һ������
		BYTE buffer[1024] = { 0 };
		BOOL bContinue = FALSE;
		BOOL bSendOK = FALSE;

		DWORD dwTotal = 0;
		DWORD dwWriteSize = 0;

		GetDataEx(NULL, 0, dwWriteSize, dwTotal);

		if (FALSE == WinHttpSendRequest(m_hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, dwTotal, 0)) {

			API_ERROR(L"WinHttpSendRequest");
		}


		do {
			DWORD dwBufferLength = sizeof(buffer);
			SecureZeroMemory(buffer, dwBufferLength);

			bSendOK = TRUE;
			bContinue = GetDataEx(buffer, dwBufferLength, dwWriteSize, dwTotal);
			if (0 != dwWriteSize) bSendOK = WinHttpWriteData(m_hRequest, buffer, dwWriteSize, NULL);

		} while (bContinue && bSendOK);

		bSuc = bSendOK;
	} while (0);
	return bSuc;
}

void CHttpClientSyn::AddHeader(map<CDuiString, CDuiString> &map, LPCTSTR key, LPCTSTR Data)
{
	map[key] = Data;
}

bool CHttpClientSyn::ParseHeaders()
{
	m_mapHeard.clear();

	DWORD dwSize = 0;
	LPVOID lpOutBuffer = NULL;
	BOOL bResults = WinHttpQueryHeaders(
		m_hRequest,
		WINHTTP_QUERY_RAW_HEADERS_CRLF,
		WINHTTP_HEADER_NAME_BY_INDEX, NULL,
		&dwSize, WINHTTP_NO_HEADER_INDEX);


	if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
	{
		lpOutBuffer = new WCHAR[dwSize / sizeof(WCHAR)];

		// Now, use WinHttpQueryHeaders to retrieve the header.
		bResults = WinHttpQueryHeaders(m_hRequest,
			WINHTTP_QUERY_RAW_HEADERS_CRLF,
			WINHTTP_HEADER_NAME_BY_INDEX,
			lpOutBuffer, &dwSize,
			WINHTTP_NO_HEADER_INDEX);
	}

	wstring strHead = L"";
	if (lpOutBuffer)
	{
		strHead = (WCHAR *)lpOutBuffer;
		delete[] lpOutBuffer;
	}

	try
	{

		strHead.append(L"\r\n");
		int pre_index = 0, index = 0, len = 0;
		wstring tok = L"\r\n";
		while ((index = strHead.find_first_of(tok, pre_index)) != wstring::npos)
		{
			len = index - pre_index;
			wstring temp = strHead.substr(pre_index, len);

			wstring::size_type  locFind = temp.find(L"HTTP");
			if (locFind != wstring::npos)
			{
				m_HttpStatus = temp.c_str();
				wstring::size_type loc3 = temp.find(L" ", 0);

				if (loc3 != wstring::npos)
				{
					wstring sztmpStatusValue = temp.substr(loc3 + 1);
					m_nHttpStatus = _tstoi(sztmpStatusValue.c_str());
				}
			}

			wstring::size_type loc = temp.find(L":", 0);
			if (loc != wstring::npos)
			{
				wstring szNeme = temp.substr(0, loc);
				wstring szValue = temp.substr(loc + 1);
				UString strName = szNeme.c_str();
				UString strValue = szValue.c_str();
				if (szValue.find(L"%") != wstring::npos)
				{
					strValue = UrlDeEncode(szValue.c_str());
				}

				ADD_STR_2_HEADER_MAP(strName.GetData(), strValue.GetData());

				if (temp.find(L"Set-Cookie", 0) != string::npos)
				{
					PraseCookie(szValue);
				}
			}
			pre_index = index + 2;
		}
	}
	catch (...)
	{
		throw NULL;
	}
	return true;
}


UString CHttpClientSyn::GetCookie(const UString& szName)
{
	UString strRetValue = L"";
	std::map<UString, UString>::iterator iterFind = m_mapCookie.find(szName);
	if (iterFind != m_mapCookie.end())
	{
		strRetValue = iterFind->second;
	}

	return strRetValue;
}

UString CHttpClientSyn::GetCookie()
{
	UString strRetValue;
	std::map<UString, UString>::iterator iterFind = m_mapCookie.begin();
	for (; iterFind != m_mapCookie.end(); ++iterFind)
	{
		strRetValue += iterFind->first;
		strRetValue.Append(_T("="));
		strRetValue.Append(iterFind->second);
		if (iterFind != m_mapCookie.end())
			strRetValue.Append(_T("; "));
	}
	return strRetValue;
}

void CHttpClientSyn::SetCookie(const UString& header, const UString& h_data)
{
	m_mapCookie[header] = h_data;
}

bool CHttpClientSyn::PraseCookie(std::wstring &strCookie)
{
	if (strCookie.size() <= 0) return false;
	try
	{
		wstring tonkCooks = L"; ";
		int cooks_pre_index = 1, cooks_index = 0, cooks_len = 0;
		wstring tokcooks = L"; ";
		strCookie.append(tokcooks);
		while ((cooks_index = strCookie.find_first_of(tokcooks, cooks_pre_index)) != wstring::npos)
		{
			cooks_len = cooks_index - cooks_pre_index;
			wstring cooks_temp = strCookie.substr(cooks_pre_index, cooks_len);
			wstring::size_type loc1 = cooks_temp.find(L"=", 0);
			if (loc1 != wstring::npos)
			{
				wstring szNemecooks = cooks_temp.substr(0, loc1);
				wstring szNemecooksValue = cooks_temp.substr((loc1 + 1));
				UString szNeme1 = szNemecooks.c_str();
				UString szValue1 = szNemecooksValue.c_str();
				SetCookie(szNeme1, szValue1);
			}
			cooks_pre_index = cooks_index + 2;
		}
	}
	catch (...)
	{
		throw NULL;
	}
	return true;
}

UString CHttpClientSyn::GetHeader(LPCTSTR Key)
{
	map<CDuiString, CDuiString> ::iterator itr = m_mapHeard.begin();
	UString  strRetValue;

	for (; itr != m_mapHeard.end(); ++itr)
	{
		if (itr->first.CompareNoCase(Key) == 0)
		{
			strRetValue = itr->second;
			break;
		}
	}
	map<CDuiString, CDuiString> ::iterator itrFind = m_mapHeard.find(Key);


	//if (itrFind != m_mapHeard.end())
	//{
	//	strRetValue = itrFind->second;

	//	int nPost = strRetValue.Find(L": ");
	//	if (nPost > 0)
	//	{
	//		strRetValue = strRetValue.Mid(nPost + 2);
	//		strRetValue.Trim();
	//	}
	//}
	return strRetValue;
}
// [8/13/2013 13:49:25 poorboy]
//���ӵ�һ�ε���ʱ���û���Ϣ
void CHttpClientSyn::AddOsInfo(void)
{
	////��¼header������������Ϣ

	//�ͻ��˱�ʶ��WEB,LinkAppBox,LinkAppBoard,LinkAppScan,LinkAppNote,WEBDAV,CIFS,NFS)   
	//AddParam("ac"," ");

	//�ͻ��˰汾��
	//AddParam("acVersion"," ");

	//ϵͳ����
	//AddParam("osArch"," ");

	//ϵͳ�汾
	//AddParam("osVersion"," ");

	//ϵͳ����
	//AddParam("osLanguage"," ");


	//char szIpAddress[500] = { 0 };
	//char szMacAddress[500] = { 0 };
	//GetInfo(szMacAddress, szIpAddress);

	////User-Ip :   "192.168.4.100|192.168.4.101"
	//GResManager::Instance()->strLocatIPS = C2W(szIpAddress).c_str();
	//ADD_STR_2_POST_HEADER(L"User-Ip", GResManager::Instance()->strLocatIPS.GetData());

	////User-Mac :  "MAC1|MAC2"
	//ADD_STR_2_POST_HEADER(L"User-Mac", C2W(szMacAddress).c_str());

	TCHAR szComputName[MAX_COMPUTERNAME_LENGTH] = { 0 };
	DWORD dwLen = 0;
	::GetComputerName(NULL, &dwLen);
	if (!::GetComputerName(szComputName, &dwLen))
	{
		//LOG_ERR(L"��ȡ�������ʧ�� ���������:%d", ::GetLastError());
		return;
	}

	ADD_STR_2_POST_HEADER(L"osName", szComputName);
}


bool CHttpClientSyn::PostData2Service()
{
	ClearParam();
	AddParam(L"wt", L"xml");
	AddParam(L"encrypt", L"BASE");
	//L"/UpFileData", _T("POST"), L"AAAAAAAAAAAAAAAAAAAAAA", 0);

	UString url = m_strBaseUrl;
	url.Append(L"UpFileData");

	return Request(url.GetData(), ePost, 3000);
}



std::wstring CHttpClientSyn::GenerateExtInfo(const VecStParam& VecExtInfo)
{
	std::wstring wstrExtInf;
	for (VecStParamCIter it = VecExtInfo.begin(); it != VecExtInfo.end(); it++) {
		if (false == wstrExtInf.empty()) {
			wstrExtInf += L"&";
		}
		wstrExtInf += it->wstrKey;
		wstrExtInf += L"=";
		wstrExtInf += it->wstrValue;
	}
	return wstrExtInf;
}

BOOL CHttpClientSyn::ModifyRequestHeader(HINTERNET hRequest)
{
	UString strHeads = L"";
	strHeads = GetCookie();

	if (strHeads.GetLength() > 1)
	{
		UString strCookie = _T("Cookie: ");
		strCookie.Append(strHeads);
		if (!WinHttpAddRequestHeaders(hRequest,
			strCookie.GetData(),
			(ULONG)-1L,
			WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE))
		{
			/*		LOG_ERR(L"WinHttpAddRequestHeaders:[%s] Error [%d]"
						, strCookie.GetData()
						, ::GetLastError()
					);*/
		}
	}


	map<CDuiString, CDuiString> ::iterator itr = m_mapPostHeard.begin();

	UString strValue;

	for (; itr != m_mapPostHeard.end(); ++itr)
	{
		strValue.Format(L"%s:%s", itr->first.GetData(), itr->second.GetData());
		if (!WinHttpAddRequestHeaders(hRequest,
			strValue.GetData(),
			(ULONG)-1L/*(pHead->GetLength())*/,
			WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE))
		{
			//LOG_ERR(L"WinHttpAddRequestHeaders:[%s] Error [%d]"
			//	, strValue.GetData()
			//	, ::GetLastError()
			//);
		}
	}
	return TRUE;
}

DWORD CHttpClientSyn::GetDataSize()
{
	return m_readDate.length();
}

/*


/*
UString strUrl1 = L"http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx/JS.aspx";
http1.AddParam(L"type", L"ct");
http1.AddParam(L"st", L"(BalFlowMain)");
http1.AddParam(L"sr", L"-1");
http1.AddParam(L"p", L"1");
http1.AddParam(L"ps", L"5000");
//http1.AddParam(L"js", L"var%20arr", L"{pages:(pc),date:%222014-10-22%22,data:[(x)]}");
http1.AddParam(L"token", L"894050c76af8597a853f5b408b759f5d");
http1.AddParam(L"cmd", L"C._AB");
http1.AddParam(L"sty", L"DCFFITA");
http1.AddParam(L"rt", L"50165138");

���� A
?type=ct
st=(FFARank)
sr=1
p=2
ps=50
js=var%20rUxKWCKW={pages:(pc),data:[(x)]}
token=894050c76af8597a853f5b408b759f5d
cmd=C._A
sty=DCFFITAMA
rt=50165072



���� ����
?type=ct
st=(BalFlowMain)
sr=-1
p=2
ps=50
js=var%20vIeNRJLu={pages:(pc),date:%222014-10-22%22,data:[(x)]}
token=894050c76af8597a853f5b408b759f5d
cmd=C._AB
sty=DCFFITA
rt=50165073

���� ����
?type=ct
st=(BalFlowMainNet3)
sr=-1
p=1
ps=50
js=var%20dhzyMevI={pages:(pc),date:%222014-10-22%22,data:[(x)]}
token=894050c76af8597a853f5b408b759f5d
cmd=C._AB
sty=DCFFITA3
rt=50165074

5�� ����
?type=ct
st=(BalFlowMainNet5)
sr=-1
p=1
ps=50
js=var%20lJMkxojr={pages:(pc),date:%222014-10-22%22,data:[(x)]}
token=894050c76af8597a853f5b408b759f5d
cmd=C._AB
sty=DCFFITA5
rt=50165075



10�� ����
?type=ct
st=(BalFlowMainNet10)
sr=-1
p=1
ps=50
js=var%20nSUJvUZA={pages:(pc),date:%222014-10-22%22,data:[(x)]}
token=894050c76af8597a853f5b408b759f5d
cmd=C._AB
sty=DCFFITA10
rt=50165076


�ɽ�����
http://mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get?dtype=all
token=44c9d251add88e27b65ed86506f6e5da
rows=1
cb=a
page=1
id=0024972
gtvolume=
sort=
_=1504952386420

�󵥽���
http://ff.eastmoney.com//EM_CapitalFlowInterface/api/js?type=hff
rtntype=2
js=({data:[(x)]})
cb=var%20aff_data=
check=TMLBMSPROCR
acces_token=1942f5da9b46b069953c873404aad4b5
id=0024972
_=1504952710976
*/


bool CHttpClientSyn::GetZJ(int type, ZJinfo &zjInfo, SK_TYPE skTYpe)
{
	ClearParam();
	AddParam(L"type", L"ct");

	/*
	���� A
	st=(FFARank)
	sr=1
	cmd=C._A
	sty=DCFFITAMA
	*/

	if (type == 1)
	{
		/*
		���� ����
		st=(BalFlowMain)
		sty=DCFFITA
		*/
		AddParam(L"st", L"(BalFlowMain)");
		AddParam(L"sty", L"DCFFITA");

	}
	else if (type == 3)
	{
		/*
		���� ����
		st=(BalFlowMainNet3)
		sty=DCFFITA3
		*/
		AddParam(L"st", L"(BalFlowMainNet3)");
		AddParam(L"sty", L"DCFFITA3");
	}
	else if (type == 5)
	{	/*
		5�� ����
		st=(BalFlowMainNet5)
		sty=DCFFITA5
		*/
		AddParam(L"st", L"(BalFlowMainNet5)");
		AddParam(L"sty", L"DCFFITA5");
	}
	else if (type == 10)
	{
		/*
		10�� ����
		st=(BalFlowMainNet10)
		sty=DCFFITA10
		*/
		AddParam(L"st", L"(BalFlowMainNet10)");
		AddParam(L"sty", L"DCFFITA10");
	}


	/*
	st=(BalFlowMain)
	cmd=C._A
	sty=DCFFITA

	st=(BalFlowMainNet3)
	cmd=C._A
	sty=DCFFITA3
	st=(BalFlowMainNet5)
	cmd=C._A
	sty=DCFFITA5

	st=(BalFlowMainNet10)
	cmd=C._A
	sty=DCFFITA10
	*/

	AddParam(L"sr", L"-1");
	AddParam(L"p", L"1");
	AddParam(L"ps", L"5000");
	AddParam(L"token", L"894050c76af8597a853f5b408b759f5d");
	//AddParam(L"rt", L"50165138");

//C.2
//C._SZAME
//C.80
//C.13

	switch (skTYpe)
	{
	case SK_ALL:
		AddParam(L"cmd", L"C._AB");
		break;
	case SK_ALL_A:
		AddParam(L"cmd", L"C._A");
		break;
	case SK_H_A:
		AddParam(L"cmd", L"C.2");
		break;
	case SK_S_A:
		AddParam(L"cmd", L"C._SZAME");
		break;
	case SK_CYB:
		AddParam(L"cmd", L"C.80");
		break;
	case SK_ZXB:
		AddParam(L"cmd", L"C.13"); 
		break; 
	}
	//AddParam(L"js", L"var%20arr", L"{pages:(pc),date:%222014-10-22%22,data:[(x)]}"); 894050c76af8597a853f5b408b759f5d


	if (Request(L"http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx/JS.aspx"))
	{
		return GetzjItem(zjInfo) > 0;
	}
	return false;

	/*

	���� A
	?type=ct
	st=(FFARank)
	sr=1
	p=2
	ps=50
	js=var%20rUxKWCKW={pages:(pc),data:[(x)]}
	token=894050c76af8597a853f5b408b759f5d
	cmd=C._A
	sty=DCFFITAMA
	rt=50165072

	�ɽ�����
	http://mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get?dtype=all
	token=44c9d251add88e27b65ed86506f6e5da
	rows=1
	cb=a
	page=1
	id=0024972
	gtvolume=
	sort=
	_=1504952386420

	�󵥽���
	http://ff.eastmoney.com//EM_CapitalFlowInterface/api/js?type=hff
	rtntype=2
	js=({data:[(x)]})
	cb=var%20aff_data=
	check=TMLBMSPROCR
	acces_token=1942f5da9b46b069953c873404aad4b5
	id=0024972
	_=1504952710976
	*/
}


//http://ff.eastmoney.com/EM_CapitalFlowInterface/api/js?type=hff&rtntype=2&acces_token=1942f5da9b46b069953c873404aad4b5&id=6016181
//��ȡ����Ʊ
bool CHttpClientSyn::GetSkZJ(LPCTSTR skNo, ZJinfo &zjInfo)
{
	ClearParam();
	AddParam(L"type", L"hff"); 
	AddParam(L"rtntype", L"2");
	AddParam(L"token", L"1942f5da9b46b069953c873404aad4b5");
	AddParam(L"id", skNo); 

	if (Request(L"http://ff.eastmoney.com/EM_CapitalFlowInterface/api/js"))
	{
		return GetzjItem(zjInfo) > 0;
	}
	return false;
}


/*
http://mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get?
dtype=all&token=44c9d251add88e27b65ed86506f6e5da&rows=1000&page=1&id=0024972


http://mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get?dtype=all&token=44c9d251add88e27b65ed86506f6e5da&rows=1000&page=1&id=6000481
*/


//��ȡ�����ʱ����
bool CHttpClientSyn::GetSkFS(LPCTSTR skNo, ZJinfo &zjInfo)
{
	ClearParam();
	AddParam(L"dtype", L"all");
	AddParam(L"rows", L"5000");
	AddParam(L"page", L"1");
	AddParam(L"token", L"44c9d251add88e27b65ed86506f6e5da");
	AddParam(L"id", skNo);

	if (Request(L"http://mdfm.eastmoney.com/EM_UBG_MinuteApi/Js/Get"))
	{
		return GetzjItem(zjInfo) > 0;
	}
	return false;
}

int CHttpClientSyn::GetzjItem(ZJinfo &info)
{
	bool isItemFins = false; //"," 
	bool hasQt1 = false;

	wstring strTmp = L"";
	wchar_t ch;
	Infoitem item;
	info.clear();

	wstring strw = C2W(m_readDate.c_str());

	for (int i = 1; i < strw.length(); i++)
	{
		ch = strw[i];
		if (ch == L'[') continue;
		else if (ch == L'\"')
		{
			if (hasQt1 && isItemFins)
			{
				info.push_back(item);
				item.clear();
			}
			else hasQt1 = true;
			continue;
		}
		else if (ch == L',')
		{
			isItemFins = true;
			if (strTmp.length() > 0) {
				item.push_back(strTmp);
				strTmp = L"";
			}
			continue;
		}

		hasQt1 = false;
		isItemFins = false;
		strTmp += ch;
	}
	return info.size();
}