#ifndef _HTTPCLIENTSYN_HEAD_
#define _HTTPCLIENTSYN_HEAD_
#pragma once

#include "../stdafx.h"
#include <xstring> 
#include <Winhttp.h>  

using namespace std;

#define  Ver   __DATE__ 
#define  AGENT  L"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36"//"LB_UPDATE_Client"


#define ADD_STR_2_POST_HEADER(KEY, DATA)	AddHeader(m_mapPostHeard, KEY, DATA)
#define ADD_STR_2_HEADER_MAP(KEY, DATA)		AddHeader(m_mapHeard, KEY, DATA)
 

enum SK_TYPE
{
	SK_ALL,
	SK_ALL_A,
	SK_H_A,
	SK_S_A,
	SK_CYB,
	SK_ZXB,

};
typedef struct _StParam_ {
	std::wstring wstrKey;
	std::wstring wstrValue;
}StParam, *PStParam;

typedef std::vector<StParam> VecStParam;
typedef VecStParam::iterator VecStParamIter;
typedef VecStParam::const_iterator VecStParamCIter;


typedef vector <wstring> Infoitem;
typedef vector<Infoitem> ZJinfo;

enum EType {
	eGet,
	ePost,
	eUpload,
	eFileUpload,
};

enum EREADPART {
	EHeader,
	EFile,
	FileUpload,
};

typedef struct StReadInfo_tag {
	DWORD dwReadIndex;
	EREADPART eType;
}StReadInfo;

class  CHttpClientSyn
{
public:
	CHttpClientSyn();
	~CHttpClientSyn(void);

public:
	BOOL TransmiteData(const std::wstring& wstrUrl, EType eType, DWORD dwTimeout);

	VOID ClearEvn();

	BOOL ReceiveData(LPBYTE lpBuffer, DWORD& dwBufferSize);

	void AddParam(LPCTSTR szName, DWORD nValue);
	void AddParam(LPCTSTR szName, int nValue);
	void AddParam(LPCTSTR szName, ULONGLONG nValue);
	void AddParam(LPCTSTR szName, LPCTSTR szValue, BOOL bBinary = FALSE);
	void ClearParam();

	UString UrlEncode(LPCTSTR strUnicode);
	UString UrlDeEncode(LPCTSTR strUnicode);

	//��ȡ�ʽ�������Ϣ
	bool GetZJ(int type, ZJinfo &zjInfo, SK_TYPE skTYpe = SK_ALL_A);
	
	
	//��ȡ����Ʊ
	bool GetSkZJ(LPCTSTR skNo, ZJinfo &zjInfo);

	//��ȡ�����ʱ����
	bool GetSkFS(LPCTSTR skNo, ZJinfo &zjInfo);
public:
	BOOL Request(LPCTSTR szURL, EType eType = EType::eGet, DWORD dTimeOut = 30000);


protected:
	BOOL InitializeHttp(const std::wstring& wstrUrl, DWORD dwTimeout, EType eType);
	VOID UninitializeHttp();

	BOOL ReceiveData();

	BOOL TransmiteData(EType eType);


	BOOL TransmiteDataToServerByGet();
	BOOL TransmiteDataToServerByPost();
	BOOL TransmiteDataToServerByUpload();
	BOOL TransmiteFileDataToServer();



	BOOL GetDataEx(LPVOID lpBuffer, DWORD dwBufferSize, DWORD& dwWrite, DWORD& dwDataSize);

	int GetzjItem(ZJinfo &zjInfo);

	//////////////////////////////////////////////////////////////////////////
public:
	UString GetHeader(LPCTSTR Key);

	bool PostData2Service();

	void AddOsInfo(void);
	//////////////////////////////////////////////////////////////////////////

	DWORD GetDataSize();

	BOOL ModifyRequestHeader(HINTERNET hRequest);
	std::wstring GenerateExtInfo(const VecStParam& VecExtInfo);

	void AddHeader(map<CDuiString, CDuiString>&mapHaads, LPCTSTR key, LPCTSTR Data);
	bool ParseHeaders();
	bool PraseCookie(std::wstring &strCookie);
	void SetCookie(const UString& header, const UString& h_data);
	UString GetCookie(const UString& szName);
	UString GetCookie();

	//bool GetOtherError();
	//�жϷ��ص�XML����Ƿ�ɹ�
	//bool GetXmlRet(CXMLMarkup &XmlPrase);
	//UString GetTmpFileName();

	const char * GetBody(void) { return m_readDate.c_str(); };

	UString GetError() { return m_strError; }


private:
	void InitHeaderMap();
	virtual BOOL GetData(LPVOID lpBuffer, DWORD dwBufferSize, DWORD& dwWrite);

protected:
	HINTERNET m_hSession;
	HINTERNET m_hConnect;
	HINTERNET m_hRequest;
	DWORD m_dwTimeout;
	LPBYTE m_lpReceiveData;
	DWORD m_dwReceiveDataLength;
	std::wstring m_wstrUrlPath;
	VecStParam m_VecExtInfo;

	map<CDuiString, CDuiString> m_mapPostHeard;
	map<CDuiString, CDuiString> m_mapHeard;
	map<UString, UString> m_mapCookie;



	UString  m_strError;
	string m_readDate;
	// ��¼����
	bool bIsNeeGetInfo;
	DWORD m_nHttpStatus;
	UString m_HttpStatus;
	UString m_strBaseUrl;

	wstring m_wstrFilePath;
	StReadInfo  m_ReadInfo;
};

#endif //_HTTPCLIENTSYN_HEAD_