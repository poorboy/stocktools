#ifndef CommApi_h__
#define CommApi_h__
#include <xstring>
#include <tchar.h>
#include <xstring> 
#include <map>
#include <vector>
#include <io.h>
#include <Shlwapi.h>
#include <Windows.h>
#include <AclAPI.h> 

using namespace std;

#define  LYMSGOK(A)                       MessageBox(GetHWND(),A, L"���ܹ���", MB_OK)

#define  LYMSGBOXOK(A,Y)                  MessageBox(GetHWND(),A, Y, MB_OK)

#define  LYMSGBOX(A,Y)                    MessageBox(GetHWND(),A, L"���ܹ���", Y)

#define  ENABLE_CONTROL(X,Y)              if(X) X->SetEnabled(Y) 

#define  ENABLE_CONTROL_BY_NAME(X,Y,Z)   { CControlUI * pCont = Z.FindControl(X);ENABLE_CONTROL(pCont, Y);}

#define  GET_CONTROL_TEXT(X,Y) {  if(X) Y =  X->GetText(); }
#define  SET_CONTROL_TEXT(X,Y) {  if(X) X->SetText(Y); }

#define  GET_CONTROL_NUMBER(X,Y) { CDuiString strTmp = L"0"; GET_CONTROL_TEXT(X,strTmp); Y = _wtoi(strTmp.GetData());}
#define  GET_CONTROL_TEXT_BY_NAME(X,Y, Z) { CControlUI * pCont = Z.FindControl(X); GET_CONTROL_TEXT(pCont,Y);}

#define  TRIM_DUI_STR(X)                 { wstring wstr = X.GetData(); TrimString(wstr);  X = wstr.c_str();}



bool        IsFileExists(const wchar_t * lpFileName);
bool        IsFileExists(const char * lpFileName);
bool        IsDir(wstring &strDirPath);
wstring     GetAppDir();
bool        DirExist(const TCHAR  *pszDirName);
string      W2UTF8(wstring& strUnicode);
wstring     C2W(string &strData);


string      W2UTF8(wchar_t * wsUnicode);
wstring     C2W(const char* pBuffer);

string      W2A(wstring &wsting);
string      W2A(const wchar_t * wsting);

wstring     C2Unicode(const char *szData);
wstring     C2Unicode(string &strData);

wstring GetCurrTimeString();

wstring N2S(ULONGLONG u);

wstring N2S(DWORD dw);

wstring FormatTime(ULONGLONG uTime);

void TrimString(wstring &wsting);

bool ChangeExeIcon(LPCTSTR IconFile, LPCTSTR ExeFile);
BOOL ReplaceICO(LPCTSTR lpszApp, LPCTSTR lpszICO);
#endif // CommApi_h__
