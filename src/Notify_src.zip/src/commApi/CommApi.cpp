#include "CommApi.h"
#include "debugnew.h"

bool IsFileExists(const wchar_t * lpFileName)
{
	if (_waccess(lpFileName, 0) == -1)
	{
		return false;
	}

	if (::PathIsDirectoryW(lpFileName))
	{
		return false;
	}

	return true;
}

bool IsFileExists(const char * lpFileName)
{
	if (_access(lpFileName, 0) == -1)
	{
		return false;
	}

	if (::PathIsDirectoryA(lpFileName))
	{
		return false;
	}

	return true;
}

//检查是不是文件夹
bool IsDir(wstring &strDirPath)
{
	if (::PathIsDirectory(strDirPath.c_str()))
	{
		return true;
	}
	return false;
}

wstring GetAppDir()
{
	TCHAR sFilename[_MAX_PATH];
	TCHAR sDrive[_MAX_DRIVE];
	TCHAR sDir[_MAX_DIR];
	TCHAR sFname[_MAX_FNAME];
	TCHAR sExt[_MAX_EXT];

	::GetModuleFileName(NULL, sFilename, _MAX_PATH);

	_tsplitpath_s(sFilename, sDrive, _MAX_DRIVE, sDir, _MAX_DIR,
		sFname, _MAX_FNAME, sExt, _MAX_EXT);

	wstring homeDir = sDrive;
	homeDir += wstring(sDir);
	int nLen = homeDir.length();
	if (homeDir.at(nLen - 1) != _T('\\'))
		homeDir += _T("\\");

	return homeDir;
}

//检查一个文件夹是否存在 
bool DirExist(const TCHAR  *pszDirName)
{
	try
	{
		WIN32_FIND_DATA   fileinfo;
		TCHAR   _szDir[_MAX_PATH];
		_tcscpy(_szDir, pszDirName);
		int nLen = _tcsclen(_szDir);
		if ((_szDir[nLen - 1] == _T('\\')) || (_szDir[nLen - 1] == _T('/')))
		{
			_szDir[nLen - 1] = _T('\0');
		}
		HANDLE hFind = ::FindFirstFile(_szDir, &fileinfo);

		if (hFind == INVALID_HANDLE_VALUE)
		{
			return false;
		}

		if (fileinfo.dwFileAttributes && FILE_ATTRIBUTE_DIRECTORY)
		{
			::FindClose(hFind);
			return true;
		}

		::FindClose(hFind);
	}
	catch (...)
	{
		return false;
	}

	return false;
}

string W2UTF8(wstring& strUnicode)
{
	string str;
	int iSize = WideCharToMultiByte(CP_UTF8, 0, strUnicode.c_str(), -1, NULL, 0, NULL, NULL);
	char*  pszMultiByte = (char*)malloc((iSize + 1));
	WideCharToMultiByte(CP_UTF8, 0, strUnicode.c_str(), -1, pszMultiByte, iSize, NULL, NULL);
	str = pszMultiByte;
	delete[] pszMultiByte;
	pszMultiByte = NULL;
	return str;
}

wstring C2W(string &strData)
{
	WCHAR* buf;
	wstring str;
	int nLength = MultiByteToWideChar(CP_UTF8, 0, strData.c_str(), -1, NULL, 0);
	if (nLength <= 0) return str;
	nLength *= 2;
	buf = new WCHAR[nLength + 1];
	memset(buf, 0, (nLength + 1) * sizeof(WCHAR));
	int nRet = MultiByteToWideChar(CP_UTF8, 0, strData.c_str(), nLength, buf, nLength);
	buf[nRet] = 0;
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

wstring C2W(const char* pBuffer)
{
	WCHAR* buf;
	wstring str;
	int nLength = strlen(pBuffer);
	if (nLength <= 0) return str;
	buf = new WCHAR[nLength + 1];
	memset(buf, 0, (nLength + 1) * sizeof(WCHAR));
	int nRet = MultiByteToWideChar(CP_UTF8, 0, pBuffer, nLength, buf, nLength);
	buf[nRet] = 0;
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

string W2UTF8(wchar_t * wsUnicode)
{
	char* buf;
	string str;
	int nLength = wcslen(wsUnicode) + 1;
	buf = new char[nLength * 4 + 1];
	memset(buf, 0, nLength * 4 + 1);
	int nSize = nLength * 4;
	int nRet = WideCharToMultiByte(CP_UTF8, 0, wsUnicode, nLength, buf, nSize, NULL, NULL);
	buf[nRet] = 0;
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

string W2A(wstring &wsting)
{
	char* buf;
	string str;
	int nLength = wsting.length() + 1;
	buf = new char[nLength * 4 + 1];
	memset(buf, 0, nLength * 4 + 1);
	int nSize = nLength * 4;
	int nRet = WideCharToMultiByte(CP_ACP, 0, wsting.c_str(), nLength, buf, nSize, NULL, NULL);
	buf[nRet] = 0;
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

string W2A(const wchar_t * wsting)
{
	char* buf;
	string str;
	int nLength = wcslen(wsting) + 1;
	buf = new char[nLength * 4 + 1];
	memset(buf, 0, nLength * 4 + 1);
	int nSize = nLength * 4;
	int nRet = WideCharToMultiByte(CP_ACP, 0, wsting, nLength, buf, nSize, NULL, NULL);
	buf[nRet] = 0;
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

wstring C2Unicode(const char *szData)
{
	WCHAR* buf;
	wstring str = L"";
	int nLength = (strlen(szData) + 1) * sizeof(WCHAR);
	int codepage = AreFileApisANSI() ? CP_ACP : CP_OEMCP;
	buf = new WCHAR[nLength];
	memset(buf, 0, nLength);
	int nRet = MultiByteToWideChar(codepage, 0, szData, nLength, buf, nLength);
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

wstring C2Unicode(string &strData)
{
	WCHAR* buf;
	wstring str = L"";
	int nLength = strData.length() + 1;
	int codepage = AreFileApisANSI() ? CP_ACP : CP_OEMCP;
	buf = new WCHAR[nLength];
	memset(buf, 0, nLength * sizeof(WCHAR));
	int nRet = MultiByteToWideChar(codepage, 0, strData.c_str(), nLength, buf, nLength);
	str = buf;
	delete[]buf;
	buf = NULL;
	return str;
}

//// 由文件全路径名获取其文件名
//wstring ParseFileName(wstring& strFileFullName)
//{
//    strFileFullName.TrimRight(_T('\\'));
//    int nLen = strFileFullName.GetLength();
//    int nPos = strFileFullName.ReverseFind(_T('\\'));
//    if (nPos == -1)
//    {
//        return strFileFullName;
//    }
//
//    wstring strFileName = strFileFullName.Mid(nPos + 1, nLen - nPos - 1);
//
//    return strFileName;
//}

wstring GetCurrTimeString()
{
	wstring strTmp;
	WCHAR szTime[50];
	SYSTEMTIME st;
	::GetLocalTime(&st);
	wsprintf(szTime,
		_T("%d-%02d-%02d %02d:%02d:%02d"),
		st.wYear,
		st.wMonth,
		st.wDay,
		st.wHour,
		st.wMinute,
		st.wSecond
	);
	strTmp = szTime;
	return strTmp;
}

wstring N2S(ULONGLONG u)
{
	wstring strTmp;
	WCHAR szTmp[10];
	wsprintf(szTmp, _T("%I64u"), u);
	strTmp = szTmp;
	return strTmp;
}


wstring N2S(DWORD dw)
{
	wstring strTmp;
	WCHAR szTmp[10];
	wsprintf(szTmp, _T("%d"), dw);
	strTmp = szTmp;
	return strTmp;
}

void TrimString(wstring &wsting)
{
	int nLen = wsting.length();
	if (nLen < 1) return;

	while (
		(nLen > 0)
		&&
		(_tcscmp(wsting.substr(0, 1).c_str(), L" ") == 0))
	{
		wsting = wsting.substr(1);
		nLen = wsting.length();
	}

	while (
		(nLen > 0)
		&&
		(_tcscmp(wsting.substr((nLen - 1), 1).c_str(), L" ") == 0))
	{
		wsting = wsting.substr(0, (nLen - 1));
		nLen = wsting.length();
	}
}



//方法二：通过PE文件的图标偏移地址实现：
//
//一年前初学VB时我对这个API就特感兴趣，听说这个API可以更改图标资源，就更感兴趣了，后来试了试，发现修改其它资源貌似没多大问题，唯独修改图标时无果，我发现所修改的图虽说已经写入到资源文件中了，但是就是无法显示。后来到网上查了下，发现用UpdateResource修改EXE图标的没一个成功的，大致都是发生成功写入，无法正常显示的问题。罢矣，当时就琢磨着把该问题先放放，等日后有时间再好好折腾。
//无奈时间过得太快，忽忽悠悠就过了一年了，前几天，在整理去年的一些源码时发现了这个遗留在硬盘中的代码，一年前无奈自己所学浅溥，啥都不知道，但现在已经对API有了较深厚的认识，再加上对汇编的一些了解，我想此时不解决更待何时。
//在折腾这个API的期间也发生不少问题，最让我自责的就是差点被 CreateFile 这个API给Game Over，这个小伟知道（又是小伟？没办法啊，谁要咱和小伟太有缘了~）。还好自己最终醒悟，否则真的要好好鄙视鄙视自己。最初修改时还是和一年前一个样，这时我一直在回想一样年遇到这个问题的问题：所写图标的数据是不是完整的写到了资源文件中？想到此，我用eXeScope(一个PE资源文件查看工具)看了下写入到资源文件中的十六进制，又用UltraEdit-32以十六进制查看ico文件中的数据，发现没问题啊？一字节一字节都对得上，那问题出在哪了？没法，继续在Google游荡，终于找了一份有效的资料（网址现在不知扔哪去了），全E文，看得难受，不过大致的意思是说ICON是由一个结构组成，同PE那些什么NT头，DOS头的差不多，而所显示的图像数据包函于ICON类型结构的dwImageOffset偏移处。呵，这下总算搞明白为什么直接把ICON文件写入到资源文件中显示不了的问题了，也就是说在dwImageOffset偏移位置处才是咱所需要的图像数据，这不就啥都OK了么，爷爷的，原来咱从一开始就被ICON文件整得稀里糊涂，靠MS，当然也鄙视下自己的无知。另外还好找到的那份资料有点人性，把结构给咱标出来了，那么现在一切都顺理成章，不说多了，上代码：

//#include <stdio.h>
//#include <windows.h>
//#include <tchar.h>

struct ICONDIRENTRY
{
	BYTE bWidth;
	BYTE bHeight;
	BYTE bColorCount;
	BYTE bReserved;
	WORD wPlanes;
	WORD wBitCount;
	DWORD dwBytesInRes;
	DWORD dwImageOffset;
};

struct ICONDIR
{
	WORD idReserved;
	WORD idType;
	WORD idCount;
	//ICONDIRENTRY idEntries;
};

struct GRPICONDIRENTRY
{
	BYTE bWidth;
	BYTE bHeight;
	BYTE bColorCount;
	BYTE bReserved;
	WORD wPlanes;
	WORD wBitCount;
	DWORD dwBytesInRes;
	WORD nID;
};

struct GRPICONDIR
{
	WORD idReserved;
	WORD idType;
	WORD idCount;
	GRPICONDIRENTRY idEntries;
};

//////////////////////////////////////////////
//函数说明：修改EXE图标
//
//参    数：IconFile 图标文件 
//              ExeFile 被修改的EXE文件
//
//返回值： 成功为True，否则False
/////////////////////////////////////////////
bool ChangeExeIcon(LPCTSTR IconFile, LPCTSTR ExeFile)
{
	DWORD dwError = 0;
	ICONDIR stID;
	ICONDIRENTRY stIDE;
	GRPICONDIR stGID;
	HANDLE hFile;
	DWORD nSize, nGSize, dwReserved;
	HANDLE hUpdate;
	PBYTE pIcon, pGrpIcon;
	BOOL ret;
	hFile = CreateFile(IconFile, GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}

	ZeroMemory(&stID, sizeof(ICONDIR));
	ret = ReadFile(hFile, &stID, sizeof(ICONDIR), &dwReserved, NULL);
	ZeroMemory(&stIDE, sizeof(ICONDIRENTRY));
	ret = ReadFile(hFile, &stIDE, sizeof(ICONDIRENTRY), &dwReserved, NULL);
	nSize = stIDE.dwBytesInRes;
	pIcon = (PBYTE)malloc(nSize);
	SetFilePointer(hFile, stIDE.dwImageOffset, NULL, FILE_BEGIN);
	ret = ReadFile(hFile, (LPVOID)pIcon, nSize, &dwReserved, NULL);
	if (!ret)
	{
		CloseHandle(hFile);
		return false;
	}

	ZeroMemory(&stGID, sizeof(GRPICONDIR));
	stGID.idCount = stID.idCount;
	stGID.idReserved = 0;
	stGID.idType = 1;
	CopyMemory(&stGID.idEntries, &stIDE, 12);
	stGID.idEntries.nID = 0;
	nGSize = sizeof(GRPICONDIR);
	pGrpIcon = (PBYTE)malloc(nGSize);
	CopyMemory(pGrpIcon, &stGID, nGSize);

	hUpdate = BeginUpdateResource(ExeFile, false);
	ret = UpdateResource(hUpdate, RT_GROUP_ICON, MAKEINTRESOURCE(1), 0, (LPVOID)pGrpIcon, nGSize);
	if (!ret)
	{
		dwError = GetLastError();
	}

	ret = UpdateResource(hUpdate, RT_ICON, MAKEINTRESOURCE(1), 0, (LPVOID)pIcon, nSize);
	if (!ret)
	{
		dwError = GetLastError();
	}

	EndUpdateResource(hUpdate, false);

	if (!ret)
	{
		CloseHandle(hFile);
		return false;
	}

	CloseHandle(hFile);
	return true;
}

BOOL ReplaceICO(LPCTSTR lpszApp, LPCTSTR lpszICO)
{
	HANDLE    hICO;
	DWORD dwError = 0;
	//打开硬盘上的图标文件
	if (!(hICO = ::CreateFile(lpszICO, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)))
	{
		return FALSE;
	}

	LONG    lOffset;    //资源在文件中的偏移量
	DWORD    dwSize;        //加载后资源的大小
	DWORD    dwReadByte;    //读取文件时实际读取大小，API强制要求。其实没用……
	LPVOID    lpRes;        //指向更新RT_ICON的资源
	LPVOID    lpGIco;        //指向更新RT_GROUP_ICON的资源
	CONST BYTE byGSize = 0x18;    //RT_GROUP_ICON资源的大小，为常数。

	//分配RT_GROUP_ICON资源的内存。
	if (!(lpGIco = new BYTE[byGSize])) { ::CloseHandle(hICO); return FALSE; }
	memset(lpGIco, 0, byGSize);//清零RT_GROUP_ICON资源内存
	::ReadFile(hICO, lpGIco, 0x06, &dwReadByte, NULL);//从文件中读取RT_GROUP_ICON资源头
	::ReadFile(hICO, (LPVOID)((BYTE*)lpGIco + 0x08), 0x0C, &dwReadByte, NULL);//从文件中读取RT_GROUP_ICON资源
	//获取ICO资源的大小。
	memcpy((void*)&dwSize, (void*)((BYTE*)lpGIco + 0x10), sizeof(DWORD));
	//获取ICO资源的偏移量。
	::ReadFile(hICO, (void*)&lOffset, sizeof(LONG), &dwReadByte, NULL);
	//分配ICO资源的内存。
	if (!(lpRes = new BYTE[dwSize])) { delete[] lpGIco; ::CloseHandle(hICO); return FALSE; }
	//偏移文件指针
	::SetFilePointer(hICO, lOffset, NULL, FILE_BEGIN);
	//读取图标资源到内存。
	::ReadFile(hICO, lpRes, dwSize, &dwReadByte, NULL);
	::CloseHandle(hICO);

	//打开要更改图标的可执行文件。
	HANDLE    hApp;
	if (NULL == (hApp = ::BeginUpdateResource(lpszApp, NULL)))
	{
		delete[] lpGIco;
		delete[] lpRes;

		return FALSE;
	}

	//标记更新资源
	if (!::UpdateResource(hApp, RT_GROUP_ICON, MAKEINTRESOURCE(1), 0, lpGIco, byGSize))
	{
		dwError = GetLastError();
	}
	if (!::UpdateResource(hApp, RT_ICON, MAKEINTRESOURCE(1), 0, lpRes, dwSize))
	{
		dwError = GetLastError();;
	}
	//写入新资源
	if (!::EndUpdateResource(hApp, FALSE))
	{
		delete[] lpGIco;
		delete[] lpRes;

		return FALSE;
	}

	delete[] lpGIco;
	delete[] lpRes;

	return TRUE;
}